int32_t vDOCUMENT = -462;
int32_t vERROR__tErrorMessage = -642;
int32_t vOK = -734;
int32_t vUSR__GetCurrent = -1046;

