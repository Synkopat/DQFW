extern int32_t vOK;
extern Txt K;
extern Txt K300;
extern Txt KBttnAdd;
extern Txt KBttnDelete;
extern Txt KBttnSave;
extern Txt KBttnSelectGroup;
extern Txt KCancel;
extern Txt KCategory;
extern Txt KCreatedBy_20_3D_20_3A1;
extern Txt KDBQueries;
extern Txt KDelete;
extern Txt KDiscard;
extern Txt KDisplayRole;
extern Txt KGroup;
extern Txt KKey;
extern Txt KQueryName;
extern Txt KSave;
extern Txt KSingle;
extern Txt KSystem_20Name;
extern Txt KUSER;
extern Txt K__;
extern Txt KbAutoComplete;
extern Txt KbEnableGrouping;
extern Txt KbFullAccess;
extern Txt KbSaveRecord;
extern Txt KbttnClose;
extern Txt Kcode;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt Kcopy;
extern Txt Kdistinct;
extern Txt Kdrop;
extern Txt KeDBQuery;
extern Txt KisNew;
extern Txt Kjoin;
extern Txt Klength;
extern Txt Knew;
extern Txt KobjectName;
extern Txt Kpush;
extern Txt Kquery;
extern Txt Ksave;
extern Txt KtFormHeader;
extern Txt KtSelectionMode;
extern Txt Ktouched;
extern Txt kHrlR6C2oH1s;
extern Txt kLGJAiSueMjo;
extern Txt kV4hd9u0tSd4;
extern Txt kXe$hkKzzxyk;
extern Txt kifRyNcfJ4tA;
extern Txt ko166k_hFrHs;
extern Txt kxBemVzOKO4U;
Asm4d_Proc proc_WDGT__CONFIGCOLUMNS;
Asm4d_Proc proc_WDGT__SELECT;
extern unsigned char D_proc_SBK__MANAGERHNDL[];
void proc_SBK__MANAGERHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__MANAGERHNDL);
	if (!ctx->doingAbort) {
		Variant ltCategory;
		Obj loQry;
		Obj loItem;
		Txt ltHeaders;
		Col lcolCategories;
		Txt ltAlertMsg;
		Variant ltGroup;
		Col lcolItems;
		Bool lbOptionKeyDown;
		Obj l__4D__auto__iter__0;
		Obj l__4D__auto__iter__1;
		Bool lbCtrlKeyDown;
		Obj loResults;
		Obj ltoFormEvent;
		Col lcolMandatoryFields;
		Obj loFormEvent;
		Col lcolUserSelection;
		Bool lJCPEREZ__20241102;
		Txt ltHiddenCols;
		Obj loListItems;
		Txt ltHdrMap;
		Bool lbContinue;
		Txt ltWidths;
		Col lcolGroups;
		c.f.fLine=12;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Bool t0;
			c.f.fLine=15;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,546)) goto _0;
			Bool t1;
			if (g->Call(ctx,(PCV[]){t1.cv()},0,562)) goto _0;
			g->Check(ctx);
			lbCtrlKeyDown=t0.get()||t1.get();
		}
		{
			Variant t3;
			c.f.fLine=17;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t3.cv())) goto _0;
			Bool t4;
			if (g->OperationOnAny(ctx,6,t3.cv(),Value_null().cv(),t4.cv())) goto _0;
			if (!(t4.get())) goto _2;
		}
		{
			Variant t5;
			c.f.fLine=21;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t5.cv())) goto _0;
			Bool t6;
			if (g->OperationOnAny(ctx,6,t5.cv(),Long(1).cv(),t6.cv())) goto _0;
			if (!(t6.get())) goto _4;
		}
		{
			Obj t7;
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){t7.cv()},0,1466)) goto _0;
			Variant t8;
			if (g->GetMember(ctx,t7.cv(),KbEnableGrouping.cv(),t8.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KGroup.cv(),t8.cv()},3,238)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t9;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t9.cv()},0,1466)) goto _0;
			Variant t10;
			if (g->GetMember(ctx,t9.cv(),KbEnableGrouping.cv(),t10.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KCategory.cv(),t10.cv()},3,238)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t11;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t11.cv()},0,1466)) goto _0;
			Variant t12;
			if (g->GetMember(ctx,t11.cv(),KbEnableGrouping.cv(),t12.cv())) goto _0;
			Bool t13;
			if (!g->GetValue(ctx,(PCV[]){t13.cv(),t12.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KBttnSelectGroup.cv(),t13.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t14;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t14.cv()},0,1466)) goto _0;
			Variant t15;
			if (g->GetMember(ctx,t14.cv(),KbEnableGrouping.cv(),t15.cv())) goto _0;
			Bool t16;
			if (!g->GetValue(ctx,(PCV[]){t16.cv(),t15.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),kLGJAiSueMjo.cv(),t16.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t17;
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1466)) goto _0;
			Variant t18;
			if (g->GetMember(ctx,t17.cv(),KbFullAccess.cv(),t18.cv())) goto _0;
			Bool t19;
			if (!g->GetValue(ctx,(PCV[]){t19.cv(),t18.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KBttnAdd.cv(),t19.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t20;
			c.f.fLine=27;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1466)) goto _0;
			Variant t21;
			if (g->GetMember(ctx,t20.cv(),KbFullAccess.cv(),t21.cv())) goto _0;
			Bool t22;
			if (!g->GetValue(ctx,(PCV[]){t22.cv(),t21.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KBttnDelete.cv(),t22.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		goto _3;
_4:
_3:
		goto _5;
_2:
		{
			Variant t23;
			c.f.fLine=33;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t23.cv())) goto _0;
			Bool t24;
			if (g->OperationOnAny(ctx,6,t23.cv(),KbttnClose.cv(),t24.cv())) goto _0;
			if (!(t24.get())) goto _7;
		}
		{
			Obj t25;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t25.cv()},0,1466)) goto _0;
			Variant t26;
			if (g->GetMember(ctx,t25.cv(),KeDBQuery.cv(),t26.cv())) goto _0;
			Variant t27;
			if (g->Call(ctx,(PCV[]){t27.cv(),t26.cv(),KisNew.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Bool t28;
			if (!g->GetValue(ctx,(PCV[]){t28.cv(),t27.cv(),nullptr})) goto _0;
			if (!(t28.get())) goto _8;
		}
		c.f.fLine=35;
		if (g->Call(ctx,(PCV[]){nullptr,kV4hd9u0tSd4.cv(),KDiscard.cv(),KCancel.cv()},3,162)) goto _0;
		g->Check(ctx);
		if (1!=Var<Long>(ctx,vOK).get()) goto _9;
		c.f.fLine=37;
		if (g->Call(ctx,(PCV[]){nullptr},0,270)) goto _0;
		g->Check(ctx);
_9:
_8:
		goto _6;
_7:
		{
			Variant t30;
			c.f.fLine=43;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t30.cv())) goto _0;
			Bool t31;
			if (g->OperationOnAny(ctx,6,t30.cv(),KBttnAdd.cv(),t31.cv())) goto _0;
			if (!(t31.get())) goto _10;
		}
		{
			Obj t32;
			c.f.fLine=46;
			if (g->Call(ctx,(PCV[]){t32.cv()},0,1466)) goto _0;
			Variant t33;
			if (g->GetMember(ctx,t32.cv(),KeDBQuery.cv(),t33.cv())) goto _0;
			Variant t34;
			if (g->Call(ctx,(PCV[]){t34.cv(),t33.cv(),Ktouched.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Bool t35;
			if (!g->GetValue(ctx,(PCV[]){t35.cv(),t34.cv(),nullptr})) goto _0;
			if (!(t35.get())) goto _11;
		}
		c.f.fLine=47;
		if (g->Call(ctx,(PCV[]){nullptr,kXe$hkKzzxyk.cv(),KSave.cv(),KCancel.cv()},3,162)) goto _0;
		g->Check(ctx);
		if (1!=Var<Long>(ctx,vOK).get()) goto _12;
		{
			Obj t37;
			c.f.fLine=49;
			if (g->Call(ctx,(PCV[]){t37.cv()},0,1466)) goto _0;
			Variant t38;
			if (g->GetMember(ctx,t37.cv(),KeDBQuery.cv(),t38.cv())) goto _0;
			Variant t39;
			if (g->Call(ctx,(PCV[]){t39.cv(),t38.cv(),Ksave.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t40;
			if (!g->GetValue(ctx,(PCV[]){t40.cv(),t39.cv(),nullptr})) goto _0;
			loResults=t40.get();
		}
_12:
_11:
		{
			Obj t41;
			c.f.fLine=54;
			if (g->Call(ctx,(PCV[]){t41.cv()},0,1466)) goto _0;
			Obj t42;
			if (g->Call(ctx,(PCV[]){t42.cv()},0,1482)) goto _0;
			Variant t43;
			if (g->Call(ctx,(PCV[]){t43.cv(),t42.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t44;
			if (g->Call(ctx,(PCV[]){t44.cv(),t43.cv(),Knew.cv()},2,1498)) goto _0;
			if (g->SetMember(ctx,t41.cv(),KeDBQuery.cv(),t44.cv())) goto _0;
		}
		goto _6;
_10:
		{
			Variant t45;
			c.f.fLine=56;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t45.cv())) goto _0;
			Bool t46;
			if (g->OperationOnAny(ctx,6,t45.cv(),KBttnDelete.cv(),t46.cv())) goto _0;
			if (!(t46.get())) goto _13;
		}
		{
			Obj t47;
			c.f.fLine=59;
			if (g->Call(ctx,(PCV[]){t47.cv()},0,1466)) goto _0;
			Variant t48;
			if (g->GetMember(ctx,t47.cv(),KeDBQuery.cv(),t48.cv())) goto _0;
			Variant t49;
			if (g->Call(ctx,(PCV[]){t49.cv(),t48.cv(),Ktouched.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Bool t50;
			if (!g->GetValue(ctx,(PCV[]){t50.cv(),t49.cv(),nullptr})) goto _0;
			if (!(t50.get())) goto _14;
		}
		c.f.fLine=60;
		if (g->Call(ctx,(PCV[]){nullptr,kHrlR6C2oH1s.cv(),KDelete.cv(),KCancel.cv()},3,162)) goto _0;
		g->Check(ctx);
		if (1!=Var<Long>(ctx,vOK).get()) goto _15;
		{
			Obj t52;
			c.f.fLine=62;
			if (g->Call(ctx,(PCV[]){t52.cv()},0,1466)) goto _0;
			Variant t53;
			if (g->GetMember(ctx,t52.cv(),KeDBQuery.cv(),t53.cv())) goto _0;
			Variant t54;
			if (g->Call(ctx,(PCV[]){t54.cv(),t53.cv(),Kdrop.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t55;
			if (!g->GetValue(ctx,(PCV[]){t55.cv(),t54.cv(),nullptr})) goto _0;
			loResults=t55.get();
		}
_15:
_14:
		{
			Obj t56;
			c.f.fLine=67;
			if (g->Call(ctx,(PCV[]){t56.cv()},0,1466)) goto _0;
			Obj t57;
			if (g->Call(ctx,(PCV[]){t57.cv()},0,1482)) goto _0;
			Variant t58;
			if (g->Call(ctx,(PCV[]){t58.cv(),t57.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t59;
			if (g->Call(ctx,(PCV[]){t59.cv(),t58.cv(),Knew.cv()},2,1498)) goto _0;
			if (g->SetMember(ctx,t56.cv(),KeDBQuery.cv(),t59.cv())) goto _0;
		}
		goto _6;
_13:
		{
			Variant t60;
			c.f.fLine=69;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t60.cv())) goto _0;
			Bool t61;
			if (g->OperationOnAny(ctx,6,t60.cv(),KBttnSave.cv(),t61.cv())) goto _0;
			if (!(t61.get())) goto _16;
		}
		{
			Col t62;
			c.f.fLine=75;
			if (g->Call(ctx,(PCV[]){t62.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolMandatoryFields=t62.get();
		}
		lbContinue=Bool(1).get();
		{
			Obj t63;
			c.f.fLine=79;
			if (g->Call(ctx,(PCV[]){t63.cv()},0,1466)) goto _0;
			Variant t64;
			if (g->GetMember(ctx,t63.cv(),KeDBQuery.cv(),t64.cv())) goto _0;
			Variant t65;
			if (g->GetMember(ctx,t64.cv(),KGroup.cv(),t65.cv())) goto _0;
			Bool t66;
			if (g->OperationOnAny(ctx,6,t65.cv(),K.cv(),t66.cv())) goto _0;
			if (!(t66.get())) goto _17;
		}
		c.f.fLine=80;
		if (g->Call(ctx,(PCV[]){nullptr,lcolMandatoryFields.cv(),Kpush.cv(),KGroup.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _18;
_17:
		{
			Obj t67;
			c.f.fLine=82;
			if (g->Call(ctx,(PCV[]){t67.cv()},0,1466)) goto _0;
			Variant t68;
			if (g->GetMember(ctx,t67.cv(),KeDBQuery.cv(),t68.cv())) goto _0;
			Obj t69;
			if (g->Call(ctx,(PCV[]){t69.cv()},0,1466)) goto _0;
			Variant t70;
			if (g->GetMember(ctx,t69.cv(),KeDBQuery.cv(),t70.cv())) goto _0;
			Variant t71;
			if (g->GetMember(ctx,t70.cv(),KGroup.cv(),t71.cv())) goto _0;
			Txt t72;
			if (g->Call(ctx,(PCV[]){t72.cv(),Long(32).cv()},1,90)) goto _0;
			Txt t73;
			if (!g->GetValue(ctx,(PCV[]){t73.cv(),t71.cv(),nullptr})) goto _0;
			Txt t74;
			if (g->Call(ctx,(PCV[]){t74.cv(),t73.cv(),t72.cv(),K__.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,t68.cv(),KGroup.cv(),t74.cv())) goto _0;
		}
_18:
		{
			Obj t75;
			c.f.fLine=85;
			if (g->Call(ctx,(PCV[]){t75.cv()},0,1466)) goto _0;
			Variant t76;
			if (g->GetMember(ctx,t75.cv(),KeDBQuery.cv(),t76.cv())) goto _0;
			Variant t77;
			if (g->GetMember(ctx,t76.cv(),KCategory.cv(),t77.cv())) goto _0;
			Bool t78;
			if (g->OperationOnAny(ctx,6,t77.cv(),K.cv(),t78.cv())) goto _0;
			if (!(t78.get())) goto _19;
		}
		c.f.fLine=86;
		if (g->Call(ctx,(PCV[]){nullptr,lcolMandatoryFields.cv(),Kpush.cv(),KCategory.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _20;
_19:
		{
			Obj t79;
			c.f.fLine=88;
			if (g->Call(ctx,(PCV[]){t79.cv()},0,1466)) goto _0;
			Variant t80;
			if (g->GetMember(ctx,t79.cv(),KeDBQuery.cv(),t80.cv())) goto _0;
			Obj t81;
			if (g->Call(ctx,(PCV[]){t81.cv()},0,1466)) goto _0;
			Variant t82;
			if (g->GetMember(ctx,t81.cv(),KeDBQuery.cv(),t82.cv())) goto _0;
			Variant t83;
			if (g->GetMember(ctx,t82.cv(),KCategory.cv(),t83.cv())) goto _0;
			Txt t84;
			if (g->Call(ctx,(PCV[]){t84.cv(),Long(32).cv()},1,90)) goto _0;
			Txt t85;
			if (!g->GetValue(ctx,(PCV[]){t85.cv(),t83.cv(),nullptr})) goto _0;
			Txt t86;
			if (g->Call(ctx,(PCV[]){t86.cv(),t85.cv(),t84.cv(),K__.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,t80.cv(),KCategory.cv(),t86.cv())) goto _0;
		}
_20:
		{
			Obj t87;
			c.f.fLine=91;
			if (g->Call(ctx,(PCV[]){t87.cv()},0,1466)) goto _0;
			Variant t88;
			if (g->GetMember(ctx,t87.cv(),KeDBQuery.cv(),t88.cv())) goto _0;
			Variant t89;
			if (g->GetMember(ctx,t88.cv(),KQueryName.cv(),t89.cv())) goto _0;
			Bool t90;
			if (g->OperationOnAny(ctx,6,t89.cv(),K.cv(),t90.cv())) goto _0;
			if (!(t90.get())) goto _21;
		}
		c.f.fLine=92;
		if (g->Call(ctx,(PCV[]){nullptr,lcolMandatoryFields.cv(),Kpush.cv(),KSystem_20Name.cv()},3,1500)) goto _0;
		g->Check(ctx);
_21:
		{
			Variant t91;
			c.f.fLine=95;
			if (g->Call(ctx,(PCV[]){t91.cv(),lcolMandatoryFields.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t92;
			if (g->OperationOnAny(ctx,5,t91.cv(),Num(0).cv(),t92.cv())) goto _0;
			if (!(t92.get())) goto _22;
		}
		{
			Txt t93;
			c.f.fLine=96;
			if (g->Call(ctx,(PCV[]){t93.cv(),Long(13).cv()},1,90)) goto _0;
			g->AddString(kxBemVzOKO4U.get(),t93.get(),ltAlertMsg.get());
		}
		{
			Txt t95;
			c.f.fLine=97;
			if (g->Call(ctx,(PCV[]){t95.cv(),Long(13).cv()},1,90)) goto _0;
			Variant t96;
			if (g->Call(ctx,(PCV[]){t96.cv(),lcolMandatoryFields.cv(),Kjoin.cv(),t95.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Variant t97;
			if (g->OperationOnAny(ctx,0,ltAlertMsg.cv(),t96.cv(),t97.cv())) goto _0;
			Txt t98;
			if (!g->GetValue(ctx,(PCV[]){t98.cv(),t97.cv(),nullptr})) goto _0;
			ltAlertMsg=t98.get();
		}
		lbContinue=Bool(0).get();
_22:
		if (!(lbContinue.get())) goto _23;
		{
			Obj t99;
			c.f.fLine=103;
			if (g->Call(ctx,(PCV[]){t99.cv()},0,1466)) goto _0;
			Variant t100;
			if (g->GetMember(ctx,t99.cv(),KeDBQuery.cv(),t100.cv())) goto _0;
			Variant t101;
			if (g->GetMember(ctx,t100.cv(),KDisplayRole.cv(),t101.cv())) goto _0;
			Bool t102;
			if (g->OperationOnAny(ctx,6,t101.cv(),K.cv(),t102.cv())) goto _0;
			if (!(t102.get())) goto _24;
		}
		{
			Obj t103;
			c.f.fLine=104;
			if (g->Call(ctx,(PCV[]){t103.cv()},0,1466)) goto _0;
			Variant t104;
			if (g->GetMember(ctx,t103.cv(),KeDBQuery.cv(),t104.cv())) goto _0;
			Obj t105;
			if (g->Call(ctx,(PCV[]){t105.cv()},0,1466)) goto _0;
			Variant t106;
			if (g->GetMember(ctx,t105.cv(),KeDBQuery.cv(),t106.cv())) goto _0;
			Variant t107;
			if (g->GetMember(ctx,t106.cv(),KQueryName.cv(),t107.cv())) goto _0;
			if (g->SetMember(ctx,t104.cv(),KDisplayRole.cv(),t107.cv())) goto _0;
		}
_24:
		{
			Obj t108;
			c.f.fLine=106;
			if (g->Call(ctx,(PCV[]){t108.cv()},0,1466)) goto _0;
			Variant t109;
			if (g->GetMember(ctx,t108.cv(),KeDBQuery.cv(),t109.cv())) goto _0;
			Obj t110;
			if (g->Call(ctx,(PCV[]){t110.cv()},0,1466)) goto _0;
			Variant t111;
			if (g->GetMember(ctx,t110.cv(),KeDBQuery.cv(),t111.cv())) goto _0;
			Variant t112;
			if (g->GetMember(ctx,t111.cv(),KGroup.cv(),t112.cv())) goto _0;
			Obj t113;
			if (g->Call(ctx,(PCV[]){t113.cv()},0,1466)) goto _0;
			Variant t114;
			if (g->GetMember(ctx,t113.cv(),KeDBQuery.cv(),t114.cv())) goto _0;
			Variant t115;
			if (g->GetMember(ctx,t114.cv(),KCategory.cv(),t115.cv())) goto _0;
			Variant t116;
			if (g->OperationOnAny(ctx,0,t112.cv(),t115.cv(),t116.cv())) goto _0;
			Obj t117;
			if (g->Call(ctx,(PCV[]){t117.cv()},0,1466)) goto _0;
			Variant t118;
			if (g->GetMember(ctx,t117.cv(),KeDBQuery.cv(),t118.cv())) goto _0;
			Variant t119;
			if (g->GetMember(ctx,t118.cv(),KQueryName.cv(),t119.cv())) goto _0;
			Variant t120;
			if (g->OperationOnAny(ctx,0,t116.cv(),t119.cv(),t120.cv())) goto _0;
			if (g->SetMember(ctx,t109.cv(),KKey.cv(),t120.cv())) goto _0;
		}
		{
			Obj t121;
			c.f.fLine=107;
			if (g->Call(ctx,(PCV[]){t121.cv()},0,1466)) goto _0;
			Bool t122;
			t122=Bool(1).get();
			if (g->SetMember(ctx,t121.cv(),KbSaveRecord.cv(),t122.cv())) goto _0;
		}
		c.f.fLine=108;
		if (g->Call(ctx,(PCV[]){nullptr},0,269)) goto _0;
		g->Check(ctx);
		goto _25;
_23:
		c.f.fLine=110;
		if (g->Call(ctx,(PCV[]){nullptr,ltAlertMsg.cv()},1,41)) goto _0;
		g->Check(ctx);
_25:
		goto _6;
_16:
		{
			Variant t123;
			c.f.fLine=115;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t123.cv())) goto _0;
			Bool t124;
			if (g->OperationOnAny(ctx,6,t123.cv(),KBttnSelectGroup.cv(),t124.cv())) goto _0;
			if (!(t124.get())) goto _26;
		}
		{
			Col t125;
			c.f.fLine=120;
			if (g->Call(ctx,(PCV[]){t125.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolItems=t125.get();
		}
		{
			Col t126;
			c.f.fLine=121;
			if (g->Call(ctx,(PCV[]){t126.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolGroups=t126.get();
		}
		ltHdrMap=KGroup.get();
		ltHeaders=KGroup.get();
		ltWidths=K300.get();
		ltHiddenCols=K.get();
		{
			Obj t127;
			c.f.fLine=128;
			if (g->Call(ctx,(PCV[]){t127.cv()},0,1482)) goto _0;
			Variant t128;
			if (g->Call(ctx,(PCV[]){t128.cv(),t127.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t129;
			if (g->Call(ctx,(PCV[]){t129.cv(),t128.cv(),Kquery.cv(),KCreatedBy_20_3D_20_3A1.cv(),KUSER.cv()},4,1498)) goto _0;
			Variant t130;
			if (g->Call(ctx,(PCV[]){t130.cv(),t129.cv(),Kdistinct.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			Col t131;
			if (!g->GetValue(ctx,(PCV[]){t131.cv(),t130.cv(),nullptr})) goto _0;
			lcolGroups=t131.get();
		}
		{
			Ref t132;
			c.f.fLine=130;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t132.cv(),ltGroup.cv(),nullptr})) goto _0;
			Obj t133;
			if (g->Call(ctx,(PCV[]){t133.cv(),t132.cv(),lcolGroups.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t133.get();
		}
_27:
		{
			Bool t134;
			if (g->Call(ctx,(PCV[]){t134.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t134.get())) goto _28;
		}
		{
			Obj t135;
			c.f.fLine=131;
			if (g->Call(ctx,(PCV[]){t135.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t135.get();
		}
		{
			Variant t136;
			c.f.fLine=132;
			if (!g->GetValue(ctx,(PCV[]){t136.cv(),ltGroup.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loItem.cv(),KGroup.cv(),t136.cv())) goto _0;
		}
		c.f.fLine=133;
		if (g->Call(ctx,(PCV[]){nullptr,lcolItems.cv(),Kpush.cv(),loItem.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _27;
_28:
		{
			Obj t137;
			l__4D__auto__iter__0=t137.get();
		}
		{
			Obj t138;
			c.f.fLine=136;
			if (g->Call(ctx,(PCV[]){t138.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t138.get();
		}
		{
			Txt t139;
			t139=ltHiddenCols.get();
			Txt t140;
			t140=ltWidths.get();
			Txt t141;
			t141=ltHdrMap.get();
			Txt t142;
			t142=ltHeaders.get();
			Col t143;
			c.f.fLine=137;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t142.cv(),t141.cv(),t140.cv(),t139.cv()},t143.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t143.cv())) goto _0;
		}
		c.f.fLine=138;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),K.cv())) goto _0;
		c.f.fLine=139;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t144;
			c.f.fLine=140;
			if (g->Call(ctx,(PCV[]){t144.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t144.cv())) goto _0;
		}
		{
			Variant t145;
			c.f.fLine=141;
			if (g->Call(ctx,(PCV[]){t145.cv(),lcolItems.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t145.cv())) goto _0;
		}
		{
			Bool t146;
			t146=Bool(1).get();
			c.f.fLine=142;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t146.cv())) goto _0;
		}
		{
			Variant t147;
			c.f.fLine=144;
			if (g->Call(ctx,(PCV[]){t147.cv(),lcolItems.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t148;
			if (g->OperationOnAny(ctx,5,t147.cv(),Num(0).cv(),t148.cv())) goto _0;
			if (!(t148.get())) goto _29;
		}
		{
			Obj t149;
			t149=loListItems.get();
			Col t150;
			c.f.fLine=145;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t149.cv()},t150.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t150.get();
		}
		{
			Variant t151;
			c.f.fLine=146;
			if (g->Call(ctx,(PCV[]){t151.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t152;
			if (g->OperationOnAny(ctx,6,t151.cv(),Num(1).cv(),t152.cv())) goto _0;
			if (!(t152.get())) goto _30;
		}
		{
			Obj t153;
			c.f.fLine=147;
			if (g->Call(ctx,(PCV[]){t153.cv()},0,1466)) goto _0;
			Variant t154;
			if (g->GetMember(ctx,t153.cv(),KeDBQuery.cv(),t154.cv())) goto _0;
			Variant t155;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t155.cv())) goto _0;
			Variant t156;
			if (g->GetMember(ctx,t155.cv(),KGroup.cv(),t156.cv())) goto _0;
			if (g->SetMember(ctx,t154.cv(),KGroup.cv(),t156.cv())) goto _0;
		}
_30:
		goto _31;
_29:
		c.f.fLine=151;
		if (g->Call(ctx,(PCV[]){nullptr,kifRyNcfJ4tA.cv()},1,41)) goto _0;
		g->Check(ctx);
_31:
		goto _6;
_26:
		{
			Variant t157;
			c.f.fLine=155;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t157.cv())) goto _0;
			Bool t158;
			if (g->OperationOnAny(ctx,6,t157.cv(),kLGJAiSueMjo.cv(),t158.cv())) goto _0;
			if (!(t158.get())) goto _32;
		}
		{
			Col t159;
			c.f.fLine=160;
			if (g->Call(ctx,(PCV[]){t159.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolItems=t159.get();
		}
		{
			Col t160;
			c.f.fLine=161;
			if (g->Call(ctx,(PCV[]){t160.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolGroups=t160.get();
		}
		ltHdrMap=KCategory.get();
		ltHeaders=KCategory.get();
		ltWidths=K300.get();
		ltHiddenCols=K.get();
		{
			Obj t161;
			c.f.fLine=168;
			if (g->Call(ctx,(PCV[]){t161.cv()},0,1482)) goto _0;
			Variant t162;
			if (g->Call(ctx,(PCV[]){t162.cv(),t161.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t163;
			if (g->Call(ctx,(PCV[]){t163.cv(),t162.cv(),Kquery.cv(),KCreatedBy_20_3D_20_3A1.cv(),KUSER.cv()},4,1498)) goto _0;
			Variant t164;
			if (g->Call(ctx,(PCV[]){t164.cv(),t163.cv(),Kdistinct.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			Col t165;
			if (!g->GetValue(ctx,(PCV[]){t165.cv(),t164.cv(),nullptr})) goto _0;
			lcolCategories=t165.get();
		}
		{
			Ref t166;
			c.f.fLine=170;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t166.cv(),ltCategory.cv(),nullptr})) goto _0;
			Obj t167;
			if (g->Call(ctx,(PCV[]){t167.cv(),t166.cv(),lcolCategories.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t167.get();
		}
_33:
		{
			Bool t168;
			if (g->Call(ctx,(PCV[]){t168.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t168.get())) goto _34;
		}
		{
			Obj t169;
			c.f.fLine=171;
			if (g->Call(ctx,(PCV[]){t169.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t169.get();
		}
		{
			Variant t170;
			c.f.fLine=172;
			if (!g->GetValue(ctx,(PCV[]){t170.cv(),ltCategory.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loItem.cv(),KCategory.cv(),t170.cv())) goto _0;
		}
		c.f.fLine=173;
		if (g->Call(ctx,(PCV[]){nullptr,lcolItems.cv(),Kpush.cv(),loItem.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _33;
_34:
		{
			Obj t171;
			l__4D__auto__iter__1=t171.get();
		}
		{
			Obj t172;
			c.f.fLine=176;
			if (g->Call(ctx,(PCV[]){t172.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t172.get();
		}
		{
			Txt t173;
			t173=ltHiddenCols.get();
			Txt t174;
			t174=ltWidths.get();
			Txt t175;
			t175=ltHdrMap.get();
			Txt t176;
			t176=ltHeaders.get();
			Col t177;
			c.f.fLine=177;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t176.cv(),t175.cv(),t174.cv(),t173.cv()},t177.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t177.cv())) goto _0;
		}
		c.f.fLine=178;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),K.cv())) goto _0;
		c.f.fLine=179;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t178;
			c.f.fLine=180;
			if (g->Call(ctx,(PCV[]){t178.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t178.cv())) goto _0;
		}
		{
			Variant t179;
			c.f.fLine=181;
			if (g->Call(ctx,(PCV[]){t179.cv(),lcolItems.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t179.cv())) goto _0;
		}
		{
			Bool t180;
			t180=Bool(1).get();
			c.f.fLine=182;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t180.cv())) goto _0;
		}
		{
			Variant t181;
			c.f.fLine=184;
			if (g->Call(ctx,(PCV[]){t181.cv(),lcolItems.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t182;
			if (g->OperationOnAny(ctx,5,t181.cv(),Num(0).cv(),t182.cv())) goto _0;
			if (!(t182.get())) goto _35;
		}
		{
			Obj t183;
			t183=loListItems.get();
			Col t184;
			c.f.fLine=185;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t183.cv()},t184.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t184.get();
		}
		{
			Variant t185;
			c.f.fLine=186;
			if (g->Call(ctx,(PCV[]){t185.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t186;
			if (g->OperationOnAny(ctx,6,t185.cv(),Num(1).cv(),t186.cv())) goto _0;
			if (!(t186.get())) goto _36;
		}
		{
			Obj t187;
			c.f.fLine=187;
			if (g->Call(ctx,(PCV[]){t187.cv()},0,1466)) goto _0;
			Variant t188;
			if (g->GetMember(ctx,t187.cv(),KeDBQuery.cv(),t188.cv())) goto _0;
			Variant t189;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t189.cv())) goto _0;
			Variant t190;
			if (g->GetMember(ctx,t189.cv(),KCategory.cv(),t190.cv())) goto _0;
			if (g->SetMember(ctx,t188.cv(),KCategory.cv(),t190.cv())) goto _0;
		}
_36:
		goto _37;
_35:
		c.f.fLine=191;
		if (g->Call(ctx,(PCV[]){nullptr,ko166k_hFrHs.cv()},1,41)) goto _0;
		g->Check(ctx);
_37:
		goto _6;
_32:
_6:
_5:
_0:
_1:
;
	}

}
