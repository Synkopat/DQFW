extern Txt K150_2C300;
extern Txt K300_2C100;
extern Txt K300_2C100_2C0;
extern Txt KAlias_2CAttribute;
extern Txt KAttribute;
extern Txt KComparisonOps;
extern Txt KDBAliases;
extern Txt KLogicOps;
extern Txt KObjectName;
extern Txt KObjectType_20_3D_20_3A1;
extern Txt KSingle;
extern Txt KbAutoComplete;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt KcolOperators;
extern Txt Kcopy;
extern Txt Klength;
extern Txt KoLogicOperators;
extern Txt Kquery;
extern Txt KtFormHeader;
extern Txt KtOperator;
extern Txt KtSelectionMode;
extern Txt KtoCollection;
extern Txt kIzdY4SXjrXA;
extern Txt kK0xZCxy7G4Y;
extern Txt kME8WkbwCo5U;
extern Txt kWs_Sv0eaXFo;
extern Txt kcshqzox9NQc;
extern Txt kdWqu0dBKCLQ;
extern Txt kiHFsVAYKZIQ;
extern Txt klQq_$TIrnvA;
extern Txt krAvNTkjyYAg;
Asm4d_Proc proc_WDGT__CONFIGCOLUMNS;
Asm4d_Proc proc_WDGT__SELECT;
extern unsigned char D_proc_DQFW__QUERYFORMLBXSELECT[];
void proc_DQFW__QUERYFORMLBXSELECT( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__QUERYFORMLBXSELECT);
	if (!ctx->doingAbort) {
		Obj loItem;
		Txt ltHeaders;
		Col lcolItems;
		Txt ltCompOpList;
		Txt ltSrch;
		Bool lbAcceptWildcard;
		Col lcolUserSelection;
		Bool lJCPEREZ__20241102;
		Txt ltHiddenCols;
		Obj loListItems;
		Txt ltListName;
		Txt ltHdrMap;
		Txt ltWidths;
		new ( outResult) Obj();
		c.f.fLine=17;
		ltListName=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=18;
		ltSrch=Parm<Txt>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		lbAcceptWildcard=Bool(0).get();
		{
			Obj t0;
			c.f.fLine=20;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t0.get();
		}
		{
			Long t1;
			t1=inNbExplicitParam;
			if (3>t1.get()) goto _2;
		}
		c.f.fLine=23;
		lbAcceptWildcard=Parm<Bool>(ctx,inParams,inNbParam,3).get();
		if (ctx->doingAbort) goto _0;
_2:
		{
			Col t3;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t3.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolItems=t3.get();
		}
		{
			Bool t4;
			t4=g->CompareString(ctx,ltListName.get(),KComparisonOps.get())==0;
			if (!(t4.get())) goto _4;
		}
		ltHdrMap=kdWqu0dBKCLQ.get();
		ltHeaders=kME8WkbwCo5U.get();
		ltWidths=K300_2C100_2C0.get();
		ltHiddenCols=klQq_$TIrnvA.get();
		{
			Obj t5;
			c.f.fLine=39;
			if (g->Call(ctx,(PCV[]){t5.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t6;
			if (g->GetMember(ctx,t5.cv(),kK0xZCxy7G4Y.cv(),t6.cv())) goto _0;
			Variant t7;
			if (g->GetMember(ctx,t6.cv(),KcolOperators.cv(),t7.cv())) goto _0;
			Col t8;
			if (!g->GetValue(ctx,(PCV[]){t8.cv(),t7.cv(),nullptr})) goto _0;
			lcolItems=t8.get();
		}
		goto _3;
_4:
		{
			Bool t9;
			t9=g->CompareString(ctx,ltListName.get(),KLogicOps.get())==0;
			if (!(t9.get())) goto _5;
		}
		ltHdrMap=kcshqzox9NQc.get();
		ltHeaders=kIzdY4SXjrXA.get();
		ltWidths=K300_2C100.get();
		ltHiddenCols=KtOperator.get();
		{
			Obj t10;
			c.f.fLine=47;
			if (g->Call(ctx,(PCV[]){t10.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t11;
			if (g->GetMember(ctx,t10.cv(),KoLogicOperators.cv(),t11.cv())) goto _0;
			Variant t12;
			if (g->GetMember(ctx,t11.cv(),KcolOperators.cv(),t12.cv())) goto _0;
			Col t13;
			if (!g->GetValue(ctx,(PCV[]){t13.cv(),t12.cv(),nullptr})) goto _0;
			lcolItems=t13.get();
		}
		goto _3;
_5:
		ltHdrMap=kWs_Sv0eaXFo.get();
		ltHeaders=KAlias_2CAttribute.get();
		ltWidths=K150_2C300.get();
		ltHiddenCols=KObjectName.get();
		{
			Obj t14;
			c.f.fLine=57;
			if (g->Call(ctx,(PCV[]){t14.cv()},0,1482)) goto _0;
			Variant t15;
			if (g->Call(ctx,(PCV[]){t15.cv(),t14.cv(),KDBAliases.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t16;
			g->AddString(KObjectType_20_3D_20_3A1.get(),krAvNTkjyYAg.get(),t16.get());
			Variant t17;
			if (g->Call(ctx,(PCV[]){t17.cv(),t15.cv(),Kquery.cv(),t16.cv(),KAttribute.cv(),ltListName.cv()},5,1498)) goto _0;
			Variant t18;
			if (g->Call(ctx,(PCV[]){t18.cv(),t17.cv(),KtoCollection.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			Col t19;
			if (!g->GetValue(ctx,(PCV[]){t19.cv(),t18.cv(),nullptr})) goto _0;
			lcolItems=t19.get();
		}
_3:
		{
			Obj t20;
			c.f.fLine=61;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t20.get();
		}
		{
			Txt t21;
			t21=ltHiddenCols.get();
			Txt t22;
			t22=ltWidths.get();
			Txt t23;
			t23=ltHdrMap.get();
			Txt t24;
			t24=ltHeaders.get();
			Col t25;
			c.f.fLine=62;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t24.cv(),t23.cv(),t22.cv(),t21.cv()},t25.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t25.cv())) goto _0;
		}
		c.f.fLine=63;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),ltSrch.cv())) goto _0;
		c.f.fLine=64;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t26;
			c.f.fLine=65;
			if (g->Call(ctx,(PCV[]){t26.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t26.cv())) goto _0;
		}
		{
			Variant t27;
			c.f.fLine=66;
			if (g->Call(ctx,(PCV[]){t27.cv(),lcolItems.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t27.cv())) goto _0;
		}
		{
			Bool t28;
			t28=Bool(1).get();
			c.f.fLine=67;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t28.cv())) goto _0;
		}
		{
			Variant t29;
			c.f.fLine=68;
			if (g->Call(ctx,(PCV[]){t29.cv(),lcolItems.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t30;
			if (g->OperationOnAny(ctx,5,t29.cv(),Num(0).cv(),t30.cv())) goto _0;
			if (!(t30.get())) goto _6;
		}
		{
			Obj t31;
			t31=loListItems.get();
			Col t32;
			c.f.fLine=69;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t31.cv()},t32.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t32.get();
		}
		{
			Variant t33;
			c.f.fLine=70;
			if (g->Call(ctx,(PCV[]){t33.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t34;
			if (g->OperationOnAny(ctx,6,t33.cv(),Num(1).cv(),t34.cv())) goto _0;
			if (!(t34.get())) goto _7;
		}
		{
			Variant t35;
			c.f.fLine=71;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t35.cv())) goto _0;
			Obj t36;
			if (!g->GetValue(ctx,(PCV[]){t36.cv(),t35.cv(),nullptr})) goto _0;
			loItem=t36.get();
		}
_7:
		goto _8;
_6:
		{
			Txt t37;
			g->AddString(ltListName.get(),kiHFsVAYKZIQ.get(),t37.get());
			c.f.fLine=75;
			if (g->Call(ctx,(PCV[]){nullptr,t37.cv()},1,41)) goto _0;
			g->Check(ctx);
		}
_8:
		c.f.fLine=79;
		Res<Obj>(outResult)=loItem.get();
_0:
_1:
;
	}

}
