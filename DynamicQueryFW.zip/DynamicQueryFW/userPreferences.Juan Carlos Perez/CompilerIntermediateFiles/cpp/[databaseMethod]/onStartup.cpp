Asm4d_Proc proc_DQFW__INITLISTS;
Asm4d_Proc proc_DQFW__INITRECENTQUERIES;
extern unsigned char D_db_1[];
void db_1( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_db_1);
	if (!ctx->doingAbort) {
		c.f.fLine=1;
		proc_DQFW__INITRECENTQUERIES(glob,ctx,0,0,nullptr,nullptr);
		if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
		if (ctx->doingAbort) goto _0;
		c.f.fLine=2;
		proc_DQFW__INITLISTS(glob,ctx,0,0,nullptr,nullptr);
		if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
		if (ctx->doingAbort) goto _0;
_0:
_1:
;
	}

}
