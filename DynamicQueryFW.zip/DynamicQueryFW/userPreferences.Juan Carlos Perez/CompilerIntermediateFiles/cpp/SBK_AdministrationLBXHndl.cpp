extern Txt KDBQueries;
extern Txt KQryLines;
extern Txt KUI__SEARCH;
extern Txt Kcode;
extern Txt KcolQryLines;
extern Txt KesSystems;
extern Txt Kfirst;
extern Txt KiHdrLineIndx;
extern Txt KlbSystemLines;
extern Txt KoHdrLine;
extern Txt KoObject;
extern Txt KobjectName;
extern Txt Kpush;
extern Txt KqryLines;
extern Txt Kquery;
extern Txt kVMWRzE2WNPY;
extern Txt kkhHWtXAdhMw;
extern Txt ku2OcsofPKtU;
Asm4d_Proc proc_UTIL__PARSEJSONSTR;
extern unsigned char D_proc_SBK__ADMINISTRATIONLBXHNDL[];
void proc_SBK__ADMINISTRATIONLBXHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__ADMINISTRATIONLBXHNDL);
	if (!ctx->doingAbort) {
		Txt ltObjectString;
		Long liLines;
		Obj loNewBlankQuery;
		Obj leSystemCurrentLine;
		Obj ltoFormEvent;
		Obj loFormEvent;
		Obj leSystemFirst;
		Bool lVICENTE__20241102a;
		Bool lJCPEREZ__20241102;
		c.f.fLine=11;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=13;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t0.cv())) goto _0;
			Bool t1;
			if (g->OperationOnAny(ctx,7,t0.cv(),Value_null().cv(),t1.cv())) goto _0;
			if (!(t1.get())) goto _2;
		}
		{
			Variant t2;
			c.f.fLine=15;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t2.cv())) goto _0;
			Bool t3;
			if (g->OperationOnAny(ctx,6,t2.cv(),KlbSystemLines.cv(),t3.cv())) goto _0;
			if (!(t3.get())) goto _4;
		}
		{
			Variant t4;
			c.f.fLine=17;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t4.cv())) goto _0;
			Bool t5;
			if (g->OperationOnAny(ctx,6,t4.cv(),Long(4).cv(),t5.cv())) goto _0;
			Variant t6;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t6.cv())) goto _0;
			Bool t7;
			if (g->OperationOnAny(ctx,6,t6.cv(),Long(31).cv(),t7.cv())) goto _0;
			Bool t8;
			t8=t5.get()||t7.get();
			if (!(t8.get())) goto _6;
		}
		{
			Obj t9;
			c.f.fLine=20;
			if (g->Call(ctx,(PCV[]){t9.cv()},0,1466)) goto _0;
			Variant t10;
			if (g->GetMember(ctx,t9.cv(),KesSystems.cv(),t10.cv())) goto _0;
			Bool t11;
			if (g->OperationOnAny(ctx,7,t10.cv(),Value_null().cv(),t11.cv())) goto _0;
			if (!(t11.get())) goto _7;
		}
		{
			Obj t12;
			c.f.fLine=21;
			if (g->Call(ctx,(PCV[]){t12.cv()},0,1466)) goto _0;
			Variant t13;
			if (g->GetMember(ctx,t12.cv(),KoHdrLine.cv(),t13.cv())) goto _0;
			Obj t14;
			if (!g->GetValue(ctx,(PCV[]){t14.cv(),t13.cv(),nullptr})) goto _0;
			leSystemCurrentLine=t14.get();
		}
		{
			Obj t15;
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){t15.cv()},0,1466)) goto _0;
			Col t16;
			if (g->Call(ctx,(PCV[]){t16.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t15.cv(),KcolQryLines.cv(),t16.cv())) goto _0;
		}
		{
			Obj t17;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1466)) goto _0;
			Variant t18;
			if (g->GetMember(ctx,leSystemCurrentLine.cv(),KQryLines.cv(),t18.cv())) goto _0;
			Long t19;
			t19=38;
			Txt t20;
			if (!g->GetValue(ctx,(PCV[]){t20.cv(),t18.cv(),nullptr})) goto _0;
			Obj t21;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t20.cv(),t19.cv()},t21.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t22;
			if (g->GetMember(ctx,t21.cv(),KoObject.cv(),t22.cv())) goto _0;
			Variant t23;
			if (g->GetMember(ctx,t22.cv(),KqryLines.cv(),t23.cv())) goto _0;
			if (g->SetMember(ctx,t17.cv(),KcolQryLines.cv(),t23.cv())) goto _0;
		}
		{
			Obj t24;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1466)) goto _0;
			Variant t25;
			if (g->GetMember(ctx,t24.cv(),KcolQryLines.cv(),t25.cv())) goto _0;
			Bool t26;
			if (g->OperationOnAny(ctx,6,t25.cv(),Value_null().cv(),t26.cv())) goto _0;
			if (!(t26.get())) goto _8;
		}
		liLines=0;
		ltObjectString=ku2OcsofPKtU.get();
		{
			Long t27;
			t27=38;
			Txt t28;
			t28=ltObjectString.get();
			Obj t29;
			c.f.fLine=33;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t28.cv(),t27.cv()},t29.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t30;
			if (g->GetMember(ctx,t29.cv(),KoObject.cv(),t30.cv())) goto _0;
			Variant t31;
			if (g->GetMember(ctx,t30.cv(),KqryLines.cv(),t31.cv())) goto _0;
			Variant t32;
			if (g->GetMember(ctx,t31.cv(),Long(0).cv(),t32.cv())) goto _0;
			Obj t33;
			if (!g->GetValue(ctx,(PCV[]){t33.cv(),t32.cv(),nullptr})) goto _0;
			loNewBlankQuery=t33.get();
		}
		{
			Obj t34;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t34.cv()},0,1466)) goto _0;
			Col t35;
			if (g->Call(ctx,(PCV[]){t35.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t34.cv(),KcolQryLines.cv(),t35.cv())) goto _0;
		}
		{
			Obj t36;
			c.f.fLine=35;
			if (g->Call(ctx,(PCV[]){t36.cv()},0,1466)) goto _0;
			Variant t37;
			if (g->GetMember(ctx,t36.cv(),KcolQryLines.cv(),t37.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t37.cv(),Kpush.cv(),loNewBlankQuery.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_8:
		goto _9;
_7:
		{
			Obj t38;
			c.f.fLine=39;
			if (g->Call(ctx,(PCV[]){t38.cv()},0,1466)) goto _0;
			Variant t39;
			t39.setNull();
			if (g->SetMember(ctx,t38.cv(),KcolQryLines.cv(),t39.cv())) goto _0;
		}
_9:
		goto _5;
_6:
_5:
		goto _3;
_4:
_3:
		goto _10;
_2:
		{
			Obj t40;
			c.f.fLine=47;
			if (g->Call(ctx,(PCV[]){t40.cv()},0,1466)) goto _0;
			Obj t41;
			if (g->Call(ctx,(PCV[]){t41.cv()},0,1482)) goto _0;
			Variant t42;
			if (g->Call(ctx,(PCV[]){t42.cv(),t41.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Obj t43;
			if (g->Call(ctx,(PCV[]){t43.cv()},0,1466)) goto _0;
			Variant t44;
			if (g->GetMember(ctx,t43.cv(),kkhHWtXAdhMw.cv(),t44.cv())) goto _0;
			Variant t45;
			if (g->Call(ctx,(PCV[]){t45.cv(),t42.cv(),Kquery.cv(),kVMWRzE2WNPY.cv(),t44.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			if (g->SetMember(ctx,t40.cv(),KesSystems.cv(),t45.cv())) goto _0;
		}
		{
			Obj t46;
			c.f.fLine=49;
			if (g->Call(ctx,(PCV[]){t46.cv()},0,1466)) goto _0;
			Variant t47;
			if (g->GetMember(ctx,t46.cv(),KesSystems.cv(),t47.cv())) goto _0;
			Bool t48;
			if (g->OperationOnAny(ctx,7,t47.cv(),Value_null().cv(),t48.cv())) goto _0;
			if (!(t48.get())) goto _11;
		}
		{
			Obj t49;
			c.f.fLine=50;
			if (g->Call(ctx,(PCV[]){t49.cv()},0,1466)) goto _0;
			Variant t50;
			if (g->GetMember(ctx,t49.cv(),KesSystems.cv(),t50.cv())) goto _0;
			Variant t51;
			if (g->Call(ctx,(PCV[]){t51.cv(),t50.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t52;
			if (!g->GetValue(ctx,(PCV[]){t52.cv(),t51.cv(),nullptr})) goto _0;
			leSystemFirst=t52.get();
		}
		{
			Obj t53;
			c.f.fLine=51;
			if (g->Call(ctx,(PCV[]){t53.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t53.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		{
			Obj t54;
			c.f.fLine=52;
			if (g->Call(ctx,(PCV[]){t54.cv()},0,1466)) goto _0;
			Col t55;
			if (g->Call(ctx,(PCV[]){t55.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t54.cv(),KcolQryLines.cv(),t55.cv())) goto _0;
		}
		{
			Obj t56;
			c.f.fLine=53;
			if (g->Call(ctx,(PCV[]){t56.cv()},0,1466)) goto _0;
			Variant t57;
			if (g->GetMember(ctx,leSystemFirst.cv(),KQryLines.cv(),t57.cv())) goto _0;
			Long t58;
			t58=38;
			Txt t59;
			if (!g->GetValue(ctx,(PCV[]){t59.cv(),t57.cv(),nullptr})) goto _0;
			Obj t60;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t59.cv(),t58.cv()},t60.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t61;
			if (g->GetMember(ctx,t60.cv(),KoObject.cv(),t61.cv())) goto _0;
			Variant t62;
			if (g->GetMember(ctx,t61.cv(),KqryLines.cv(),t62.cv())) goto _0;
			if (g->SetMember(ctx,t56.cv(),KcolQryLines.cv(),t62.cv())) goto _0;
		}
		{
			Obj t63;
			c.f.fLine=55;
			if (g->Call(ctx,(PCV[]){t63.cv()},0,1466)) goto _0;
			Variant t64;
			if (g->GetMember(ctx,t63.cv(),KcolQryLines.cv(),t64.cv())) goto _0;
			Bool t65;
			if (g->OperationOnAny(ctx,6,t64.cv(),Value_null().cv(),t65.cv())) goto _0;
			if (!(t65.get())) goto _12;
		}
		liLines=0;
		ltObjectString=ku2OcsofPKtU.get();
		{
			Long t66;
			t66=38;
			Txt t67;
			t67=ltObjectString.get();
			Obj t68;
			c.f.fLine=63;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t67.cv(),t66.cv()},t68.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t69;
			if (g->GetMember(ctx,t68.cv(),KoObject.cv(),t69.cv())) goto _0;
			Variant t70;
			if (g->GetMember(ctx,t69.cv(),KqryLines.cv(),t70.cv())) goto _0;
			Variant t71;
			if (g->GetMember(ctx,t70.cv(),Long(0).cv(),t71.cv())) goto _0;
			Obj t72;
			if (!g->GetValue(ctx,(PCV[]){t72.cv(),t71.cv(),nullptr})) goto _0;
			loNewBlankQuery=t72.get();
		}
		{
			Obj t73;
			c.f.fLine=64;
			if (g->Call(ctx,(PCV[]){t73.cv()},0,1466)) goto _0;
			Col t74;
			if (g->Call(ctx,(PCV[]){t74.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t73.cv(),KcolQryLines.cv(),t74.cv())) goto _0;
		}
		{
			Obj t75;
			c.f.fLine=65;
			if (g->Call(ctx,(PCV[]){t75.cv()},0,1466)) goto _0;
			Variant t76;
			if (g->GetMember(ctx,t75.cv(),KcolQryLines.cv(),t76.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t76.cv(),Kpush.cv(),loNewBlankQuery.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_12:
		goto _13;
_11:
		{
			Obj t77;
			c.f.fLine=69;
			if (g->Call(ctx,(PCV[]){t77.cv()},0,1466)) goto _0;
			Variant t78;
			t78.setNull();
			if (g->SetMember(ctx,t77.cv(),KcolQryLines.cv(),t78.cv())) goto _0;
		}
_13:
_10:
_0:
_1:
;
	}

}
