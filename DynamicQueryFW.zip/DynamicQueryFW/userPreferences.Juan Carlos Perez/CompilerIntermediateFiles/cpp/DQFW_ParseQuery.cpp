extern Txt K_7C_40;
extern Txt Kattribute;
extern Txt Kattributes;
extern Txt Kextract;
extern Txt Kindices;
extern Txt Klength;
extern Txt KlogicOP;
extern Txt KlogicOPs;
extern Txt Koperator;
extern Txt Koperators;
extern Txt KqryValue;
extern Txt KqryValue_20_3D_20_3A1;
extern Txt KtoObject;
extern Txt Kvalues;
Asm4d_Proc proc_DQFW__GETQUERYOBJ;
extern unsigned char D_proc_DQFW__PARSEQUERY[];
void proc_DQFW__PARSEQUERY( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__PARSEQUERY);
	if (!ctx->doingAbort) {
		Long v0;
		Long v1;
		Long li;
		Bool lJCPEREZ__20230206a;
		Col lcolQryLines;
		Long liValueIndx;
		Obj loQuerySettings;
		Obj loQryLine;
		Obj loQueryRequest;
		Obj loRefGame;
		Txt ltRefAttribute;
		Col lcolAttrBasedParams;
		c.f.fLine=17;
		lcolQryLines=Parm<Col>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=18;
		loQuerySettings=Parm<Obj>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		{
			Long t0;
			t0=inNbExplicitParam;
			if (3>t0.get()) goto _2;
		}
		c.f.fLine=21;
		{
			Variant t2;
			if (g->Call(ctx,(PCV[]){t2.cv(),Parm<Obj>(ctx,inParams,inNbParam,3).cv(),KtoObject.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t3;
			if (!g->GetValue(ctx,(PCV[]){t3.cv(),t2.cv(),nullptr})) goto _0;
			loRefGame=t3.get();
		}
		if (ctx->doingAbort) goto _0;
_2:
		{
			Obj t4;
			c.f.fLine=29;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loQueryRequest=t4.get();
		}
		{
			Variant t5;
			c.f.fLine=31;
			if (g->Call(ctx,(PCV[]){t5.cv(),lcolQryLines.cv(),Kextract.cv(),Kattribute.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t5.cv())) goto _0;
		}
		{
			Variant t6;
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){t6.cv(),lcolQryLines.cv(),Kextract.cv(),KqryValue.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQueryRequest.cv(),Kvalues.cv(),t6.cv())) goto _0;
		}
		{
			Variant t7;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t7.cv(),lcolQryLines.cv(),Kextract.cv(),Koperator.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQueryRequest.cv(),Koperators.cv(),t7.cv())) goto _0;
		}
		{
			Variant t8;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t8.cv(),lcolQryLines.cv(),Kextract.cv(),KlogicOP.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQueryRequest.cv(),KlogicOPs.cv(),t8.cv())) goto _0;
		}
		{
			Variant t9;
			c.f.fLine=36;
			if (g->Call(ctx,(PCV[]){t9.cv(),lcolQryLines.cv(),Kindices.cv(),KqryValue_20_3D_20_3A1.cv(),K_7C_40.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Col t10;
			if (!g->GetValue(ctx,(PCV[]){t10.cv(),t9.cv(),nullptr})) goto _0;
			lcolAttrBasedParams=t10.get();
		}
		{
			Bool t11;
			c.f.fLine=38;
			if (g->Call(ctx,(PCV[]){t11.cv(),loRefGame.cv()},1,1297)) goto _0;
			g->Check(ctx);
			Bool t12;
			t12=t11.get();
			Bool t13;
			t13=!(t12.get());
			Variant t14;
			if (g->Call(ctx,(PCV[]){t14.cv(),lcolAttrBasedParams.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			Bool t15;
			if (g->OperationOnAny(ctx,5,t14.cv(),Num(0).cv(),t15.cv())) goto _0;
			Bool t16;
			t16=t13.get()&&t15.get();
			if (!(t16.get())) goto _3;
		}
		li=1;
		{
			Variant t17;
			c.f.fLine=39;
			if (g->Call(ctx,(PCV[]){t17.cv(),lcolAttrBasedParams.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Long t18;
			if (!g->GetValue(ctx,(PCV[]){t18.cv(),t17.cv(),nullptr})) goto _0;
			v0=t18.get();
		}
		goto _4;
_6:
		{
			Long t19;
			t19=li.get()-1;
			Variant t20;
			c.f.fLine=40;
			if (g->GetMember(ctx,lcolAttrBasedParams.cv(),t19.cv(),t20.cv())) goto _0;
			Long t21;
			if (!g->GetValue(ctx,(PCV[]){t21.cv(),t20.cv(),nullptr})) goto _0;
			liValueIndx=t21.get();
		}
		{
			Variant t22;
			c.f.fLine=41;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kvalues.cv(),t22.cv())) goto _0;
			Variant t23;
			if (g->GetMember(ctx,t22.cv(),liValueIndx.cv(),t23.cv())) goto _0;
			Txt t24;
			if (!g->GetValue(ctx,(PCV[]){t24.cv(),t23.cv(),nullptr})) goto _0;
			Variant t25;
			if (g->Call(ctx,(PCV[]){t25.cv(),t24.cv(),Long(2).cv()},2,12)) goto _0;
			Txt t26;
			if (!g->GetValue(ctx,(PCV[]){t26.cv(),t25.cv(),nullptr})) goto _0;
			ltRefAttribute=t26.get();
		}
		{
			Variant t27;
			c.f.fLine=42;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kvalues.cv(),t27.cv())) goto _0;
			Variant t28;
			if (g->GetMember(ctx,loRefGame.cv(),ltRefAttribute.cv(),t28.cv())) goto _0;
			if (g->SetMember(ctx,t27.cv(),liValueIndx.cv(),t28.cv())) goto _0;
		}
_5:
		li=li.get()+1;
_4:
		if (li.get()<=v0.get()) goto _6;
_7:
_3:
		{
			Obj t31;
			t31=loQuerySettings.get();
			Obj t32;
			t32=loQueryRequest.get();
			c.f.fLine=47;
			proc_DQFW__GETQUERYOBJ(glob,ctx,2,2,(PCV[]){t32.cv(),t31.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Variant t33;
			c.f.fLine=49;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t33.cv())) goto _0;
			if (g->SetMember(ctx,loQuerySettings.cv(),Kattributes.cv(),t33.cv())) goto _0;
		}
_0:
_1:
;
	}

}
