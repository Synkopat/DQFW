extern Txt KDBQueries;
extern Txt KID;
extern Txt KSBK__AddModify;
extern Txt KbSaveRecord;
extern Txt KeDBQuery;
extern Txt KiWinRef;
extern Txt Knew;
extern Txt Ksave;
extern Txt Ksuccess;
extern Txt KtFormHeader;
extern Txt k1$MufgeWnJs;
extern Txt kKF5$aMVUyGE;
Asm4d_Proc proc_UTIL__SETOBJVALUES;
Asm4d_Proc proc_WIND__OPENWINDOW;
extern unsigned char D_proc_SBK__ADDMODIFY[];
void proc_SBK__ADDMODIFY( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__ADDMODIFY);
	if (!ctx->doingAbort) {
		Bool lbSuccess;
		Obj leDBQuery;
		Txt ltForm;
		Long liFormHeight;
		Long liFormWidth;
		Obj loResults;
		Obj loSysBook;
		Bool lJCPEREZ__20241102;
		Variant loResult;
		Obj loDBQuery;
		new ( outResult) Obj();
		c.f.fLine=13;
		loSysBook=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		lbSuccess=Bool(0).get();
		ltForm=KSBK__AddModify.get();
		{
			Ref t0;
			t0.setLocalRef(ctx,liFormHeight.cv());
			Ref t1;
			t1.setLocalRef(ctx,liFormWidth.cv());
			c.f.fLine=20;
			if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),t1.cv(),t0.cv()},3,674)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t2;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loDBQuery=t2.get();
		}
		c.f.fLine=26;
		if (g->SetMember(ctx,loDBQuery.cv(),KtFormHeader.cv(),kKF5$aMVUyGE.cv())) goto _0;
		{
			Variant t3;
			c.f.fLine=29;
			if (g->GetMember(ctx,loSysBook.cv(),KID.cv(),t3.cv())) goto _0;
			Bool t4;
			if (g->OperationOnAny(ctx,7,t3.cv(),Value_null().cv(),t4.cv())) goto _0;
			if (!(t4.get())) goto _2;
		}
		c.f.fLine=30;
		if (g->SetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),loSysBook.cv())) goto _0;
		goto _3;
_2:
		{
			Obj t5;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t5.cv()},0,1482)) goto _0;
			Variant t6;
			if (g->Call(ctx,(PCV[]){t6.cv(),t5.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t7;
			if (g->Call(ctx,(PCV[]){t7.cv(),t6.cv(),Knew.cv()},2,1498)) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t7.cv())) goto _0;
		}
		{
			Variant t8;
			c.f.fLine=34;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t8.cv())) goto _0;
			Obj t9;
			t9=loSysBook.get();
			Obj t10;
			if (!g->GetValue(ctx,(PCV[]){t10.cv(),t8.cv(),nullptr})) goto _0;
			proc_UTIL__SETOBJVALUES(glob,ctx,2,2,(PCV[]){t10.cv(),t9.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
_3:
		{
			Ptr t11;
			Txt t12;
			t12=ltForm.get();
			Txt t13;
			t13=k1$MufgeWnJs.get();
			Long t14;
			t14=33;
			Long t15;
			t15=6;
			Long t16;
			t16=liFormHeight.get();
			Long t17;
			t17=liFormWidth.get();
			Long t18;
			c.f.fLine=38;
			proc_WIND__OPENWINDOW(glob,ctx,6,7,(PCV[]){t17.cv(),t16.cv(),t15.cv(),t14.cv(),t13.cv(),t12.cv(),t11.cv()},t18.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KiWinRef.cv(),t18.cv())) goto _0;
		}
		c.f.fLine=40;
		if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),loDBQuery.cv()},2,40)) goto _0;
		g->Check(ctx);
		{
			Variant t19;
			c.f.fLine=42;
			if (g->GetMember(ctx,loDBQuery.cv(),KbSaveRecord.cv(),t19.cv())) goto _0;
			Bool t20;
			if (!g->GetValue(ctx,(PCV[]){t20.cv(),t19.cv(),nullptr})) goto _0;
			if (!(t20.get())) goto _4;
		}
		{
			Variant t21;
			c.f.fLine=43;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t21.cv())) goto _0;
			Variant t22;
			if (g->Call(ctx,(PCV[]){t22.cv(),t21.cv(),Ksave.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (!g->SetValue(ctx,(PCV[]){t22.cv(),loResult.cv(),nullptr})) goto _0;
		}
		{
			Variant t23;
			c.f.fLine=44;
			if (!g->GetValue(ctx,(PCV[]){t23.cv(),loResult.cv(),nullptr})) goto _0;
			Variant t24;
			if (g->Call(ctx,(PCV[]){t24.cv(),t23.cv(),Ksuccess.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Bool t25;
			if (!g->GetValue(ctx,(PCV[]){t25.cv(),t24.cv(),nullptr})) goto _0;
			lbSuccess=t25.get();
		}
_4:
		{
			Obj t26;
			c.f.fLine=47;
			if (g->Call(ctx,(PCV[]){t26.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loResults=t26.get();
		}
		{
			Bool t27;
			t27=lbSuccess.get();
			c.f.fLine=48;
			if (g->SetMember(ctx,loResults.cv(),Ksuccess.cv(),t27.cv())) goto _0;
		}
		{
			Variant t28;
			c.f.fLine=49;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t28.cv())) goto _0;
			Variant t29;
			if (g->GetMember(ctx,t28.cv(),KID.cv(),t29.cv())) goto _0;
			if (g->SetMember(ctx,loResults.cv(),KID.cv(),t29.cv())) goto _0;
		}
		c.f.fLine=50;
		Res<Obj>(outResult)=loResults.get();
_0:
_1:
;
	}

}
