extern Txt KautoFilled;
extern Txt Kkind;
extern Txt KrelatedEntities;
extern Txt KrelatedEntity;
extern Txt Ksave;
extern unsigned char D_proc_UTIL__IMPORTENTITY[];
void proc_UTIL__IMPORTENTITY( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_UTIL__IMPORTENTITY);
	if (!ctx->doingAbort) {
		Bool lbAutoFilled;
		Long v0;
		Long v1;
		Long lt;
		Txt ltDataClass;
		Value_array_text latAttrs;
		Obj loEntity2Import;
		Obj leEntity2Update;
		Bool lJCPEREZ__20241102;
		Txt ltAttrKind;
		c.f.fLine=12;
		ltDataClass=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=13;
		leEntity2Update=Parm<Obj>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=14;
		loEntity2Import=Parm<Obj>(ctx,inParams,inNbParam,3).get();
		if (ctx->doingAbort) goto _0;
		{
			Ref t0;
			t0.setLocalRef(ctx,latAttrs.cv());
			c.f.fLine=16;
			if (g->Call(ctx,(PCV[]){nullptr,t0.cv(),Long(0).cv()},2,222)) goto _0;
		}
		{
			Ref t1;
			t1.setLocalRef(ctx,latAttrs.cv());
			c.f.fLine=21;
			if (g->Call(ctx,(PCV[]){nullptr,loEntity2Import.cv(),t1.cv()},2,1232)) goto _0;
			g->Check(ctx);
		}
		lt=1;
		{
			Ref t2;
			t2.setLocalRef(ctx,latAttrs.cv());
			Long t3;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t3.cv(),t2.cv()},1,274)) goto _0;
			v0=t3.get();
		}
		goto _2;
_4:
		{
			Obj t4;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1482)) goto _0;
			Variant t5;
			if (g->GetMember(ctx,t4.cv(),ltDataClass.cv(),t5.cv())) goto _0;
			Txt t6;
			t6=latAttrs.arrayElem(ctx,lt.get()).get();
			Txt t7;
			t7=t6.get();
			Variant t8;
			if (g->GetMember(ctx,t5.cv(),t7.cv(),t8.cv())) goto _0;
			Variant t9;
			if (g->GetMember(ctx,t8.cv(),Kkind.cv(),t9.cv())) goto _0;
			Txt t10;
			if (!g->GetValue(ctx,(PCV[]){t10.cv(),t9.cv(),nullptr})) goto _0;
			ltAttrKind=t10.get();
		}
		if (ctx->doingAbort) goto _0;
		{
			Obj t11;
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){t11.cv()},0,1482)) goto _0;
			Variant t12;
			if (g->GetMember(ctx,t11.cv(),ltDataClass.cv(),t12.cv())) goto _0;
			Txt t13;
			t13=latAttrs.arrayElem(ctx,lt.get()).get();
			Txt t14;
			t14=t13.get();
			Variant t15;
			if (g->GetMember(ctx,t12.cv(),t14.cv(),t15.cv())) goto _0;
			Variant t16;
			if (g->GetMember(ctx,t15.cv(),KautoFilled.cv(),t16.cv())) goto _0;
			Bool t17;
			if (!g->GetValue(ctx,(PCV[]){t17.cv(),t16.cv(),nullptr})) goto _0;
			lbAutoFilled=t17.get();
		}
		if (ctx->doingAbort) goto _0;
		{
			Bool t18;
			t18=g->CompareString(ctx,ltAttrKind.get(),KrelatedEntity.get())==0;
			if (!(t18.get())) goto _7;
		}
		goto _6;
_7:
		{
			Bool t19;
			t19=g->CompareString(ctx,ltAttrKind.get(),KrelatedEntities.get())==0;
			if (!(t19.get())) goto _8;
		}
		goto _6;
_8:
		if (!(lbAutoFilled.get())) goto _9;
		goto _6;
_9:
		{
			Txt t20;
			c.f.fLine=40;
			t20=latAttrs.arrayElem(ctx,lt.get()).get();
			Txt t21;
			t21=t20.get();
			Variant t22;
			if (g->GetMember(ctx,loEntity2Import.cv(),t21.cv(),t22.cv())) goto _0;
			Txt t23;
			t23=latAttrs.arrayElem(ctx,lt.get()).get();
			Txt t24;
			t24=t23.get();
			if (g->Call(ctx,(PCV[]){nullptr,leEntity2Update.cv(),t24.cv(),t22.cv()},3,1497)) goto _0;
			g->Check(ctx);
		}
		if (ctx->doingAbort) goto _0;
_6:
_3:
		lt=lt.get()+1;
_2:
		if (lt.get()<=v0.get()) goto _4;
_5:
		c.f.fLine=46;
		if (g->Call(ctx,(PCV[]){nullptr,leEntity2Update.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
_0:
_1:
;
	}

}
