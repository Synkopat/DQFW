extern Txt KAND;
extern Txt KAND_20_28;
extern Txt KAnd;
extern Txt KAnd_20_28;
extern Txt KContainis;
extern Txt KIs_20equal_20to;
extern Txt KIs_20greater_20than;
extern Txt KIs_20less_20than;
extern Txt KIs_20not_20equal_20to;
extern Txt KNONE;
extern Txt KOR;
extern Txt KOR_20_28;
extern Txt KOr;
extern Txt KOr_20_28;
extern Txt KSTART_2FEND;
extern Txt K_21_3D;
extern Txt K_23;
extern Txt K_29_20AND;
extern Txt K_29_20And;
extern Txt K_29_20OR;
extern Txt K_29_20Or;
extern Txt K_3C;
extern Txt K_3C_3D;
extern Txt K_3D;
extern Txt K_3D_3D;
extern Txt K_3E;
extern Txt K_3E_3D;
extern Txt KcolOperators;
extern Txt KoLogicOperators;
extern Txt Kpush;
extern Txt KtDisplayName;
extern Txt KtOperator;
extern Txt KtWildcard;
extern Txt kK0xZCxy7G4Y;
extern Txt kSQrkHbQsyew;
extern Txt kUYzHRa1RkIw;
extern Txt kt24wFY1HOc8;
extern unsigned char D_proc_DQFW__INITLISTS[];
void proc_DQFW__INITLISTS( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__INITLISTS);
	if (!ctx->doingAbort) {
		Obj loComparisonOperators;
		Obj loLogicOperators;
		Obj l__4D__auto__mutex__0;
		Bool lJCPEREZ__20241117;
		{
			Obj t0;
			c.f.fLine=13;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loLogicOperators=t0.get();
		}
		{
			Col t1;
			c.f.fLine=14;
			if (g->Call(ctx,(PCV[]){t1.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loLogicOperators.cv(),KcolOperators.cv(),t1.cv())) goto _0;
		}
		{
			Variant t2;
			c.f.fLine=15;
			if (g->GetMember(ctx,loLogicOperators.cv(),KcolOperators.cv(),t2.cv())) goto _0;
			Obj t3;
			if (g->Call(ctx,(PCV[]){t3.cv(),KtDisplayName.cv(),KAnd.cv(),KtOperator.cv(),KAND.cv()},4,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t2.cv(),Kpush.cv(),t3.cv()},3,1500)) goto _0;
		}
		{
			Variant t4;
			c.f.fLine=16;
			if (g->GetMember(ctx,loLogicOperators.cv(),KcolOperators.cv(),t4.cv())) goto _0;
			Obj t5;
			if (g->Call(ctx,(PCV[]){t5.cv(),KtDisplayName.cv(),KOr.cv(),KtOperator.cv(),KOR.cv()},4,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t4.cv(),Kpush.cv(),t5.cv()},3,1500)) goto _0;
		}
		{
			Variant t6;
			c.f.fLine=17;
			if (g->GetMember(ctx,loLogicOperators.cv(),KcolOperators.cv(),t6.cv())) goto _0;
			Obj t7;
			if (g->Call(ctx,(PCV[]){t7.cv(),KtDisplayName.cv(),K_29_20And.cv(),KtOperator.cv(),K_29_20AND.cv()},4,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t6.cv(),Kpush.cv(),t7.cv()},3,1500)) goto _0;
		}
		{
			Variant t8;
			c.f.fLine=18;
			if (g->GetMember(ctx,loLogicOperators.cv(),KcolOperators.cv(),t8.cv())) goto _0;
			Obj t9;
			if (g->Call(ctx,(PCV[]){t9.cv(),KtDisplayName.cv(),K_29_20Or.cv(),KtOperator.cv(),K_29_20OR.cv()},4,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t8.cv(),Kpush.cv(),t9.cv()},3,1500)) goto _0;
		}
		{
			Variant t10;
			c.f.fLine=19;
			if (g->GetMember(ctx,loLogicOperators.cv(),KcolOperators.cv(),t10.cv())) goto _0;
			Obj t11;
			if (g->Call(ctx,(PCV[]){t11.cv(),KtDisplayName.cv(),KAnd_20_28.cv(),KtOperator.cv(),KAND_20_28.cv()},4,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t10.cv(),Kpush.cv(),t11.cv()},3,1500)) goto _0;
		}
		{
			Variant t12;
			c.f.fLine=20;
			if (g->GetMember(ctx,loLogicOperators.cv(),KcolOperators.cv(),t12.cv())) goto _0;
			Obj t13;
			if (g->Call(ctx,(PCV[]){t13.cv(),KtDisplayName.cv(),KOr_20_28.cv(),KtOperator.cv(),KOR_20_28.cv()},4,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t12.cv(),Kpush.cv(),t13.cv()},3,1500)) goto _0;
		}
		{
			Obj t14;
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){t14.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loComparisonOperators=t14.get();
		}
		{
			Col t15;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t15.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t15.cv())) goto _0;
		}
		{
			Variant t16;
			c.f.fLine=24;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t16.cv())) goto _0;
			Obj t17;
			if (g->Call(ctx,(PCV[]){t17.cv(),KtDisplayName.cv(),KIs_20equal_20to.cv(),KtOperator.cv(),K_3D_3D.cv(),KtWildcard.cv(),KNONE.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t16.cv(),Kpush.cv(),t17.cv()},3,1500)) goto _0;
		}
		{
			Variant t18;
			c.f.fLine=25;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t18.cv())) goto _0;
			Obj t19;
			if (g->Call(ctx,(PCV[]){t19.cv(),KtDisplayName.cv(),KIs_20not_20equal_20to.cv(),KtOperator.cv(),K_21_3D.cv(),KtWildcard.cv(),KNONE.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t18.cv(),Kpush.cv(),t19.cv()},3,1500)) goto _0;
		}
		{
			Variant t20;
			c.f.fLine=26;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t20.cv())) goto _0;
			Obj t21;
			if (g->Call(ctx,(PCV[]){t21.cv(),KtDisplayName.cv(),KIs_20greater_20than.cv(),KtOperator.cv(),K_3E.cv(),KtWildcard.cv(),KNONE.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t20.cv(),Kpush.cv(),t21.cv()},3,1500)) goto _0;
		}
		{
			Variant t22;
			c.f.fLine=27;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t22.cv())) goto _0;
			Obj t23;
			if (g->Call(ctx,(PCV[]){t23.cv(),KtDisplayName.cv(),kSQrkHbQsyew.cv(),KtOperator.cv(),K_3E_3D.cv(),KtWildcard.cv(),KNONE.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t22.cv(),Kpush.cv(),t23.cv()},3,1500)) goto _0;
		}
		{
			Variant t24;
			c.f.fLine=28;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t24.cv())) goto _0;
			Obj t25;
			if (g->Call(ctx,(PCV[]){t25.cv(),KtDisplayName.cv(),KIs_20less_20than.cv(),KtOperator.cv(),K_3C.cv(),KtWildcard.cv(),KNONE.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t24.cv(),Kpush.cv(),t25.cv()},3,1500)) goto _0;
		}
		{
			Variant t26;
			c.f.fLine=29;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t26.cv())) goto _0;
			Obj t27;
			if (g->Call(ctx,(PCV[]){t27.cv(),KtDisplayName.cv(),kt24wFY1HOc8.cv(),KtOperator.cv(),K_3C_3D.cv(),KtWildcard.cv(),KNONE.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t26.cv(),Kpush.cv(),t27.cv()},3,1500)) goto _0;
		}
		{
			Variant t28;
			c.f.fLine=30;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t28.cv())) goto _0;
			Obj t29;
			if (g->Call(ctx,(PCV[]){t29.cv(),KtDisplayName.cv(),KContainis.cv(),KtOperator.cv(),K_3D.cv(),KtWildcard.cv(),KSTART_2FEND.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t28.cv(),Kpush.cv(),t29.cv()},3,1500)) goto _0;
		}
		{
			Variant t30;
			c.f.fLine=31;
			if (g->GetMember(ctx,loComparisonOperators.cv(),KcolOperators.cv(),t30.cv())) goto _0;
			Obj t31;
			if (g->Call(ctx,(PCV[]){t31.cv(),KtDisplayName.cv(),kUYzHRa1RkIw.cv(),KtOperator.cv(),K_23.cv(),KtWildcard.cv(),KSTART_2FEND.cv()},6,1471)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t30.cv(),Kpush.cv(),t31.cv()},3,1500)) goto _0;
		}
		{
			Obj t32;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t32.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t33;
			if (g->Call(ctx,(PCV[]){t33.cv(),t32.cv()},1,1529)) goto _0;
			l__4D__auto__mutex__0=t33.get();
		}
		{
			Obj t34;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t34.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t35;
			if (g->GetMember(ctx,t34.cv(),KoLogicOperators.cv(),t35.cv())) goto _0;
			Bool t36;
			if (g->OperationOnAny(ctx,6,t35.cv(),Value_null().cv(),t36.cv())) goto _0;
			if (!(t36.get())) goto _2;
		}
		{
			Obj t37;
			c.f.fLine=35;
			if (g->Call(ctx,(PCV[]){t37.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t38;
			if (g->Call(ctx,(PCV[]){t38.cv(),loLogicOperators.cv(),Long(16).cv()},2,1225)) goto _0;
			if (g->SetMember(ctx,t37.cv(),KoLogicOperators.cv(),t38.cv())) goto _0;
		}
_2:
		{
			Obj t39;
			c.f.fLine=38;
			if (g->Call(ctx,(PCV[]){t39.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t40;
			if (g->GetMember(ctx,t39.cv(),kK0xZCxy7G4Y.cv(),t40.cv())) goto _0;
			Bool t41;
			if (g->OperationOnAny(ctx,6,t40.cv(),Value_null().cv(),t41.cv())) goto _0;
			if (!(t41.get())) goto _3;
		}
		{
			Obj t42;
			c.f.fLine=39;
			if (g->Call(ctx,(PCV[]){t42.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t43;
			if (g->Call(ctx,(PCV[]){t43.cv(),loComparisonOperators.cv(),Long(16).cv()},2,1225)) goto _0;
			if (g->SetMember(ctx,t42.cv(),kK0xZCxy7G4Y.cv(),t43.cv())) goto _0;
		}
_3:
		{
			Obj t44;
			l__4D__auto__mutex__0=t44.get();
		}
_0:
_1:
;
	}

}
