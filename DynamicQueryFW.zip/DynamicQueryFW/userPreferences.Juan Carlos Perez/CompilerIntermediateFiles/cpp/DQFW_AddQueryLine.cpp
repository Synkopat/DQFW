extern Txt Kattributes;
extern Txt Klength;
extern Txt KlogicOPs;
extern Txt Koperators;
extern Txt Kpush;
extern Txt Kvalues;
extern unsigned char D_proc_DQFW__ADDQUERYLINE[];
void proc_DQFW__ADDQUERYLINE( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__ADDQUERYLINE);
	if (!ctx->doingAbort) {
		Col lcolQryLineDef;
		Bool lJCPEREZ__20241102;
		Obj loQryDef;
		c.f.fLine=15;
		loQryDef=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=16;
		lcolQryLineDef=Parm<Col>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=18;
			if (g->Call(ctx,(PCV[]){t0.cv(),lcolQryLineDef.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t1;
			if (g->OperationOnAny(ctx,6,t0.cv(),Num(4).cv(),t1.cv())) goto _0;
			if (!(t1.get())) goto _2;
		}
		{
			Variant t2;
			c.f.fLine=19;
			if (g->GetMember(ctx,loQryDef.cv(),Kattributes.cv(),t2.cv())) goto _0;
			Variant t3;
			if (g->GetMember(ctx,lcolQryLineDef.cv(),Long(0).cv(),t3.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t2.cv(),Kpush.cv(),t3.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t4;
			c.f.fLine=20;
			if (g->GetMember(ctx,loQryDef.cv(),KlogicOPs.cv(),t4.cv())) goto _0;
			Variant t5;
			if (g->GetMember(ctx,lcolQryLineDef.cv(),Long(1).cv(),t5.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t4.cv(),Kpush.cv(),t5.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t6;
			c.f.fLine=21;
			if (g->GetMember(ctx,loQryDef.cv(),Koperators.cv(),t6.cv())) goto _0;
			Variant t7;
			if (g->GetMember(ctx,lcolQryLineDef.cv(),Long(2).cv(),t7.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t6.cv(),Kpush.cv(),t7.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t8;
			c.f.fLine=22;
			if (g->GetMember(ctx,loQryDef.cv(),Kvalues.cv(),t8.cv())) goto _0;
			Variant t9;
			if (g->GetMember(ctx,lcolQryLineDef.cv(),Long(3).cv(),t9.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t8.cv(),Kpush.cv(),t9.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_2:
_0:
_1:
;
	}

}
