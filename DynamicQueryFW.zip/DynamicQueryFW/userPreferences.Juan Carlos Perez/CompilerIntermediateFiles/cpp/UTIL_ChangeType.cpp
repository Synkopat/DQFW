extern Txt K;
extern Txt Kpush;
extern unsigned char D_proc_UTIL__CHANGETYPE[];
void proc_UTIL__CHANGETYPE( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_UTIL__CHANGETYPE);
	if (!ctx->doingAbort) {
		Variant lvValue;
		Variant lvValueIfTrue;
		Long liVarType;
		Long liType;
		Variant lvChangedValue;
		Bool lJCPEREZ__20241102;
		new ( outResult) Variant();
		{
			Variant t0;
			c.f.fLine=18;
			if (!g->GetValue(ctx,(PCV[]){t0.cv(),Parm<Variant>(ctx,inParams,inNbParam,1).cv(),nullptr})) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t0.cv(),lvValue.cv(),nullptr})) goto _0;
		}
		if (ctx->doingAbort) goto _0;
		c.f.fLine=19;
		liVarType=Parm<Long>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		{
			Txt t1;
			t1=K.get();
			c.f.fLine=20;
			if (!g->SetValue(ctx,(PCV[]){t1.cv(),lvValueIfTrue.cv(),nullptr})) goto _0;
		}
		{
			Txt t2;
			t2=K.get();
			c.f.fLine=21;
			if (!g->SetValue(ctx,(PCV[]){t2.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
		{
			Long t3;
			t3=inNbExplicitParam;
			if (3>t3.get()) goto _2;
		}
		{
			Variant t5;
			c.f.fLine=23;
			if (!g->GetValue(ctx,(PCV[]){t5.cv(),Parm<Variant>(ctx,inParams,inNbParam,3).cv(),nullptr})) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t5.cv(),lvValueIfTrue.cv(),nullptr})) goto _0;
		}
		if (ctx->doingAbort) goto _0;
_2:
		{
			Ref t6;
			c.f.fLine=26;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t6.cv(),lvValue.cv(),nullptr})) goto _0;
			Long t7;
			if (g->Call(ctx,(PCV[]){t7.cv(),t6.cv()},1,295)) goto _0;
			liType=t7.get();
		}
		if (liType.get()==liVarType.get()) goto _3;
		{
			Bool t9;
			t9=2==liVarType.get();
			Bool t10;
			t10=0==liVarType.get();
			Bool t11;
			t11=t9.get()||t10.get();
			Bool t12;
			t12=24==liVarType.get();
			if (!( t11.get()||t12.get())) goto _5;
		}
		{
			Variant t14;
			c.f.fLine=30;
			if (!g->GetValue(ctx,(PCV[]){t14.cv(),lvValue.cv(),nullptr})) goto _0;
			Txt t15;
			if (g->Call(ctx,(PCV[]){t15.cv(),t14.cv()},1,10)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t15.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
		goto _4;
_5:
		{
			Bool t16;
			t16=9==liVarType.get();
			Bool t17;
			t17=8==liVarType.get();
			Bool t18;
			t18=t16.get()||t17.get();
			Bool t19;
			t19=25==liVarType.get();
			Bool t20;
			t20=t18.get()||t19.get();
			Bool t21;
			t21=1==liVarType.get();
			if (!( t20.get()||t21.get())) goto _6;
		}
		{
			Variant t23;
			c.f.fLine=33;
			if (!g->GetValue(ctx,(PCV[]){t23.cv(),lvValue.cv(),nullptr})) goto _0;
			Num t24;
			if (g->Call(ctx,(PCV[]){t24.cv(),t23.cv()},1,11)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t24.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
		goto _4;
_6:
		if (4!=liVarType.get()) goto _7;
		{
			Variant t26;
			c.f.fLine=36;
			if (!g->GetValue(ctx,(PCV[]){t26.cv(),lvValue.cv(),nullptr})) goto _0;
			Date t27;
			if (g->Call(ctx,(PCV[]){t27.cv(),t26.cv()},1,102)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t27.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
		goto _4;
_7:
		if (11!=liVarType.get()) goto _8;
		{
			Variant t29;
			c.f.fLine=39;
			if (!g->GetValue(ctx,(PCV[]){t29.cv(),lvValue.cv(),nullptr})) goto _0;
			Time t30;
			if (g->Call(ctx,(PCV[]){t30.cv(),t29.cv()},1,179)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t30.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
		goto _4;
_8:
		if (6!=liVarType.get()) goto _9;
		c.f.fLine=43;
		if (!g->SetValue(ctx,(PCV[]){Bool(0).cv(),lvChangedValue.cv(),nullptr})) goto _0;
		{
			Ref t32;
			c.f.fLine=44;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t32.cv(),lvValue.cv(),nullptr})) goto _0;
			Long t33;
			if (g->Call(ctx,(PCV[]){t33.cv(),t32.cv()},1,295)) goto _0;
			Ref t34;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t34.cv(),lvValueIfTrue.cv(),nullptr})) goto _0;
			Long t35;
			if (g->Call(ctx,(PCV[]){t35.cv(),t34.cv()},1,295)) goto _0;
			if (t33.get()!=t35.get()) goto _10;
		}
		{
			Variant t37;
			c.f.fLine=45;
			if (!g->GetValue(ctx,(PCV[]){t37.cv(),lvValue.cv(),nullptr})) goto _0;
			Variant t38;
			if (!g->GetValue(ctx,(PCV[]){t38.cv(),lvValueIfTrue.cv(),nullptr})) goto _0;
			Bool t39;
			if (g->OperationOnAny(ctx,6,t37.cv(),t38.cv(),t39.cv())) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t39.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
_10:
		goto _4;
_9:
		if (42!=liVarType.get()) goto _11;
		{
			Col t41;
			c.f.fLine=49;
			if (g->Call(ctx,(PCV[]){t41.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (!g->SetValue(ctx,(PCV[]){t41.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
		{
			Variant t42;
			c.f.fLine=50;
			if (!g->GetValue(ctx,(PCV[]){t42.cv(),lvValue.cv(),nullptr})) goto _0;
			Variant t43;
			if (!g->GetValue(ctx,(PCV[]){t43.cv(),lvChangedValue.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t43.cv(),Kpush.cv(),t42.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		goto _4;
_11:
		{
			Variant t44;
			c.f.fLine=53;
			if (!g->GetValue(ctx,(PCV[]){t44.cv(),lvValue.cv(),nullptr})) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t44.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
_4:
		goto _12;
_3:
		{
			Variant t45;
			c.f.fLine=58;
			if (!g->GetValue(ctx,(PCV[]){t45.cv(),lvValue.cv(),nullptr})) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t45.cv(),lvChangedValue.cv(),nullptr})) goto _0;
		}
_12:
		{
			Variant t46;
			c.f.fLine=62;
			if (!g->GetValue(ctx,(PCV[]){t46.cv(),lvChangedValue.cv(),nullptr})) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t46.cv(),Res<Variant>(outResult).cv(),nullptr})) goto _0;
		}
_0:
_1:
;
	}

}
