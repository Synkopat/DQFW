extern Txt K;
extern Txt K_2E;
extern Txt Kkind;
extern Txt Klength;
extern Txt Krelated_40;
extern Txt knVPnk6aYtd4;
Asm4d_Proc proc_UTIL__VALIDATEATTRNAME;
extern unsigned char D_proc_UTIL__VALIDATEATTRNAME[];
void proc_UTIL__VALIDATEATTRNAME( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_UTIL__VALIDATEATTRNAME);
	if (!ctx->doingAbort) {
		Long li;
		Txt ltValidAttrName;
		Long lr;
		Bool lbDefinesRelationship;
		Txt ltRelationAttr;
		Value_array_text latAttributes;
		Txt ltRelatedDataClass;
		Col lcolRelation;
		Txt ltRelAttrName;
		Variant ltRelationName;
		Obj loDataObject;
		Bool lJCPEREZ__20241102;
		Txt ltAttrName;
		new ( outResult) Txt();
		c.f.fLine=13;
		loDataObject=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=14;
		ltAttrName=Parm<Txt>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=15;
		ltValidAttrName=Res<Txt>(outResult).get();
		ltValidAttrName=K.get();
		{
			Ref t0;
			t0.setLocalRef(ctx,latAttributes.cv());
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){nullptr,t0.cv(),Long(0).cv()},2,222)) goto _0;
		}
		{
			Ref t1;
			t1.setLocalRef(ctx,latAttributes.cv());
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){nullptr,loDataObject.cv(),t1.cv()},2,1232)) goto _0;
			g->Check(ctx);
		}
		{
			Ref t2;
			t2.setLocalRef(ctx,latAttributes.cv());
			Long t3;
			c.f.fLine=27;
			if (g->Call(ctx,(PCV[]){t3.cv(),t2.cv(),ltAttrName.cv()},2,230)) goto _0;
			li=t3.get();
		}
		if (0>=li.get()) goto _2;
		c.f.fLine=30;
		ltValidAttrName=latAttributes.arrayElem(ctx,li.get()).get();
		if (ctx->doingAbort) goto _0;
		goto _3;
_2:
		{
			Col t6;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t6.cv(),ltAttrName.cv(),K_2E.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolRelation=t6.get();
		}
		{
			Variant t7;
			c.f.fLine=34;
			if (g->GetMember(ctx,lcolRelation.cv(),Klength.cv(),t7.cv())) goto _0;
			Bool t8;
			if (g->OperationOnAny(ctx,5,t7.cv(),Num(1).cv(),t8.cv())) goto _0;
			if (!(t8.get())) goto _4;
		}
		{
			Variant t9;
			c.f.fLine=35;
			if (g->GetMember(ctx,lcolRelation.cv(),Long(0).cv(),t9.cv())) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t9.cv(),ltRelationName.cv(),nullptr})) goto _0;
		}
		{
			Variant t10;
			c.f.fLine=36;
			if (g->GetMember(ctx,lcolRelation.cv(),Long(1).cv(),t10.cv())) goto _0;
			Txt t11;
			if (!g->GetValue(ctx,(PCV[]){t11.cv(),t10.cv(),nullptr})) goto _0;
			ltRelationAttr=t11.get();
		}
		{
			Variant t12;
			c.f.fLine=38;
			if (!g->GetValue(ctx,(PCV[]){t12.cv(),ltRelationName.cv(),nullptr})) goto _0;
			Ref t13;
			t13.setLocalRef(ctx,latAttributes.cv());
			Long t14;
			if (g->Call(ctx,(PCV[]){t14.cv(),t13.cv(),t12.cv()},2,230)) goto _0;
			lr=t14.get();
		}
		if (0>=lr.get()) goto _5;
		{
			Txt t16;
			c.f.fLine=41;
			t16=latAttributes.arrayElem(ctx,lr.get()).get();
			Txt t17;
			t17=t16.get();
			Variant t18;
			if (g->GetMember(ctx,loDataObject.cv(),t17.cv(),t18.cv())) goto _0;
			Variant t19;
			if (g->GetMember(ctx,t18.cv(),Kkind.cv(),t19.cv())) goto _0;
			Bool t20;
			if (g->OperationOnAny(ctx,6,t19.cv(),Krelated_40.cv(),t20.cv())) goto _0;
			lbDefinesRelationship=t20.get();
		}
		if (ctx->doingAbort) goto _0;
		if (!(lbDefinesRelationship.get())) goto _6;
		{
			Txt t21;
			c.f.fLine=44;
			t21=latAttributes.arrayElem(ctx,lr.get()).get();
			Txt t22;
			t22=t21.get();
			Variant t23;
			if (g->GetMember(ctx,loDataObject.cv(),t22.cv(),t23.cv())) goto _0;
			Variant t24;
			if (g->GetMember(ctx,t23.cv(),knVPnk6aYtd4.cv(),t24.cv())) goto _0;
			Txt t25;
			if (!g->GetValue(ctx,(PCV[]){t25.cv(),t24.cv(),nullptr})) goto _0;
			ltRelatedDataClass=t25.get();
		}
		if (ctx->doingAbort) goto _0;
		{
			Obj t26;
			c.f.fLine=45;
			if (g->Call(ctx,(PCV[]){t26.cv()},0,1482)) goto _0;
			Variant t27;
			if (g->GetMember(ctx,t26.cv(),ltRelatedDataClass.cv(),t27.cv())) goto _0;
			Txt t28;
			t28=ltRelationAttr.get();
			Obj t29;
			if (!g->GetValue(ctx,(PCV[]){t29.cv(),t27.cv(),nullptr})) goto _0;
			Txt t30;
			proc_UTIL__VALIDATEATTRNAME(glob,ctx,2,2,(PCV[]){t29.cv(),t28.cv()},t30.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			ltRelAttrName=t30.get();
		}
		{
			Bool t31;
			t31=g->CompareString(ctx,ltRelAttrName.get(),K.get())!=0;
			if (!(t31.get())) goto _7;
		}
		{
			Txt t32;
			c.f.fLine=47;
			t32=latAttributes.arrayElem(ctx,lr.get()).get();
			Txt t33;
			g->AddString(t32.get(),K_2E.get(),t33.get());
			g->AddString(t33.get(),ltRelAttrName.get(),ltValidAttrName.get());
		}
		if (ctx->doingAbort) goto _0;
_7:
_6:
_5:
_4:
_3:
		c.f.fLine=58;
		Res<Txt>(outResult)=ltValidAttrName.get();
_0:
_1:
;
	}

}
