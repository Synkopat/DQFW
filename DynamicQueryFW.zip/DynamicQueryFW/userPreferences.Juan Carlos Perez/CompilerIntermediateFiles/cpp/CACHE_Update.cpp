extern Txt Kclear;
extern Txt Kcombine;
Asm4d_Proc proc_UTIL__SETOBJVALUES;
extern unsigned char D_proc_CACHE__UPDATE[];
void proc_CACHE__UPDATE( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_CACHE__UPDATE);
	if (!ctx->doingAbort) {
		Variant lvValue;
		Obj lo;
		Txt ltAttrib;
		Long liType;
		Obj l__4D__auto__mutex__0;
		Bool lJCPEREZ__20241102;
		Obj l__4D__auto__mutex__1;
		Obj l__4D__auto__mutex__2;
		Obj l__4D__auto__mutex__3;
		c.f.fLine=16;
		ltAttrib=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=17;
			if (!g->GetValue(ctx,(PCV[]){t0.cv(),Parm<Variant>(ctx,inParams,inNbParam,2).cv(),nullptr})) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t0.cv(),lvValue.cv(),nullptr})) goto _0;
		}
		if (ctx->doingAbort) goto _0;
		c.f.fLine=18;
		liType=Parm<Long>(ctx,inParams,inNbParam,3).get();
		if (ctx->doingAbort) goto _0;
		if (42!=liType.get()) goto _3;
		{
			Obj t2;
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t3;
			if (g->Call(ctx,(PCV[]){t3.cv(),t2.cv()},1,1529)) goto _0;
			l__4D__auto__mutex__1=t3.get();
		}
		{
			Obj t4;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t5;
			if (g->GetMember(ctx,t4.cv(),ltAttrib.cv(),t5.cv())) goto _0;
			Bool t6;
			if (g->OperationOnAny(ctx,6,t5.cv(),Value_null().cv(),t6.cv())) goto _0;
			if (!(t6.get())) goto _4;
		}
		{
			Obj t7;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t7.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Col t8;
			if (g->Call(ctx,(PCV[]){t8.cv()},0,1527)) goto _0;
			if (g->SetMember(ctx,t7.cv(),ltAttrib.cv(),t8.cv())) goto _0;
		}
		goto _5;
_4:
		{
			Obj t9;
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){t9.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t10;
			if (g->Call(ctx,(PCV[]){t10.cv()},0,1525)) goto _0;
			Variant t11;
			if (g->GetMember(ctx,t10.cv(),ltAttrib.cv(),t11.cv())) goto _0;
			Variant t12;
			if (g->Call(ctx,(PCV[]){t12.cv(),t11.cv(),Kclear.cv()},2,1498)) goto _0;
			if (g->SetMember(ctx,t9.cv(),ltAttrib.cv(),t12.cv())) goto _0;
		}
_5:
		{
			Obj t13;
			c.f.fLine=28;
			if (g->Call(ctx,(PCV[]){t13.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t14;
			if (g->GetMember(ctx,t13.cv(),ltAttrib.cv(),t14.cv())) goto _0;
			Obj t15;
			if (g->Call(ctx,(PCV[]){t15.cv(),t14.cv()},1,1529)) goto _0;
			l__4D__auto__mutex__0=t15.get();
		}
		{
			Obj t16;
			c.f.fLine=29;
			if (g->Call(ctx,(PCV[]){t16.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t17;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1525)) goto _0;
			Variant t18;
			if (g->GetMember(ctx,t17.cv(),ltAttrib.cv(),t18.cv())) goto _0;
			Variant t19;
			if (!g->GetValue(ctx,(PCV[]){t19.cv(),lvValue.cv(),nullptr})) goto _0;
			Variant t20;
			if (g->Call(ctx,(PCV[]){t20.cv(),t18.cv(),Kcombine.cv(),t19.cv()},3,1498)) goto _0;
			if (g->SetMember(ctx,t16.cv(),ltAttrib.cv(),t20.cv())) goto _0;
		}
		{
			Obj t21;
			l__4D__auto__mutex__0=t21.get();
		}
		{
			Obj t22;
			l__4D__auto__mutex__1=t22.get();
		}
		goto _2;
_3:
		if (38!=liType.get()) goto _6;
		{
			Obj t24;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t25;
			if (g->GetMember(ctx,t24.cv(),ltAttrib.cv(),t25.cv())) goto _0;
			Bool t26;
			if (g->OperationOnAny(ctx,6,t25.cv(),Value_null().cv(),t26.cv())) goto _0;
			if (!(t26.get())) goto _7;
		}
		{
			Obj t27;
			c.f.fLine=35;
			if (g->Call(ctx,(PCV[]){t27.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t28;
			if (g->Call(ctx,(PCV[]){t28.cv(),t27.cv()},1,1529)) goto _0;
			l__4D__auto__mutex__2=t28.get();
		}
		{
			Obj t29;
			c.f.fLine=36;
			if (g->Call(ctx,(PCV[]){t29.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t30;
			if (g->Call(ctx,(PCV[]){t30.cv()},0,1526)) goto _0;
			if (g->SetMember(ctx,t29.cv(),ltAttrib.cv(),t30.cv())) goto _0;
		}
		{
			Obj t31;
			c.f.fLine=37;
			if (g->Call(ctx,(PCV[]){t31.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t32;
			if (g->GetMember(ctx,t31.cv(),ltAttrib.cv(),t32.cv())) goto _0;
			Obj t33;
			if (!g->GetValue(ctx,(PCV[]){t33.cv(),t32.cv(),nullptr})) goto _0;
			lo=t33.get();
		}
		{
			Obj t34;
			l__4D__auto__mutex__2=t34.get();
		}
		{
			Obj t35;
			c.f.fLine=40;
			if (g->Call(ctx,(PCV[]){t35.cv(),lo.cv()},1,1529)) goto _0;
			g->Check(ctx);
			l__4D__auto__mutex__3=t35.get();
		}
		{
			Obj t36;
			c.f.fLine=41;
			if (!g->GetValue(ctx,(PCV[]){t36.cv(),lvValue.cv(),nullptr})) goto _0;
			Obj t37;
			t37=lo.get();
			proc_UTIL__SETOBJVALUES(glob,ctx,2,2,(PCV[]){t37.cv(),t36.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Obj t38;
			l__4D__auto__mutex__3=t38.get();
		}
_7:
		goto _2;
_6:
_2:
_0:
_1:
;
	}

}
