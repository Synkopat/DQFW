extern Txt K;
extern Txt KSingle;
extern Txt K_20_3D_20_3A1;
extern Txt K_40;
extern Txt KbAutoComplete;
extern Txt KbUserSelected;
extern Txt KbttnSelect;
extern Txt Kcode;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt KcolOrigList;
extern Txt KlbItemListMulti;
extern Txt KlbItemList_40;
extern Txt Klength;
extern Txt KobjectName;
extern Txt Kpush;
extern Txt Kquery;
extern Txt KtFormHeader;
extern Txt KtName;
extern Txt KtSelectionMode;
extern Txt kCPE6gzua87w;
extern Txt kUUFh9UQqW4I;
extern Txt klQSV4ZoYWzw;
Asm4d_Proc proc_LBX__SETUP;
extern unsigned char D_proc_WDGT__SELECTOBJECTHNDL[];
void proc_WDGT__SELECTOBJECTHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_WDGT__SELECTOBJECTHNDL);
	if (!ctx->doingAbort) {
		Bool lbSuccess;
		Long liInsertPos;
		Obj ltoFormEvent;
		Obj loFormEvent;
		Txt ltEntry;
		Bool lJCPEREZ__20241102;
		c.f.fLine=13;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=15;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t0.cv())) goto _0;
			Bool t1;
			if (g->OperationOnAny(ctx,6,t0.cv(),Value_null().cv(),t1.cv())) goto _0;
			if (!(t1.get())) goto _2;
		}
		{
			Variant t2;
			c.f.fLine=19;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t2.cv())) goto _0;
			Bool t3;
			if (g->OperationOnAny(ctx,6,t2.cv(),Long(1).cv(),t3.cv())) goto _0;
			if (!(t3.get())) goto _4;
		}
		{
			Obj t4;
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1466)) goto _0;
			Variant t5;
			if (g->GetMember(ctx,t4.cv(),KtSelectionMode.cv(),t5.cv())) goto _0;
			Bool t6;
			if (g->OperationOnAny(ctx,6,t5.cv(),KSingle.cv(),t6.cv())) goto _0;
			if (!(t6.get())) goto _5;
		}
		{
			Obj t7;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t7.cv()},0,1466)) goto _0;
			Variant t8;
			if (g->GetMember(ctx,t7.cv(),KcolLBSetup.cv(),t8.cv())) goto _0;
			Col t9;
			if (!g->GetValue(ctx,(PCV[]){t9.cv(),t8.cv(),nullptr})) goto _0;
			Txt t10;
			t10=kUUFh9UQqW4I.get();
			Bool t11;
			proc_LBX__SETUP(glob,ctx,2,2,(PCV[]){t10.cv(),t9.cv()},t11.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lbSuccess=t11.get();
		}
		{
			Obj t12;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t12.cv()},0,1466)) goto _0;
			Obj t13;
			if (g->Call(ctx,(PCV[]){t13.cv()},0,1466)) goto _0;
			Variant t14;
			if (g->GetMember(ctx,t13.cv(),KcolListItems.cv(),t14.cv())) goto _0;
			if (g->SetMember(ctx,t12.cv(),KcolListItems.cv(),t14.cv())) goto _0;
		}
		{
			Obj t15;
			c.f.fLine=27;
			if (g->Call(ctx,(PCV[]){t15.cv()},0,1466)) goto _0;
			Variant t16;
			if (g->GetMember(ctx,t15.cv(),KbAutoComplete.cv(),t16.cv())) goto _0;
			Bool t17;
			if (!g->GetValue(ctx,(PCV[]){t17.cv(),t16.cv(),nullptr})) goto _0;
			if (!(t17.get())) goto _6;
		}
		{
			Obj t18;
			c.f.fLine=29;
			if (g->Call(ctx,(PCV[]){t18.cv()},0,1466)) goto _0;
			Obj t19;
			if (g->Call(ctx,(PCV[]){t19.cv()},0,1466)) goto _0;
			Variant t20;
			if (g->GetMember(ctx,t19.cv(),KcolListItems.cv(),t20.cv())) goto _0;
			if (g->SetMember(ctx,t18.cv(),KcolOrigList.cv(),t20.cv())) goto _0;
		}
		{
			Obj t21;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t21.cv()},0,1466)) goto _0;
			Obj t22;
			if (g->Call(ctx,(PCV[]){t22.cv()},0,1466)) goto _0;
			Variant t23;
			if (g->GetMember(ctx,t22.cv(),KcolListItems.cv(),t23.cv())) goto _0;
			Obj t24;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1466)) goto _0;
			Variant t25;
			if (g->GetMember(ctx,t24.cv(),KcolLBSetup.cv(),t25.cv())) goto _0;
			Variant t26;
			if (g->GetMember(ctx,t25.cv(),Long(0).cv(),t26.cv())) goto _0;
			Variant t27;
			if (g->GetMember(ctx,t26.cv(),KtName.cv(),t27.cv())) goto _0;
			Variant t28;
			if (g->OperationOnAny(ctx,0,t27.cv(),K_20_3D_20_3A1.cv(),t28.cv())) goto _0;
			Obj t29;
			if (g->Call(ctx,(PCV[]){t29.cv()},0,1466)) goto _0;
			Variant t30;
			if (g->GetMember(ctx,t29.cv(),KtFormHeader.cv(),t30.cv())) goto _0;
			Variant t31;
			if (g->OperationOnAny(ctx,0,t30.cv(),K_40.cv(),t31.cv())) goto _0;
			Variant t32;
			if (g->Call(ctx,(PCV[]){t32.cv(),t23.cv(),Kquery.cv(),t28.cv(),t31.cv()},4,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t21.cv(),KcolListItems.cv(),t32.cv())) goto _0;
		}
		{
			Bool t33;
			t33=Bool(1).get();
			c.f.fLine=31;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KtFormHeader.cv(),t33.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		{
			Bool t34;
			t34=Bool(1).get();
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KtFormHeader.cv(),t34.cv()},3,238)) goto _0;
			g->Check(ctx);
		}
		c.f.fLine=33;
		if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KtFormHeader.cv()},2,206)) goto _0;
		g->Check(ctx);
		{
			Obj t35;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t35.cv()},0,1466)) goto _0;
			Variant t36;
			if (g->GetMember(ctx,t35.cv(),KtFormHeader.cv(),t36.cv())) goto _0;
			Txt t37;
			if (!g->GetValue(ctx,(PCV[]){t37.cv(),t36.cv(),nullptr})) goto _0;
			Long t38;
			t38=t37.get().fLength;
			liInsertPos=t38.get()+1;
		}
		c.f.fLine=35;
		if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KtFormHeader.cv(),liInsertPos.cv(),liInsertPos.cv()},4,210)) goto _0;
		g->Check(ctx);
_6:
		c.f.fLine=38;
		if (g->Call(ctx,(PCV[]){nullptr,Long(1).cv()},1,247)) goto _0;
		g->Check(ctx);
		goto _7;
_5:
		{
			Obj t40;
			c.f.fLine=41;
			if (g->Call(ctx,(PCV[]){t40.cv()},0,1466)) goto _0;
			Variant t41;
			if (g->GetMember(ctx,t40.cv(),KcolLBSetup.cv(),t41.cv())) goto _0;
			Col t42;
			if (!g->GetValue(ctx,(PCV[]){t42.cv(),t41.cv(),nullptr})) goto _0;
			Txt t43;
			t43=KlbItemListMulti.get();
			Bool t44;
			proc_LBX__SETUP(glob,ctx,2,2,(PCV[]){t43.cv(),t42.cv()},t44.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lbSuccess=t44.get();
		}
		{
			Obj t45;
			c.f.fLine=42;
			if (g->Call(ctx,(PCV[]){t45.cv()},0,1466)) goto _0;
			Obj t46;
			if (g->Call(ctx,(PCV[]){t46.cv()},0,1466)) goto _0;
			Variant t47;
			if (g->GetMember(ctx,t46.cv(),KlbItemListMulti.cv(),t47.cv())) goto _0;
			if (g->SetMember(ctx,t45.cv(),KlbItemListMulti.cv(),t47.cv())) goto _0;
		}
		c.f.fLine=43;
		if (g->Call(ctx,(PCV[]){nullptr,Long(2).cv()},1,247)) goto _0;
		g->Check(ctx);
_7:
		{
			Bool t48;
			t48=lbSuccess.get();
			Bool t49;
			t49=!(t48.get());
			if (!(t49.get())) goto _8;
		}
		c.f.fLine=48;
		if (g->Call(ctx,(PCV[]){nullptr,kCPE6gzua87w.cv()},1,41)) goto _0;
		g->Check(ctx);
		c.f.fLine=49;
		if (g->Call(ctx,(PCV[]){nullptr},0,270)) goto _0;
		g->Check(ctx);
_8:
		goto _3;
_4:
		{
			Long t50;
			c.f.fLine=53;
			if (g->Call(ctx,(PCV[]){t50.cv()},0,388)) goto _0;
			g->Check(ctx);
			if (22!=t50.get()) goto _9;
		}
		goto _3;
_9:
_3:
		goto _10;
_2:
		{
			Variant t52;
			c.f.fLine=59;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t52.cv())) goto _0;
			Bool t53;
			if (g->OperationOnAny(ctx,6,t52.cv(),KlbItemList_40.cv(),t53.cv())) goto _0;
			Variant t54;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t54.cv())) goto _0;
			Bool t55;
			if (g->OperationOnAny(ctx,6,t54.cv(),Long(13).cv(),t55.cv())) goto _0;
			Bool t56;
			t56=t53.get()&&t55.get();
			if (!(t56.get())) goto _12;
		}
		{
			Obj t57;
			c.f.fLine=60;
			if (g->Call(ctx,(PCV[]){t57.cv()},0,1466)) goto _0;
			Bool t58;
			t58=Bool(1).get();
			if (g->SetMember(ctx,t57.cv(),KbUserSelected.cv(),t58.cv())) goto _0;
		}
		c.f.fLine=61;
		if (g->Call(ctx,(PCV[]){nullptr},0,269)) goto _0;
		g->Check(ctx);
		goto _11;
_12:
		{
			Variant t59;
			c.f.fLine=62;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t59.cv())) goto _0;
			Bool t60;
			if (g->OperationOnAny(ctx,6,t59.cv(),KtFormHeader.cv(),t60.cv())) goto _0;
			if (!(t60.get())) goto _13;
		}
		{
			Txt t61;
			c.f.fLine=64;
			if (g->Call(ctx,(PCV[]){t61.cv()},0,655)) goto _0;
			g->Check(ctx);
			ltEntry=t61.get();
		}
		{
			Bool t62;
			t62=g->CompareString(ctx,ltEntry.get(),K.get())!=0;
			if (!(t62.get())) goto _14;
		}
		{
			Obj t63;
			c.f.fLine=66;
			if (g->Call(ctx,(PCV[]){t63.cv()},0,1466)) goto _0;
			Obj t64;
			if (g->Call(ctx,(PCV[]){t64.cv()},0,1466)) goto _0;
			Variant t65;
			if (g->GetMember(ctx,t64.cv(),KcolListItems.cv(),t65.cv())) goto _0;
			Obj t66;
			if (g->Call(ctx,(PCV[]){t66.cv()},0,1466)) goto _0;
			Variant t67;
			if (g->GetMember(ctx,t66.cv(),KcolLBSetup.cv(),t67.cv())) goto _0;
			Variant t68;
			if (g->GetMember(ctx,t67.cv(),Long(0).cv(),t68.cv())) goto _0;
			Variant t69;
			if (g->GetMember(ctx,t68.cv(),KtName.cv(),t69.cv())) goto _0;
			Variant t70;
			if (g->OperationOnAny(ctx,0,t69.cv(),K_20_3D_20_3A1.cv(),t70.cv())) goto _0;
			Txt t71;
			g->AddString(ltEntry.get(),K_40.get(),t71.get());
			Variant t72;
			if (g->Call(ctx,(PCV[]){t72.cv(),t65.cv(),Kquery.cv(),t70.cv(),t71.cv()},4,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t63.cv(),KcolListItems.cv(),t72.cv())) goto _0;
		}
		goto _15;
_14:
		{
			Obj t73;
			c.f.fLine=68;
			if (g->Call(ctx,(PCV[]){t73.cv()},0,1466)) goto _0;
			Obj t74;
			if (g->Call(ctx,(PCV[]){t74.cv()},0,1466)) goto _0;
			Variant t75;
			if (g->GetMember(ctx,t74.cv(),KcolOrigList.cv(),t75.cv())) goto _0;
			if (g->SetMember(ctx,t73.cv(),KcolListItems.cv(),t75.cv())) goto _0;
		}
_15:
		goto _11;
_13:
		{
			Variant t76;
			c.f.fLine=70;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t76.cv())) goto _0;
			Bool t77;
			if (g->OperationOnAny(ctx,6,t76.cv(),KbttnSelect.cv(),t77.cv())) goto _0;
			if (!(t77.get())) goto _16;
		}
		{
			Obj t78;
			c.f.fLine=71;
			if (g->Call(ctx,(PCV[]){t78.cv()},0,1466)) goto _0;
			Variant t79;
			if (g->GetMember(ctx,t78.cv(),KbAutoComplete.cv(),t79.cv())) goto _0;
			Bool t80;
			if (!g->GetValue(ctx,(PCV[]){t80.cv(),t79.cv(),nullptr})) goto _0;
			if (!(t80.get())) goto _17;
		}
		{
			Obj t81;
			c.f.fLine=72;
			if (g->Call(ctx,(PCV[]){t81.cv()},0,1466)) goto _0;
			Variant t82;
			if (g->GetMember(ctx,t81.cv(),klQSV4ZoYWzw.cv(),t82.cv())) goto _0;
			Variant t83;
			if (g->GetMember(ctx,t82.cv(),Klength.cv(),t83.cv())) goto _0;
			Bool t84;
			if (g->OperationOnAny(ctx,6,t83.cv(),Num(0).cv(),t84.cv())) goto _0;
			Obj t85;
			if (g->Call(ctx,(PCV[]){t85.cv()},0,1466)) goto _0;
			Variant t86;
			if (g->GetMember(ctx,t85.cv(),KcolListItems.cv(),t86.cv())) goto _0;
			Variant t87;
			if (g->GetMember(ctx,t86.cv(),Klength.cv(),t87.cv())) goto _0;
			Bool t88;
			if (g->OperationOnAny(ctx,5,t87.cv(),Num(0).cv(),t88.cv())) goto _0;
			Bool t89;
			t89=t84.get()&&t88.get();
			if (!(t89.get())) goto _18;
		}
		{
			Obj t90;
			c.f.fLine=73;
			if (g->Call(ctx,(PCV[]){t90.cv()},0,1466)) goto _0;
			Variant t91;
			if (g->GetMember(ctx,t90.cv(),klQSV4ZoYWzw.cv(),t91.cv())) goto _0;
			Obj t92;
			if (g->Call(ctx,(PCV[]){t92.cv()},0,1466)) goto _0;
			Variant t93;
			if (g->GetMember(ctx,t92.cv(),KcolListItems.cv(),t93.cv())) goto _0;
			Variant t94;
			if (g->GetMember(ctx,t93.cv(),Long(0).cv(),t94.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t91.cv(),Kpush.cv(),t94.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_18:
_17:
		goto _11;
_16:
_11:
_10:
_0:
_1:
;
	}

}
