extern Txt K;
extern Txt k4YwHrlt0lGo;
extern unsigned char D_proc_WIND__OPENWINDOW[];
void proc_WIND__OPENWINDOW( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_WIND__OPENWINDOW);
	if (!ctx->doingAbort) {
		Long liWindowWidth;
		Long liMouseX;
		Long liMouseY;
		Txt ltFormName;
		Long liRight;
		Long liWindowRef;
		Long liMenuHeight;
		Long liBottom;
		Long liTop;
		Bool lJCPEREZ__20230115a;
		Long liWindowTitleHeight;
		Long liWindowPosition;
		Long liWindowHeight;
		Ptr lpTable;
		Long liWindowEdge;
		Long lparms;
		Long liMouseBttns;
		Txt ltWindowTitle;
		Long liLeft;
		Long liWindowType;
		Long liWindowScrollBar;
		Bool lJCPEREZ__20220920a;
		Long liScreenHeight;
		Long liScreenWidth;
		new ( outResult) Long();
		{
			Long t0;
			t0=inNbExplicitParam;
			lparms=t0.get();
		}
		liWindowRef=0;
		c.f.fLine=32;
		liWindowWidth=Parm<Long>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=33;
		liWindowHeight=Parm<Long>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=34;
		liWindowPosition=Parm<Long>(ctx,inParams,inNbParam,3).get();
		if (ctx->doingAbort) goto _0;
		liWindowType=8;
		ltWindowTitle=K.get();
		ltFormName=K.get();
		{
			Ptr t1;
			lpTable=t1.get();
		}
		{
			Long t2;
			t2=inNbExplicitParam;
			if (4>t2.get()) goto _2;
		}
		c.f.fLine=41;
		liWindowType=Parm<Long>(ctx,inParams,inNbParam,4).get();
		if (ctx->doingAbort) goto _0;
		{
			Long t4;
			t4=inNbExplicitParam;
			if (5>t4.get()) goto _3;
		}
		c.f.fLine=43;
		ltWindowTitle=Parm<Txt>(ctx,inParams,inNbParam,5).get();
		if (ctx->doingAbort) goto _0;
		{
			Long t6;
			t6=inNbExplicitParam;
			if (6>t6.get()) goto _4;
		}
		c.f.fLine=45;
		ltFormName=Parm<Txt>(ctx,inParams,inNbParam,6).get();
		if (ctx->doingAbort) goto _0;
		{
			Long t8;
			t8=inNbExplicitParam;
			if (7>t8.get()) goto _5;
		}
		c.f.fLine=47;
		lpTable=Parm<Ptr>(ctx,inParams,inNbParam,7).get();
		if (ctx->doingAbort) goto _0;
_5:
_4:
_3:
_2:
		{
			Long t10;
			c.f.fLine=56;
			if (g->Call(ctx,(PCV[]){t10.cv()},0,188)) goto _0;
			liScreenHeight=t10.get();
		}
		{
			Long t11;
			c.f.fLine=57;
			if (g->Call(ctx,(PCV[]){t11.cv()},0,187)) goto _0;
			liScreenWidth=t11.get();
		}
		{
			Long t12;
			c.f.fLine=58;
			if (g->Call(ctx,(PCV[]){t12.cv()},0,440)) goto _0;
			g->Check(ctx);
			liMenuHeight=t12.get();
		}
		liWindowTitleHeight=20;
		liWindowScrollBar=10;
		liWindowEdge=5;
		if (0!=liWindowPosition.get()) goto _7;
		{
			Long t14;
			t14=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t14.get()/2;
		}
		{
			Long t16;
			t16=liScreenHeight.get()-liWindowHeight.get();
			Long t17;
			t17=t16.get()-liWindowTitleHeight.get();
			Long t18;
			t18=t17.get()/2;
			liTop=t18.get()+liMenuHeight.get();
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_7:
		if (1!=liWindowPosition.get()) goto _8;
		{
			Txt t23;
			c.f.fLine=72;
			if (g->Call(ctx,(PCV[]){t23.cv()},0,684)) goto _0;
			g->Check(ctx);
			Txt t24;
			g->AddString(k4YwHrlt0lGo.get(),t23.get(),t24.get());
			if (g->Call(ctx,(PCV[]){nullptr,t24.cv()},1,41)) goto _0;
		}
		goto _6;
_8:
		if (2!=liWindowPosition.get()) goto _9;
		liLeft=liWindowEdge.get();
		liTop=liMenuHeight.get()+liWindowTitleHeight.get();
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_9:
		if (3!=liWindowPosition.get()) goto _10;
		{
			Long t30;
			t30=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t30.get()-liWindowScrollBar.get();
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liTop=liMenuHeight.get()+liWindowTitleHeight.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_10:
		if (4!=liWindowPosition.get()) goto _11;
		liLeft=liWindowEdge.get();
		{
			Long t36;
			t36=liScreenHeight.get()-liWindowHeight.get();
			liTop=t36.get()-liWindowEdge.get();
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_11:
		if (5!=liWindowPosition.get()) goto _12;
		{
			Long t41;
			t41=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t41.get()-liWindowScrollBar.get();
		}
		{
			Long t43;
			t43=liScreenHeight.get()-liWindowHeight.get();
			liTop=t43.get()-liWindowEdge.get();
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_12:
		if (6!=liWindowPosition.get()) goto _13;
		{
			Long t48;
			t48=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t48.get()/2;
		}
		{
			Long t50;
			t50=liScreenHeight.get()-liWindowHeight.get();
			Long t51;
			t51=t50.get()-liWindowTitleHeight.get();
			Long t52;
			t52=t51.get()/3;
			liTop=t52.get()+liMenuHeight.get();
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_13:
		if (7!=liWindowPosition.get()) goto _14;
		{
			Long t57;
			t57=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t57.get()/2;
		}
		{
			Long t59;
			t59=liScreenHeight.get()-liWindowHeight.get();
			Long t60;
			t60=t59.get()-liWindowTitleHeight.get();
			Long t61;
			t61=t60.get()/4;
			liTop=t61.get()+liMenuHeight.get();
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_14:
		if (8!=liWindowPosition.get()) goto _15;
		{
			Long t66;
			t66=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t66.get()/2;
		}
		liTop=liMenuHeight.get()+liWindowTitleHeight.get();
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_15:
		if (9!=liWindowPosition.get()) goto _16;
		{
			Long t72;
			t72=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t72.get()/2;
		}
		{
			Long t74;
			t74=liMenuHeight.get()+liWindowTitleHeight.get();
			liTop=t74.get()+40;
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_16:
		if (10!=liWindowPosition.get()) goto _17;
		{
			Long t79;
			t79=liScreenWidth.get()-liWindowWidth.get();
			liLeft=t79.get()/2;
		}
		{
			Long t81;
			t81=liScreenHeight.get()-liWindowHeight.get();
			liTop=t81.get()-liWindowEdge.get();
		}
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_17:
		if (11!=liWindowPosition.get()) goto _18;
		{
			Ref t86;
			t86.setLocalRef(ctx,liMouseBttns.cv());
			Ref t87;
			t87.setLocalRef(ctx,liMouseY.cv());
			Ref t88;
			t88.setLocalRef(ctx,liMouseX.cv());
			c.f.fLine=130;
			if (g->Call(ctx,(PCV[]){nullptr,t88.cv(),t87.cv(),t86.cv()},3,468)) goto _0;
			g->Check(ctx);
		}
		{
			Ref t89;
			t89.setLocalRef(ctx,liMouseY.cv());
			Ref t90;
			t90.setLocalRef(ctx,liMouseX.cv());
			c.f.fLine=131;
			if (g->Call(ctx,(PCV[]){nullptr,t90.cv(),t89.cv(),Long(2).cv(),Long(4).cv()},4,1365)) goto _0;
			g->Check(ctx);
		}
		liLeft=liMouseX.get();
		liTop=liMouseY.get();
		liRight=liLeft.get()+liWindowWidth.get();
		liBottom=liTop.get()+liWindowHeight.get();
		goto _6;
_18:
_6:
		{
			Ptr t93;
			c.f.fLine=140;
			if (!g->GetValue(ctx,(PCV[]){t93.cv(),lpTable.cv(),nullptr})) goto _0;
			Bool t94;
			if (g->Call(ctx,(PCV[]){t94.cv(),t93.cv()},1,315)) goto _0;
			if (!(t94.get())) goto _19;
		}
		{
			Long t95;
			c.f.fLine=141;
			if (g->Call(ctx,(PCV[]){t95.cv(),ltFormName.cv(),liWindowType.cv(),liLeft.cv(),liTop.cv()},4,675)) goto _0;
			g->Check(ctx);
			liWindowRef=t95.get();
		}
		goto _20;
_19:
		{
			Ref t96;
			c.f.fLine=143;
			if (!g->CastPointerToRef(ctx,2,(PCV[]){t96.cv(),lpTable.cv(),(PCV)-1,nullptr})) goto _0;
			Long t97;
			if (g->Call(ctx,(PCV[]){t97.cv(),t96.cv(),ltFormName.cv(),liWindowType.cv(),liLeft.cv(),liTop.cv()},5,675)) goto _0;
			g->Check(ctx);
			liWindowRef=t97.get();
		}
_20:
		c.f.fLine=145;
		if (g->Call(ctx,(PCV[]){nullptr,liLeft.cv(),liTop.cv(),liRight.cv(),liBottom.cv(),liWindowRef.cv()},5,444)) goto _0;
		g->Check(ctx);
		c.f.fLine=146;
		if (g->Call(ctx,(PCV[]){nullptr,ltWindowTitle.cv(),liWindowRef.cv()},2,213)) goto _0;
		g->Check(ctx);
		c.f.fLine=148;
		Res<Long>(outResult)=liWindowRef.get();
_0:
_1:
;
	}

}
