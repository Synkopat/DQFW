extern Txt KBaseEntity;
extern Txt KDBQueries;
extern Txt KKey;
extern Txt KSBK__Manager;
extern Txt KbEnableGrouping;
extern Txt KbFullAccess;
extern Txt KbSaveRecord;
extern Txt KeDBQuery;
extern Txt KiWinRef;
extern Txt Knew;
extern Txt Ksave;
extern Txt Ksuccess;
extern Txt KtFormHeader;
extern Txt kM7ZrSE1z4ns;
extern Txt kx70Q3Jyepmo;
Asm4d_Proc proc_SBK__GET;
Asm4d_Proc proc_UTIL__SETOBJVALUES;
Asm4d_Proc proc_WIND__OPENWINDOW;
extern unsigned char D_proc_SBK__EDIT[];
void proc_SBK__EDIT( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__EDIT);
	if (!ctx->doingAbort) {
		Bool lbSuccess;
		Obj leDBQuery;
		Txt ltForm;
		Long liFormHeight;
		Long liFormWidth;
		Obj loSysBook;
		Bool lJCPEREZ__20241102;
		Variant loResult;
		Obj loDBQuery;
		new ( outResult) Bool();
		c.f.fLine=12;
		loSysBook=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		lbSuccess=Bool(0).get();
		ltForm=KSBK__Manager.get();
		{
			Ref t0;
			t0.setLocalRef(ctx,liFormHeight.cv());
			Ref t1;
			t1.setLocalRef(ctx,liFormWidth.cv());
			c.f.fLine=19;
			if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),t1.cv(),t0.cv()},3,674)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t2;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loDBQuery=t2.get();
		}
		c.f.fLine=25;
		if (g->SetMember(ctx,loDBQuery.cv(),KtFormHeader.cv(),kM7ZrSE1z4ns.cv())) goto _0;
		{
			Bool t3;
			t3=Bool(0).get();
			c.f.fLine=26;
			if (g->SetMember(ctx,loDBQuery.cv(),KbSaveRecord.cv(),t3.cv())) goto _0;
		}
		{
			Bool t4;
			t4=Bool(1).get();
			c.f.fLine=27;
			if (g->SetMember(ctx,loDBQuery.cv(),KbEnableGrouping.cv(),t4.cv())) goto _0;
		}
		{
			Bool t5;
			t5=Bool(0).get();
			c.f.fLine=28;
			if (g->SetMember(ctx,loDBQuery.cv(),KbFullAccess.cv(),t5.cv())) goto _0;
		}
		{
			Variant t6;
			c.f.fLine=29;
			if (g->GetMember(ctx,loSysBook.cv(),KbEnableGrouping.cv(),t6.cv())) goto _0;
			Bool t7;
			if (g->OperationOnAny(ctx,7,t6.cv(),Value_null().cv(),t7.cv())) goto _0;
			if (!(t7.get())) goto _2;
		}
		{
			Variant t8;
			c.f.fLine=30;
			if (g->GetMember(ctx,loSysBook.cv(),KbEnableGrouping.cv(),t8.cv())) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KbEnableGrouping.cv(),t8.cv())) goto _0;
		}
_2:
		{
			Variant t9;
			c.f.fLine=33;
			if (g->GetMember(ctx,loSysBook.cv(),KKey.cv(),t9.cv())) goto _0;
			Bool t10;
			if (g->OperationOnAny(ctx,7,t9.cv(),Value_null().cv(),t10.cv())) goto _0;
			if (!(t10.get())) goto _3;
		}
		{
			Variant t11;
			c.f.fLine=35;
			if (g->GetMember(ctx,loSysBook.cv(),KBaseEntity.cv(),t11.cv())) goto _0;
			Variant t12;
			if (g->GetMember(ctx,loSysBook.cv(),KKey.cv(),t12.cv())) goto _0;
			Txt t13;
			if (!g->GetValue(ctx,(PCV[]){t13.cv(),t12.cv(),nullptr})) goto _0;
			Txt t14;
			if (!g->GetValue(ctx,(PCV[]){t14.cv(),t11.cv(),nullptr})) goto _0;
			Obj t15;
			proc_SBK__GET(glob,ctx,2,2,(PCV[]){t14.cv(),t13.cv()},t15.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t15.cv())) goto _0;
		}
		goto _4;
_3:
		{
			Obj t16;
			c.f.fLine=38;
			if (g->Call(ctx,(PCV[]){t16.cv()},0,1482)) goto _0;
			Variant t17;
			if (g->Call(ctx,(PCV[]){t17.cv(),t16.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t18;
			if (g->Call(ctx,(PCV[]){t18.cv(),t17.cv(),Knew.cv()},2,1498)) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t18.cv())) goto _0;
		}
		{
			Variant t19;
			c.f.fLine=39;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t19.cv())) goto _0;
			Obj t20;
			t20=loSysBook.get();
			Obj t21;
			if (!g->GetValue(ctx,(PCV[]){t21.cv(),t19.cv(),nullptr})) goto _0;
			proc_UTIL__SETOBJVALUES(glob,ctx,2,2,(PCV[]){t21.cv(),t20.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
_4:
		{
			Ptr t22;
			Txt t23;
			t23=ltForm.get();
			Txt t24;
			t24=kx70Q3Jyepmo.get();
			Long t25;
			t25=33;
			Long t26;
			t26=6;
			Long t27;
			t27=liFormHeight.get();
			Long t28;
			t28=liFormWidth.get();
			Long t29;
			c.f.fLine=43;
			proc_WIND__OPENWINDOW(glob,ctx,6,7,(PCV[]){t28.cv(),t27.cv(),t26.cv(),t25.cv(),t24.cv(),t23.cv(),t22.cv()},t29.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KiWinRef.cv(),t29.cv())) goto _0;
		}
		c.f.fLine=45;
		if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),loDBQuery.cv()},2,40)) goto _0;
		g->Check(ctx);
		{
			Variant t30;
			c.f.fLine=47;
			if (g->GetMember(ctx,loDBQuery.cv(),KbSaveRecord.cv(),t30.cv())) goto _0;
			Bool t31;
			if (!g->GetValue(ctx,(PCV[]){t31.cv(),t30.cv(),nullptr})) goto _0;
			if (!(t31.get())) goto _5;
		}
		{
			Variant t32;
			c.f.fLine=49;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t32.cv())) goto _0;
			Variant t33;
			if (g->Call(ctx,(PCV[]){t33.cv(),t32.cv(),Ksave.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (!g->SetValue(ctx,(PCV[]){t33.cv(),loResult.cv(),nullptr})) goto _0;
		}
		{
			Variant t34;
			c.f.fLine=50;
			if (!g->GetValue(ctx,(PCV[]){t34.cv(),loResult.cv(),nullptr})) goto _0;
			Variant t35;
			if (g->Call(ctx,(PCV[]){t35.cv(),t34.cv(),Ksuccess.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Bool t36;
			if (!g->GetValue(ctx,(PCV[]){t36.cv(),t35.cv(),nullptr})) goto _0;
			lbSuccess=t36.get();
		}
		goto _6;
_5:
		c.f.fLine=52;
		Res<Bool>(outResult)=lbSuccess.get();
_6:
_0:
_1:
;
	}

}
