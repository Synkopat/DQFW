extern int32_t vOK;
extern Txt K;
extern Txt K300;
extern Txt KBaseEntity;
extern Txt KBaseEntity_20_3D_20_3A1;
extern Txt KBttnRunQuery;
extern Txt KBttnSelectGroup;
extern Txt KCancel;
extern Txt KCategory;
extern Txt KCategory_20_3D_20_3A1;
extern Txt KCreatedBy_20_3D_20_3A1;
extern Txt KDBQueries;
extern Txt KDiscard;
extern Txt KDisplayRole;
extern Txt KGroup;
extern Txt KGroup_20_3D_20_3A1;
extern Txt KQueryName;
extern Txt KQueryName_20_3D_20_3A1;
extern Txt KSingle;
extern Txt KUI__SEARCH;
extern Txt KUSER;
extern Txt K_20AND_20Group_20_23_20_3A2;
extern Txt K_40;
extern Txt KbAutoComplete;
extern Txt KbttnAllRecords;
extern Txt KbttnClose;
extern Txt Kcode;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt Kcopy;
extern Txt Kdistinct;
extern Txt KeDBQuery;
extern Txt Klength;
extern Txt KobjectName;
extern Txt Kpush;
extern Txt Kquery;
extern Txt KtFormHeader;
extern Txt KtSelectionMode;
extern Txt k8pbYXc0IDa4;
extern Txt kFC3mrBPpIRQ;
extern Txt kLGJAiSueMjo;
extern Txt keDIZs3EOHqQ;
extern Txt kifRyNcfJ4tA;
extern Txt kiin4rCiGwQ8;
extern Txt ko166k_hFrHs;
Asm4d_Proc proc_WDGT__CONFIGCOLUMNS;
Asm4d_Proc proc_WDGT__SELECT;
extern unsigned char D_proc_SBK__SEARCHHNDL[];
void proc_SBK__SEARCHHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__SEARCHHNDL);
	if (!ctx->doingAbort) {
		Variant ltCategory;
		Obj lesSystems;
		Obj loItem;
		Txt ltHeaders;
		Col lcolCategories;
		Variant ltGroup;
		Col lcolItems;
		Bool lbOptionKeyDown;
		Obj l__4D__auto__iter__0;
		Obj l__4D__auto__iter__1;
		Bool lbCtrlKeyDown;
		Obj ltoFormEvent;
		Obj loFormEvent;
		Col lcolUserSelection;
		Bool lJCPEREZ__20241102;
		Txt ltHiddenCols;
		Obj loListItems;
		Txt ltHdrMap;
		Txt ltWidths;
		Col lcolGroups;
		c.f.fLine=11;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Bool t0;
			c.f.fLine=14;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,546)) goto _0;
			Bool t1;
			if (g->Call(ctx,(PCV[]){t1.cv()},0,562)) goto _0;
			g->Check(ctx);
			lbCtrlKeyDown=t0.get()||t1.get();
		}
		{
			Variant t3;
			c.f.fLine=16;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t3.cv())) goto _0;
			Bool t4;
			if (g->OperationOnAny(ctx,6,t3.cv(),Value_null().cv(),t4.cv())) goto _0;
			if (!(t4.get())) goto _2;
		}
		{
			Variant t5;
			c.f.fLine=19;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t5.cv())) goto _0;
			Bool t6;
			if (g->OperationOnAny(ctx,6,t5.cv(),Long(1).cv(),t6.cv())) goto _0;
			if (!(t6.get())) goto _4;
		}
		goto _3;
_4:
_3:
		goto _5;
_2:
		{
			Variant t7;
			c.f.fLine=24;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t7.cv())) goto _0;
			Bool t8;
			if (g->OperationOnAny(ctx,6,t7.cv(),KbttnClose.cv(),t8.cv())) goto _0;
			if (!(t8.get())) goto _7;
		}
		c.f.fLine=25;
		if (g->Call(ctx,(PCV[]){nullptr,kiin4rCiGwQ8.cv(),KDiscard.cv(),KCancel.cv()},3,162)) goto _0;
		g->Check(ctx);
		if (1!=Var<Long>(ctx,vOK).get()) goto _8;
		c.f.fLine=27;
		if (g->Call(ctx,(PCV[]){nullptr},0,270)) goto _0;
		g->Check(ctx);
_8:
		goto _6;
_7:
		{
			Variant t10;
			c.f.fLine=29;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t10.cv())) goto _0;
			Bool t11;
			if (g->OperationOnAny(ctx,6,t10.cv(),KbttnAllRecords.cv(),t11.cv())) goto _0;
			if (!(t11.get())) goto _9;
		}
		{
			Obj t12;
			c.f.fLine=31;
			if (g->Call(ctx,(PCV[]){t12.cv()},0,1482)) goto _0;
			Variant t13;
			if (g->Call(ctx,(PCV[]){t13.cv(),t12.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t14;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_23_20_3A2.get(),t14.get());
			Obj t15;
			if (g->Call(ctx,(PCV[]){t15.cv()},0,1466)) goto _0;
			Variant t16;
			if (g->GetMember(ctx,t15.cv(),KBaseEntity.cv(),t16.cv())) goto _0;
			Variant t17;
			if (g->Call(ctx,(PCV[]){t17.cv(),t13.cv(),Kquery.cv(),t14.cv(),t16.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			Obj t18;
			if (!g->GetValue(ctx,(PCV[]){t18.cv(),t17.cv(),nullptr})) goto _0;
			lesSystems=t18.get();
		}
		{
			Bool t19;
			t19=!lesSystems.isNull();
			if (!(t19.get())) goto _10;
		}
		{
			Obj t20;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t20.cv(),kFC3mrBPpIRQ.cv(),lesSystems.cv())) goto _0;
		}
		goto _11;
_10:
		{
			Obj t21;
			c.f.fLine=35;
			if (g->Call(ctx,(PCV[]){t21.cv()},0,1466)) goto _0;
			Variant t22;
			t22.setNull();
			if (g->SetMember(ctx,t21.cv(),kFC3mrBPpIRQ.cv(),t22.cv())) goto _0;
		}
_11:
		c.f.fLine=37;
		if (g->Call(ctx,(PCV[]){nullptr},0,269)) goto _0;
		g->Check(ctx);
		goto _6;
_9:
		{
			Variant t23;
			c.f.fLine=38;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t23.cv())) goto _0;
			Bool t24;
			if (g->OperationOnAny(ctx,6,t23.cv(),KBttnRunQuery.cv(),t24.cv())) goto _0;
			if (!(t24.get())) goto _12;
		}
		{
			Obj t25;
			c.f.fLine=40;
			if (g->Call(ctx,(PCV[]){t25.cv()},0,1482)) goto _0;
			Variant t26;
			if (g->Call(ctx,(PCV[]){t26.cv(),t25.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Obj t27;
			if (g->Call(ctx,(PCV[]){t27.cv()},0,1466)) goto _0;
			Variant t28;
			if (g->GetMember(ctx,t27.cv(),KBaseEntity.cv(),t28.cv())) goto _0;
			Variant t29;
			if (g->Call(ctx,(PCV[]){t29.cv(),t26.cv(),Kquery.cv(),k8pbYXc0IDa4.cv(),t28.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			Obj t30;
			if (!g->GetValue(ctx,(PCV[]){t30.cv(),t29.cv(),nullptr})) goto _0;
			lesSystems=t30.get();
		}
		{
			Obj t31;
			c.f.fLine=44;
			if (g->Call(ctx,(PCV[]){t31.cv()},0,1466)) goto _0;
			Variant t32;
			if (g->GetMember(ctx,t31.cv(),KeDBQuery.cv(),t32.cv())) goto _0;
			Variant t33;
			if (g->GetMember(ctx,t32.cv(),KGroup.cv(),t33.cv())) goto _0;
			Bool t34;
			if (g->OperationOnAny(ctx,7,t33.cv(),Value_null().cv(),t34.cv())) goto _0;
			if (!(t34.get())) goto _13;
		}
		{
			Obj t35;
			c.f.fLine=45;
			if (g->Call(ctx,(PCV[]){t35.cv()},0,1466)) goto _0;
			Variant t36;
			if (g->GetMember(ctx,t35.cv(),KeDBQuery.cv(),t36.cv())) goto _0;
			Variant t37;
			if (g->GetMember(ctx,t36.cv(),KGroup.cv(),t37.cv())) goto _0;
			Variant t38;
			if (g->Call(ctx,(PCV[]){t38.cv(),lesSystems.cv(),Kquery.cv(),KGroup_20_3D_20_3A1.cv(),t37.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Obj t39;
			if (!g->GetValue(ctx,(PCV[]){t39.cv(),t38.cv(),nullptr})) goto _0;
			lesSystems=t39.get();
		}
_13:
		{
			Obj t40;
			c.f.fLine=48;
			if (g->Call(ctx,(PCV[]){t40.cv()},0,1466)) goto _0;
			Variant t41;
			if (g->GetMember(ctx,t40.cv(),KeDBQuery.cv(),t41.cv())) goto _0;
			Variant t42;
			if (g->GetMember(ctx,t41.cv(),KCategory.cv(),t42.cv())) goto _0;
			Bool t43;
			if (g->OperationOnAny(ctx,7,t42.cv(),Value_null().cv(),t43.cv())) goto _0;
			if (!(t43.get())) goto _14;
		}
		{
			Obj t44;
			c.f.fLine=49;
			if (g->Call(ctx,(PCV[]){t44.cv()},0,1466)) goto _0;
			Variant t45;
			if (g->GetMember(ctx,t44.cv(),KeDBQuery.cv(),t45.cv())) goto _0;
			Variant t46;
			if (g->GetMember(ctx,t45.cv(),KCategory.cv(),t46.cv())) goto _0;
			Variant t47;
			if (g->Call(ctx,(PCV[]){t47.cv(),lesSystems.cv(),Kquery.cv(),KCategory_20_3D_20_3A1.cv(),t46.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Obj t48;
			if (!g->GetValue(ctx,(PCV[]){t48.cv(),t47.cv(),nullptr})) goto _0;
			lesSystems=t48.get();
		}
_14:
		{
			Obj t49;
			c.f.fLine=52;
			if (g->Call(ctx,(PCV[]){t49.cv()},0,1466)) goto _0;
			Variant t50;
			if (g->GetMember(ctx,t49.cv(),KeDBQuery.cv(),t50.cv())) goto _0;
			Variant t51;
			if (g->GetMember(ctx,t50.cv(),KQueryName.cv(),t51.cv())) goto _0;
			Bool t52;
			if (g->OperationOnAny(ctx,7,t51.cv(),K.cv(),t52.cv())) goto _0;
			if (!(t52.get())) goto _15;
		}
		{
			Obj t53;
			c.f.fLine=53;
			if (g->Call(ctx,(PCV[]){t53.cv()},0,1466)) goto _0;
			Variant t54;
			if (g->GetMember(ctx,t53.cv(),KeDBQuery.cv(),t54.cv())) goto _0;
			Variant t55;
			if (g->GetMember(ctx,t54.cv(),KQueryName.cv(),t55.cv())) goto _0;
			Variant t56;
			if (g->OperationOnAny(ctx,0,K_40.cv(),t55.cv(),t56.cv())) goto _0;
			Variant t57;
			if (g->OperationOnAny(ctx,0,t56.cv(),K_40.cv(),t57.cv())) goto _0;
			Variant t58;
			if (g->Call(ctx,(PCV[]){t58.cv(),lesSystems.cv(),Kquery.cv(),KQueryName_20_3D_20_3A1.cv(),t57.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Obj t59;
			if (!g->GetValue(ctx,(PCV[]){t59.cv(),t58.cv(),nullptr})) goto _0;
			lesSystems=t59.get();
		}
_15:
		{
			Obj t60;
			c.f.fLine=56;
			if (g->Call(ctx,(PCV[]){t60.cv()},0,1466)) goto _0;
			Variant t61;
			if (g->GetMember(ctx,t60.cv(),KeDBQuery.cv(),t61.cv())) goto _0;
			Variant t62;
			if (g->GetMember(ctx,t61.cv(),KDisplayRole.cv(),t62.cv())) goto _0;
			Bool t63;
			if (g->OperationOnAny(ctx,7,t62.cv(),K.cv(),t63.cv())) goto _0;
			if (!(t63.get())) goto _16;
		}
		{
			Obj t64;
			c.f.fLine=57;
			if (g->Call(ctx,(PCV[]){t64.cv()},0,1466)) goto _0;
			Variant t65;
			if (g->GetMember(ctx,t64.cv(),KeDBQuery.cv(),t65.cv())) goto _0;
			Variant t66;
			if (g->GetMember(ctx,t65.cv(),KDisplayRole.cv(),t66.cv())) goto _0;
			Variant t67;
			if (g->OperationOnAny(ctx,0,K_40.cv(),t66.cv(),t67.cv())) goto _0;
			Variant t68;
			if (g->OperationOnAny(ctx,0,t67.cv(),K_40.cv(),t68.cv())) goto _0;
			Variant t69;
			if (g->Call(ctx,(PCV[]){t69.cv(),lesSystems.cv(),Kquery.cv(),keDIZs3EOHqQ.cv(),t68.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Obj t70;
			if (!g->GetValue(ctx,(PCV[]){t70.cv(),t69.cv(),nullptr})) goto _0;
			lesSystems=t70.get();
		}
_16:
		{
			Bool t71;
			t71=!lesSystems.isNull();
			if (!(t71.get())) goto _17;
		}
		{
			Obj t72;
			c.f.fLine=61;
			if (g->Call(ctx,(PCV[]){t72.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t72.cv(),kFC3mrBPpIRQ.cv(),lesSystems.cv())) goto _0;
		}
		goto _18;
_17:
		{
			Obj t73;
			c.f.fLine=63;
			if (g->Call(ctx,(PCV[]){t73.cv()},0,1466)) goto _0;
			Variant t74;
			t74.setNull();
			if (g->SetMember(ctx,t73.cv(),kFC3mrBPpIRQ.cv(),t74.cv())) goto _0;
		}
_18:
		c.f.fLine=65;
		if (g->Call(ctx,(PCV[]){nullptr},0,269)) goto _0;
		g->Check(ctx);
		goto _6;
_12:
		{
			Variant t75;
			c.f.fLine=66;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t75.cv())) goto _0;
			Bool t76;
			if (g->OperationOnAny(ctx,6,t75.cv(),KBttnSelectGroup.cv(),t76.cv())) goto _0;
			if (!(t76.get())) goto _19;
		}
		{
			Col t77;
			c.f.fLine=71;
			if (g->Call(ctx,(PCV[]){t77.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolItems=t77.get();
		}
		{
			Col t78;
			c.f.fLine=72;
			if (g->Call(ctx,(PCV[]){t78.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolGroups=t78.get();
		}
		ltHdrMap=KGroup.get();
		ltHeaders=KGroup.get();
		ltWidths=K300.get();
		ltHiddenCols=K.get();
		{
			Obj t79;
			c.f.fLine=79;
			if (g->Call(ctx,(PCV[]){t79.cv()},0,1482)) goto _0;
			Variant t80;
			if (g->Call(ctx,(PCV[]){t80.cv(),t79.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t81;
			if (g->Call(ctx,(PCV[]){t81.cv(),t80.cv(),Kquery.cv(),KCreatedBy_20_3D_20_3A1.cv(),KUSER.cv()},4,1498)) goto _0;
			Variant t82;
			if (g->Call(ctx,(PCV[]){t82.cv(),t81.cv(),Kdistinct.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			Col t83;
			if (!g->GetValue(ctx,(PCV[]){t83.cv(),t82.cv(),nullptr})) goto _0;
			lcolGroups=t83.get();
		}
		{
			Ref t84;
			c.f.fLine=81;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t84.cv(),ltGroup.cv(),nullptr})) goto _0;
			Obj t85;
			if (g->Call(ctx,(PCV[]){t85.cv(),t84.cv(),lcolGroups.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t85.get();
		}
_20:
		{
			Bool t86;
			if (g->Call(ctx,(PCV[]){t86.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t86.get())) goto _21;
		}
		{
			Obj t87;
			c.f.fLine=82;
			if (g->Call(ctx,(PCV[]){t87.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t87.get();
		}
		{
			Variant t88;
			c.f.fLine=83;
			if (!g->GetValue(ctx,(PCV[]){t88.cv(),ltGroup.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loItem.cv(),KGroup.cv(),t88.cv())) goto _0;
		}
		c.f.fLine=84;
		if (g->Call(ctx,(PCV[]){nullptr,lcolItems.cv(),Kpush.cv(),loItem.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _20;
_21:
		{
			Obj t89;
			l__4D__auto__iter__0=t89.get();
		}
		{
			Obj t90;
			c.f.fLine=87;
			if (g->Call(ctx,(PCV[]){t90.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t90.get();
		}
		{
			Txt t91;
			t91=ltHiddenCols.get();
			Txt t92;
			t92=ltWidths.get();
			Txt t93;
			t93=ltHdrMap.get();
			Txt t94;
			t94=ltHeaders.get();
			Col t95;
			c.f.fLine=88;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t94.cv(),t93.cv(),t92.cv(),t91.cv()},t95.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t95.cv())) goto _0;
		}
		c.f.fLine=89;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),K.cv())) goto _0;
		c.f.fLine=90;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t96;
			c.f.fLine=91;
			if (g->Call(ctx,(PCV[]){t96.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t96.cv())) goto _0;
		}
		{
			Variant t97;
			c.f.fLine=92;
			if (g->Call(ctx,(PCV[]){t97.cv(),lcolItems.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t97.cv())) goto _0;
		}
		{
			Bool t98;
			t98=Bool(1).get();
			c.f.fLine=93;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t98.cv())) goto _0;
		}
		{
			Variant t99;
			c.f.fLine=95;
			if (g->Call(ctx,(PCV[]){t99.cv(),lcolItems.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t100;
			if (g->OperationOnAny(ctx,5,t99.cv(),Num(0).cv(),t100.cv())) goto _0;
			if (!(t100.get())) goto _22;
		}
		{
			Obj t101;
			t101=loListItems.get();
			Col t102;
			c.f.fLine=96;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t101.cv()},t102.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t102.get();
		}
		{
			Variant t103;
			c.f.fLine=97;
			if (g->Call(ctx,(PCV[]){t103.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t104;
			if (g->OperationOnAny(ctx,6,t103.cv(),Num(1).cv(),t104.cv())) goto _0;
			if (!(t104.get())) goto _23;
		}
		{
			Obj t105;
			c.f.fLine=98;
			if (g->Call(ctx,(PCV[]){t105.cv()},0,1466)) goto _0;
			Variant t106;
			if (g->GetMember(ctx,t105.cv(),KeDBQuery.cv(),t106.cv())) goto _0;
			Variant t107;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t107.cv())) goto _0;
			Variant t108;
			if (g->GetMember(ctx,t107.cv(),KGroup.cv(),t108.cv())) goto _0;
			if (g->SetMember(ctx,t106.cv(),KGroup.cv(),t108.cv())) goto _0;
		}
_23:
		goto _24;
_22:
		c.f.fLine=102;
		if (g->Call(ctx,(PCV[]){nullptr,kifRyNcfJ4tA.cv()},1,41)) goto _0;
		g->Check(ctx);
_24:
		goto _6;
_19:
		{
			Variant t109;
			c.f.fLine=105;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t109.cv())) goto _0;
			Bool t110;
			if (g->OperationOnAny(ctx,6,t109.cv(),kLGJAiSueMjo.cv(),t110.cv())) goto _0;
			if (!(t110.get())) goto _25;
		}
		{
			Col t111;
			c.f.fLine=110;
			if (g->Call(ctx,(PCV[]){t111.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolItems=t111.get();
		}
		{
			Col t112;
			c.f.fLine=111;
			if (g->Call(ctx,(PCV[]){t112.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolGroups=t112.get();
		}
		ltHdrMap=KCategory.get();
		ltHeaders=KCategory.get();
		ltWidths=K300.get();
		ltHiddenCols=K.get();
		{
			Obj t113;
			c.f.fLine=118;
			if (g->Call(ctx,(PCV[]){t113.cv()},0,1482)) goto _0;
			Variant t114;
			if (g->Call(ctx,(PCV[]){t114.cv(),t113.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t115;
			if (g->Call(ctx,(PCV[]){t115.cv(),t114.cv(),Kquery.cv(),KCreatedBy_20_3D_20_3A1.cv(),KUSER.cv()},4,1498)) goto _0;
			Variant t116;
			if (g->Call(ctx,(PCV[]){t116.cv(),t115.cv(),Kdistinct.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			Col t117;
			if (!g->GetValue(ctx,(PCV[]){t117.cv(),t116.cv(),nullptr})) goto _0;
			lcolCategories=t117.get();
		}
		{
			Ref t118;
			c.f.fLine=120;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t118.cv(),ltCategory.cv(),nullptr})) goto _0;
			Obj t119;
			if (g->Call(ctx,(PCV[]){t119.cv(),t118.cv(),lcolCategories.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t119.get();
		}
_26:
		{
			Bool t120;
			if (g->Call(ctx,(PCV[]){t120.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t120.get())) goto _27;
		}
		{
			Obj t121;
			c.f.fLine=121;
			if (g->Call(ctx,(PCV[]){t121.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t121.get();
		}
		{
			Variant t122;
			c.f.fLine=122;
			if (!g->GetValue(ctx,(PCV[]){t122.cv(),ltCategory.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loItem.cv(),KCategory.cv(),t122.cv())) goto _0;
		}
		c.f.fLine=123;
		if (g->Call(ctx,(PCV[]){nullptr,lcolItems.cv(),Kpush.cv(),loItem.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _26;
_27:
		{
			Obj t123;
			l__4D__auto__iter__1=t123.get();
		}
		{
			Obj t124;
			c.f.fLine=126;
			if (g->Call(ctx,(PCV[]){t124.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t124.get();
		}
		{
			Txt t125;
			t125=ltHiddenCols.get();
			Txt t126;
			t126=ltWidths.get();
			Txt t127;
			t127=ltHdrMap.get();
			Txt t128;
			t128=ltHeaders.get();
			Col t129;
			c.f.fLine=127;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t128.cv(),t127.cv(),t126.cv(),t125.cv()},t129.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t129.cv())) goto _0;
		}
		c.f.fLine=128;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),K.cv())) goto _0;
		c.f.fLine=129;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t130;
			c.f.fLine=130;
			if (g->Call(ctx,(PCV[]){t130.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t130.cv())) goto _0;
		}
		{
			Variant t131;
			c.f.fLine=131;
			if (g->Call(ctx,(PCV[]){t131.cv(),lcolItems.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t131.cv())) goto _0;
		}
		{
			Bool t132;
			t132=Bool(1).get();
			c.f.fLine=132;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t132.cv())) goto _0;
		}
		{
			Variant t133;
			c.f.fLine=134;
			if (g->Call(ctx,(PCV[]){t133.cv(),lcolItems.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t134;
			if (g->OperationOnAny(ctx,5,t133.cv(),Num(0).cv(),t134.cv())) goto _0;
			if (!(t134.get())) goto _28;
		}
		{
			Obj t135;
			t135=loListItems.get();
			Col t136;
			c.f.fLine=135;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t135.cv()},t136.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t136.get();
		}
		{
			Variant t137;
			c.f.fLine=136;
			if (g->Call(ctx,(PCV[]){t137.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t138;
			if (g->OperationOnAny(ctx,6,t137.cv(),Num(1).cv(),t138.cv())) goto _0;
			if (!(t138.get())) goto _29;
		}
		{
			Obj t139;
			c.f.fLine=137;
			if (g->Call(ctx,(PCV[]){t139.cv()},0,1466)) goto _0;
			Variant t140;
			if (g->GetMember(ctx,t139.cv(),KeDBQuery.cv(),t140.cv())) goto _0;
			Variant t141;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t141.cv())) goto _0;
			Variant t142;
			if (g->GetMember(ctx,t141.cv(),KCategory.cv(),t142.cv())) goto _0;
			if (g->SetMember(ctx,t140.cv(),KCategory.cv(),t142.cv())) goto _0;
		}
_29:
		goto _30;
_28:
		c.f.fLine=141;
		if (g->Call(ctx,(PCV[]){nullptr,ko166k_hFrHs.cv()},1,41)) goto _0;
		g->Check(ctx);
_30:
		goto _6;
_25:
_6:
_5:
_0:
_1:
;
	}

}
