extern Txt K_7B_7D;
extern Txt Kcopy;
Asm4d_Proc proc_DQFW__GETQRYNAME;
extern unsigned char D_proc_DQFW__STRINGIFY[];
void proc_DQFW__STRINGIFY( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__STRINGIFY);
	if (!ctx->doingAbort) {
		Col lcolQryLines;
		Txt ltSysName;
		Txt ltQry;
		Obj loSystem;
		Bool lJCPEREZ__20241102;
		new ( outResult) Txt();
		c.f.fLine=34;
		lcolQryLines=Parm<Col>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		ltQry=K_7B_7D.get();
		{
			Col t0;
			t0=lcolQryLines.get();
			Txt t1;
			c.f.fLine=37;
			proc_DQFW__GETQRYNAME(glob,ctx,1,1,(PCV[]){t0.cv()},t1.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			ltSysName=t1.get();
		}
		{
			Long t2;
			t2=inNbExplicitParam;
			if (2>t2.get()) goto _2;
		}
		c.f.fLine=39;
		ltSysName=Parm<Txt>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
_2:
		{
			Obj t4;
			c.f.fLine=44;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSystem=t4.get();
		}
		{
			Variant t5;
			c.f.fLine=45;
			if (g->Call(ctx,(PCV[]){t5.cv(),lcolQryLines.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loSystem.cv(),ltSysName.cv(),t5.cv())) goto _0;
		}
		{
			Txt t6;
			c.f.fLine=47;
			if (g->Call(ctx,(PCV[]){t6.cv(),loSystem.cv()},1,1217)) goto _0;
			g->Check(ctx);
			ltQry=t6.get();
		}
		c.f.fLine=49;
		Res<Txt>(outResult)=ltQry.get();
_0:
_1:
;
	}

}
