extern int32_t vOK;
extern Txt K;
extern Txt K300;
extern Txt KBttnSave;
extern Txt KBttnSelectGroup;
extern Txt KCancel;
extern Txt KCategory;
extern Txt KCreateDate;
extern Txt KCreatedBy;
extern Txt KCreatedBy_20_3D_20_3A1;
extern Txt KDBQueries;
extern Txt KDiscard;
extern Txt KDisplayRole;
extern Txt KGroup;
extern Txt KKey;
extern Txt KQueryName;
extern Txt KSingle;
extern Txt KSystem_20Name;
extern Txt KUSER;
extern Txt KUpdateDate;
extern Txt KUpdatedBy;
extern Txt K__;
extern Txt KbAutoComplete;
extern Txt KbSaveRecord;
extern Txt KbttnClose;
extern Txt Kcode;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt Kcopy;
extern Txt Kdistinct;
extern Txt KeDBQuery;
extern Txt KisNew;
extern Txt Kjoin;
extern Txt Klength;
extern Txt KobjectName;
extern Txt Kpush;
extern Txt Kquery;
extern Txt KtFormHeader;
extern Txt KtSelectionMode;
extern Txt kLGJAiSueMjo;
extern Txt kifRyNcfJ4tA;
extern Txt kiin4rCiGwQ8;
extern Txt ko166k_hFrHs;
extern Txt kxBemVzOKO4U;
Asm4d_Proc proc_WDGT__CONFIGCOLUMNS;
Asm4d_Proc proc_WDGT__SELECT;
extern unsigned char D_proc_SBK__ADDMODIFYHNDL[];
void proc_SBK__ADDMODIFYHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__ADDMODIFYHNDL);
	if (!ctx->doingAbort) {
		Variant ltCategory;
		Obj loQry;
		Obj loItem;
		Txt ltHeaders;
		Col lcolCategories;
		Txt ltAlertMsg;
		Variant ltGroup;
		Col lcolItems;
		Bool lbOptionKeyDown;
		Obj l__4D__auto__iter__0;
		Obj l__4D__auto__iter__1;
		Bool lbCtrlKeyDown;
		Obj loResults;
		Obj ltoFormEvent;
		Col lcolMandatoryFields;
		Obj loFormEvent;
		Col lcolUserSelection;
		Bool lJCPEREZ__20241102;
		Txt ltHiddenCols;
		Obj loListItems;
		Txt ltHdrMap;
		Bool lbContinue;
		Txt ltWidths;
		Col lcolGroups;
		c.f.fLine=12;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Bool t0;
			c.f.fLine=15;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,546)) goto _0;
			Bool t1;
			if (g->Call(ctx,(PCV[]){t1.cv()},0,562)) goto _0;
			g->Check(ctx);
			lbCtrlKeyDown=t0.get()||t1.get();
		}
		{
			Variant t3;
			c.f.fLine=17;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t3.cv())) goto _0;
			Bool t4;
			if (g->OperationOnAny(ctx,6,t3.cv(),Value_null().cv(),t4.cv())) goto _0;
			if (!(t4.get())) goto _2;
		}
		{
			Variant t5;
			c.f.fLine=21;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t5.cv())) goto _0;
			Bool t6;
			if (g->OperationOnAny(ctx,6,t5.cv(),Long(1).cv(),t6.cv())) goto _0;
			if (!(t6.get())) goto _4;
		}
		goto _3;
_4:
_3:
		goto _5;
_2:
		{
			Variant t7;
			c.f.fLine=29;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t7.cv())) goto _0;
			Bool t8;
			if (g->OperationOnAny(ctx,6,t7.cv(),KbttnClose.cv(),t8.cv())) goto _0;
			if (!(t8.get())) goto _7;
		}
		{
			Obj t9;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t9.cv()},0,1466)) goto _0;
			Variant t10;
			if (g->GetMember(ctx,t9.cv(),KeDBQuery.cv(),t10.cv())) goto _0;
			Bool t11;
			if (g->OperationOnAny(ctx,7,t10.cv(),Value_null().cv(),t11.cv())) goto _0;
			if (!(t11.get())) goto _8;
		}
		{
			Obj t12;
			c.f.fLine=31;
			if (g->Call(ctx,(PCV[]){t12.cv()},0,1466)) goto _0;
			Variant t13;
			if (g->GetMember(ctx,t12.cv(),KeDBQuery.cv(),t13.cv())) goto _0;
			Variant t14;
			if (g->Call(ctx,(PCV[]){t14.cv(),t13.cv(),KisNew.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Bool t15;
			if (!g->GetValue(ctx,(PCV[]){t15.cv(),t14.cv(),nullptr})) goto _0;
			if (!(t15.get())) goto _9;
		}
		c.f.fLine=32;
		if (g->Call(ctx,(PCV[]){nullptr,kiin4rCiGwQ8.cv(),KDiscard.cv(),KCancel.cv()},3,162)) goto _0;
		g->Check(ctx);
		if (1!=Var<Long>(ctx,vOK).get()) goto _10;
		c.f.fLine=34;
		if (g->Call(ctx,(PCV[]){nullptr},0,270)) goto _0;
		g->Check(ctx);
_10:
		goto _11;
_9:
		c.f.fLine=37;
		if (g->Call(ctx,(PCV[]){nullptr},0,270)) goto _0;
		g->Check(ctx);
_11:
		goto _12;
_8:
		c.f.fLine=40;
		if (g->Call(ctx,(PCV[]){nullptr},0,270)) goto _0;
		g->Check(ctx);
_12:
		goto _6;
_7:
		{
			Variant t17;
			c.f.fLine=42;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t17.cv())) goto _0;
			Bool t18;
			if (g->OperationOnAny(ctx,6,t17.cv(),KBttnSave.cv(),t18.cv())) goto _0;
			if (!(t18.get())) goto _13;
		}
		{
			Col t19;
			c.f.fLine=48;
			if (g->Call(ctx,(PCV[]){t19.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolMandatoryFields=t19.get();
		}
		lbContinue=Bool(1).get();
		{
			Obj t20;
			c.f.fLine=52;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1466)) goto _0;
			Variant t21;
			if (g->GetMember(ctx,t20.cv(),KeDBQuery.cv(),t21.cv())) goto _0;
			Variant t22;
			if (g->GetMember(ctx,t21.cv(),KGroup.cv(),t22.cv())) goto _0;
			Bool t23;
			if (g->OperationOnAny(ctx,6,t22.cv(),K.cv(),t23.cv())) goto _0;
			if (!(t23.get())) goto _14;
		}
		c.f.fLine=53;
		if (g->Call(ctx,(PCV[]){nullptr,lcolMandatoryFields.cv(),Kpush.cv(),KGroup.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _15;
_14:
		{
			Obj t24;
			c.f.fLine=55;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1466)) goto _0;
			Variant t25;
			if (g->GetMember(ctx,t24.cv(),KeDBQuery.cv(),t25.cv())) goto _0;
			Obj t26;
			if (g->Call(ctx,(PCV[]){t26.cv()},0,1466)) goto _0;
			Variant t27;
			if (g->GetMember(ctx,t26.cv(),KeDBQuery.cv(),t27.cv())) goto _0;
			Variant t28;
			if (g->GetMember(ctx,t27.cv(),KGroup.cv(),t28.cv())) goto _0;
			Txt t29;
			if (g->Call(ctx,(PCV[]){t29.cv(),Long(32).cv()},1,90)) goto _0;
			Txt t30;
			if (!g->GetValue(ctx,(PCV[]){t30.cv(),t28.cv(),nullptr})) goto _0;
			Txt t31;
			if (g->Call(ctx,(PCV[]){t31.cv(),t30.cv(),t29.cv(),K__.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,t25.cv(),KGroup.cv(),t31.cv())) goto _0;
		}
_15:
		{
			Obj t32;
			c.f.fLine=58;
			if (g->Call(ctx,(PCV[]){t32.cv()},0,1466)) goto _0;
			Variant t33;
			if (g->GetMember(ctx,t32.cv(),KeDBQuery.cv(),t33.cv())) goto _0;
			Variant t34;
			if (g->GetMember(ctx,t33.cv(),KCategory.cv(),t34.cv())) goto _0;
			Bool t35;
			if (g->OperationOnAny(ctx,6,t34.cv(),K.cv(),t35.cv())) goto _0;
			if (!(t35.get())) goto _16;
		}
		c.f.fLine=59;
		if (g->Call(ctx,(PCV[]){nullptr,lcolMandatoryFields.cv(),Kpush.cv(),KCategory.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _17;
_16:
		{
			Obj t36;
			c.f.fLine=61;
			if (g->Call(ctx,(PCV[]){t36.cv()},0,1466)) goto _0;
			Variant t37;
			if (g->GetMember(ctx,t36.cv(),KeDBQuery.cv(),t37.cv())) goto _0;
			Obj t38;
			if (g->Call(ctx,(PCV[]){t38.cv()},0,1466)) goto _0;
			Variant t39;
			if (g->GetMember(ctx,t38.cv(),KeDBQuery.cv(),t39.cv())) goto _0;
			Variant t40;
			if (g->GetMember(ctx,t39.cv(),KCategory.cv(),t40.cv())) goto _0;
			Txt t41;
			if (g->Call(ctx,(PCV[]){t41.cv(),Long(32).cv()},1,90)) goto _0;
			Txt t42;
			if (!g->GetValue(ctx,(PCV[]){t42.cv(),t40.cv(),nullptr})) goto _0;
			Txt t43;
			if (g->Call(ctx,(PCV[]){t43.cv(),t42.cv(),t41.cv(),K__.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,t37.cv(),KCategory.cv(),t43.cv())) goto _0;
		}
_17:
		{
			Obj t44;
			c.f.fLine=64;
			if (g->Call(ctx,(PCV[]){t44.cv()},0,1466)) goto _0;
			Variant t45;
			if (g->GetMember(ctx,t44.cv(),KeDBQuery.cv(),t45.cv())) goto _0;
			Variant t46;
			if (g->GetMember(ctx,t45.cv(),KQueryName.cv(),t46.cv())) goto _0;
			Bool t47;
			if (g->OperationOnAny(ctx,6,t46.cv(),K.cv(),t47.cv())) goto _0;
			if (!(t47.get())) goto _18;
		}
		c.f.fLine=65;
		if (g->Call(ctx,(PCV[]){nullptr,lcolMandatoryFields.cv(),Kpush.cv(),KSystem_20Name.cv()},3,1500)) goto _0;
		g->Check(ctx);
_18:
		{
			Variant t48;
			c.f.fLine=68;
			if (g->Call(ctx,(PCV[]){t48.cv(),lcolMandatoryFields.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t49;
			if (g->OperationOnAny(ctx,5,t48.cv(),Num(0).cv(),t49.cv())) goto _0;
			if (!(t49.get())) goto _19;
		}
		{
			Txt t50;
			c.f.fLine=69;
			if (g->Call(ctx,(PCV[]){t50.cv(),Long(13).cv()},1,90)) goto _0;
			g->AddString(kxBemVzOKO4U.get(),t50.get(),ltAlertMsg.get());
		}
		{
			Txt t52;
			c.f.fLine=70;
			if (g->Call(ctx,(PCV[]){t52.cv(),Long(13).cv()},1,90)) goto _0;
			Variant t53;
			if (g->Call(ctx,(PCV[]){t53.cv(),lcolMandatoryFields.cv(),Kjoin.cv(),t52.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Variant t54;
			if (g->OperationOnAny(ctx,0,ltAlertMsg.cv(),t53.cv(),t54.cv())) goto _0;
			Txt t55;
			if (!g->GetValue(ctx,(PCV[]){t55.cv(),t54.cv(),nullptr})) goto _0;
			ltAlertMsg=t55.get();
		}
		lbContinue=Bool(0).get();
_19:
		if (!(lbContinue.get())) goto _20;
		{
			Obj t56;
			c.f.fLine=76;
			if (g->Call(ctx,(PCV[]){t56.cv()},0,1466)) goto _0;
			Variant t57;
			if (g->GetMember(ctx,t56.cv(),KeDBQuery.cv(),t57.cv())) goto _0;
			Variant t58;
			if (g->GetMember(ctx,t57.cv(),KDisplayRole.cv(),t58.cv())) goto _0;
			Bool t59;
			if (g->OperationOnAny(ctx,6,t58.cv(),K.cv(),t59.cv())) goto _0;
			if (!(t59.get())) goto _21;
		}
		{
			Obj t60;
			c.f.fLine=77;
			if (g->Call(ctx,(PCV[]){t60.cv()},0,1466)) goto _0;
			Variant t61;
			if (g->GetMember(ctx,t60.cv(),KeDBQuery.cv(),t61.cv())) goto _0;
			Obj t62;
			if (g->Call(ctx,(PCV[]){t62.cv()},0,1466)) goto _0;
			Variant t63;
			if (g->GetMember(ctx,t62.cv(),KeDBQuery.cv(),t63.cv())) goto _0;
			Variant t64;
			if (g->GetMember(ctx,t63.cv(),KQueryName.cv(),t64.cv())) goto _0;
			if (g->SetMember(ctx,t61.cv(),KDisplayRole.cv(),t64.cv())) goto _0;
		}
_21:
		{
			Obj t65;
			c.f.fLine=79;
			if (g->Call(ctx,(PCV[]){t65.cv()},0,1466)) goto _0;
			Variant t66;
			if (g->GetMember(ctx,t65.cv(),KeDBQuery.cv(),t66.cv())) goto _0;
			Obj t67;
			if (g->Call(ctx,(PCV[]){t67.cv()},0,1466)) goto _0;
			Variant t68;
			if (g->GetMember(ctx,t67.cv(),KeDBQuery.cv(),t68.cv())) goto _0;
			Variant t69;
			if (g->GetMember(ctx,t68.cv(),KGroup.cv(),t69.cv())) goto _0;
			Obj t70;
			if (g->Call(ctx,(PCV[]){t70.cv()},0,1466)) goto _0;
			Variant t71;
			if (g->GetMember(ctx,t70.cv(),KeDBQuery.cv(),t71.cv())) goto _0;
			Variant t72;
			if (g->GetMember(ctx,t71.cv(),KCategory.cv(),t72.cv())) goto _0;
			Variant t73;
			if (g->OperationOnAny(ctx,0,t69.cv(),t72.cv(),t73.cv())) goto _0;
			Obj t74;
			if (g->Call(ctx,(PCV[]){t74.cv()},0,1466)) goto _0;
			Variant t75;
			if (g->GetMember(ctx,t74.cv(),KeDBQuery.cv(),t75.cv())) goto _0;
			Variant t76;
			if (g->GetMember(ctx,t75.cv(),KQueryName.cv(),t76.cv())) goto _0;
			Variant t77;
			if (g->OperationOnAny(ctx,0,t73.cv(),t76.cv(),t77.cv())) goto _0;
			if (g->SetMember(ctx,t66.cv(),KKey.cv(),t77.cv())) goto _0;
		}
		{
			Obj t78;
			c.f.fLine=80;
			if (g->Call(ctx,(PCV[]){t78.cv()},0,1466)) goto _0;
			Variant t79;
			if (g->GetMember(ctx,t78.cv(),KeDBQuery.cv(),t79.cv())) goto _0;
			Variant t80;
			if (g->Call(ctx,(PCV[]){t80.cv(),t79.cv(),KisNew.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Bool t81;
			if (!g->GetValue(ctx,(PCV[]){t81.cv(),t80.cv(),nullptr})) goto _0;
			if (!(t81.get())) goto _22;
		}
		{
			Obj t82;
			c.f.fLine=81;
			if (g->Call(ctx,(PCV[]){t82.cv()},0,1466)) goto _0;
			Variant t83;
			if (g->GetMember(ctx,t82.cv(),KeDBQuery.cv(),t83.cv())) goto _0;
			Txt t84;
			if (g->Call(ctx,(PCV[]){t84.cv()},0,182)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t83.cv(),KCreatedBy.cv(),t84.cv())) goto _0;
		}
		{
			Obj t85;
			c.f.fLine=82;
			if (g->Call(ctx,(PCV[]){t85.cv()},0,1466)) goto _0;
			Variant t86;
			if (g->GetMember(ctx,t85.cv(),KeDBQuery.cv(),t86.cv())) goto _0;
			Date t87;
			if (g->Call(ctx,(PCV[]){t87.cv()},0,33)) goto _0;
			Date t88;
			t88=t87.get();
			if (g->SetMember(ctx,t86.cv(),KCreateDate.cv(),t88.cv())) goto _0;
		}
		goto _23;
_22:
		{
			Obj t89;
			c.f.fLine=84;
			if (g->Call(ctx,(PCV[]){t89.cv()},0,1466)) goto _0;
			Variant t90;
			if (g->GetMember(ctx,t89.cv(),KeDBQuery.cv(),t90.cv())) goto _0;
			Txt t91;
			if (g->Call(ctx,(PCV[]){t91.cv()},0,182)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t90.cv(),KUpdatedBy.cv(),t91.cv())) goto _0;
		}
		{
			Obj t92;
			c.f.fLine=85;
			if (g->Call(ctx,(PCV[]){t92.cv()},0,1466)) goto _0;
			Variant t93;
			if (g->GetMember(ctx,t92.cv(),KeDBQuery.cv(),t93.cv())) goto _0;
			Date t94;
			if (g->Call(ctx,(PCV[]){t94.cv()},0,33)) goto _0;
			Date t95;
			t95=t94.get();
			if (g->SetMember(ctx,t93.cv(),KUpdateDate.cv(),t95.cv())) goto _0;
		}
_23:
		{
			Obj t96;
			c.f.fLine=87;
			if (g->Call(ctx,(PCV[]){t96.cv()},0,1466)) goto _0;
			Bool t97;
			t97=Bool(1).get();
			if (g->SetMember(ctx,t96.cv(),KbSaveRecord.cv(),t97.cv())) goto _0;
		}
		c.f.fLine=88;
		if (g->Call(ctx,(PCV[]){nullptr},0,269)) goto _0;
		g->Check(ctx);
		goto _24;
_20:
		c.f.fLine=90;
		if (g->Call(ctx,(PCV[]){nullptr,ltAlertMsg.cv()},1,41)) goto _0;
		g->Check(ctx);
_24:
		goto _6;
_13:
		{
			Variant t98;
			c.f.fLine=93;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t98.cv())) goto _0;
			Bool t99;
			if (g->OperationOnAny(ctx,6,t98.cv(),KBttnSelectGroup.cv(),t99.cv())) goto _0;
			if (!(t99.get())) goto _25;
		}
		{
			Col t100;
			c.f.fLine=98;
			if (g->Call(ctx,(PCV[]){t100.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolItems=t100.get();
		}
		{
			Col t101;
			c.f.fLine=99;
			if (g->Call(ctx,(PCV[]){t101.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolGroups=t101.get();
		}
		ltHdrMap=KGroup.get();
		ltHeaders=KGroup.get();
		ltWidths=K300.get();
		ltHiddenCols=K.get();
		{
			Obj t102;
			c.f.fLine=106;
			if (g->Call(ctx,(PCV[]){t102.cv()},0,1482)) goto _0;
			Variant t103;
			if (g->Call(ctx,(PCV[]){t103.cv(),t102.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t104;
			if (g->Call(ctx,(PCV[]){t104.cv(),t103.cv(),Kquery.cv(),KCreatedBy_20_3D_20_3A1.cv(),KUSER.cv()},4,1498)) goto _0;
			Variant t105;
			if (g->Call(ctx,(PCV[]){t105.cv(),t104.cv(),Kdistinct.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			Col t106;
			if (!g->GetValue(ctx,(PCV[]){t106.cv(),t105.cv(),nullptr})) goto _0;
			lcolGroups=t106.get();
		}
		{
			Ref t107;
			c.f.fLine=108;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t107.cv(),ltGroup.cv(),nullptr})) goto _0;
			Obj t108;
			if (g->Call(ctx,(PCV[]){t108.cv(),t107.cv(),lcolGroups.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t108.get();
		}
_26:
		{
			Bool t109;
			if (g->Call(ctx,(PCV[]){t109.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t109.get())) goto _27;
		}
		{
			Obj t110;
			c.f.fLine=109;
			if (g->Call(ctx,(PCV[]){t110.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t110.get();
		}
		{
			Variant t111;
			c.f.fLine=110;
			if (!g->GetValue(ctx,(PCV[]){t111.cv(),ltGroup.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loItem.cv(),KGroup.cv(),t111.cv())) goto _0;
		}
		c.f.fLine=111;
		if (g->Call(ctx,(PCV[]){nullptr,lcolItems.cv(),Kpush.cv(),loItem.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _26;
_27:
		{
			Obj t112;
			l__4D__auto__iter__0=t112.get();
		}
		{
			Obj t113;
			c.f.fLine=114;
			if (g->Call(ctx,(PCV[]){t113.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t113.get();
		}
		{
			Txt t114;
			t114=ltHiddenCols.get();
			Txt t115;
			t115=ltWidths.get();
			Txt t116;
			t116=ltHdrMap.get();
			Txt t117;
			t117=ltHeaders.get();
			Col t118;
			c.f.fLine=115;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t117.cv(),t116.cv(),t115.cv(),t114.cv()},t118.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t118.cv())) goto _0;
		}
		c.f.fLine=116;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),K.cv())) goto _0;
		c.f.fLine=117;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t119;
			c.f.fLine=118;
			if (g->Call(ctx,(PCV[]){t119.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t119.cv())) goto _0;
		}
		{
			Variant t120;
			c.f.fLine=119;
			if (g->Call(ctx,(PCV[]){t120.cv(),lcolItems.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t120.cv())) goto _0;
		}
		{
			Bool t121;
			t121=Bool(1).get();
			c.f.fLine=120;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t121.cv())) goto _0;
		}
		{
			Variant t122;
			c.f.fLine=122;
			if (g->Call(ctx,(PCV[]){t122.cv(),lcolItems.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t123;
			if (g->OperationOnAny(ctx,5,t122.cv(),Num(0).cv(),t123.cv())) goto _0;
			if (!(t123.get())) goto _28;
		}
		{
			Obj t124;
			t124=loListItems.get();
			Col t125;
			c.f.fLine=123;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t124.cv()},t125.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t125.get();
		}
		{
			Variant t126;
			c.f.fLine=124;
			if (g->Call(ctx,(PCV[]){t126.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t127;
			if (g->OperationOnAny(ctx,6,t126.cv(),Num(1).cv(),t127.cv())) goto _0;
			if (!(t127.get())) goto _29;
		}
		{
			Obj t128;
			c.f.fLine=125;
			if (g->Call(ctx,(PCV[]){t128.cv()},0,1466)) goto _0;
			Variant t129;
			if (g->GetMember(ctx,t128.cv(),KeDBQuery.cv(),t129.cv())) goto _0;
			Variant t130;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t130.cv())) goto _0;
			Variant t131;
			if (g->GetMember(ctx,t130.cv(),KGroup.cv(),t131.cv())) goto _0;
			if (g->SetMember(ctx,t129.cv(),KGroup.cv(),t131.cv())) goto _0;
		}
_29:
		goto _30;
_28:
		c.f.fLine=129;
		if (g->Call(ctx,(PCV[]){nullptr,kifRyNcfJ4tA.cv()},1,41)) goto _0;
		g->Check(ctx);
_30:
		goto _6;
_25:
		{
			Variant t132;
			c.f.fLine=133;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t132.cv())) goto _0;
			Bool t133;
			if (g->OperationOnAny(ctx,6,t132.cv(),kLGJAiSueMjo.cv(),t133.cv())) goto _0;
			if (!(t133.get())) goto _31;
		}
		{
			Col t134;
			c.f.fLine=138;
			if (g->Call(ctx,(PCV[]){t134.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolItems=t134.get();
		}
		{
			Col t135;
			c.f.fLine=139;
			if (g->Call(ctx,(PCV[]){t135.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolGroups=t135.get();
		}
		ltHdrMap=KCategory.get();
		ltHeaders=KCategory.get();
		ltWidths=K300.get();
		ltHiddenCols=K.get();
		{
			Obj t136;
			c.f.fLine=146;
			if (g->Call(ctx,(PCV[]){t136.cv()},0,1482)) goto _0;
			Variant t137;
			if (g->Call(ctx,(PCV[]){t137.cv(),t136.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t138;
			if (g->Call(ctx,(PCV[]){t138.cv(),t137.cv(),Kquery.cv(),KCreatedBy_20_3D_20_3A1.cv(),KUSER.cv()},4,1498)) goto _0;
			Variant t139;
			if (g->Call(ctx,(PCV[]){t139.cv(),t138.cv(),Kdistinct.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			Col t140;
			if (!g->GetValue(ctx,(PCV[]){t140.cv(),t139.cv(),nullptr})) goto _0;
			lcolCategories=t140.get();
		}
		{
			Ref t141;
			c.f.fLine=148;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t141.cv(),ltCategory.cv(),nullptr})) goto _0;
			Obj t142;
			if (g->Call(ctx,(PCV[]){t142.cv(),t141.cv(),lcolCategories.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t142.get();
		}
_32:
		{
			Bool t143;
			if (g->Call(ctx,(PCV[]){t143.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t143.get())) goto _33;
		}
		{
			Obj t144;
			c.f.fLine=149;
			if (g->Call(ctx,(PCV[]){t144.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t144.get();
		}
		{
			Variant t145;
			c.f.fLine=150;
			if (!g->GetValue(ctx,(PCV[]){t145.cv(),ltCategory.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loItem.cv(),KCategory.cv(),t145.cv())) goto _0;
		}
		c.f.fLine=151;
		if (g->Call(ctx,(PCV[]){nullptr,lcolItems.cv(),Kpush.cv(),loItem.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _32;
_33:
		{
			Obj t146;
			l__4D__auto__iter__1=t146.get();
		}
		{
			Obj t147;
			c.f.fLine=154;
			if (g->Call(ctx,(PCV[]){t147.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t147.get();
		}
		{
			Txt t148;
			t148=ltHiddenCols.get();
			Txt t149;
			t149=ltWidths.get();
			Txt t150;
			t150=ltHdrMap.get();
			Txt t151;
			t151=ltHeaders.get();
			Col t152;
			c.f.fLine=155;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t151.cv(),t150.cv(),t149.cv(),t148.cv()},t152.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t152.cv())) goto _0;
		}
		c.f.fLine=156;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),K.cv())) goto _0;
		c.f.fLine=157;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t153;
			c.f.fLine=158;
			if (g->Call(ctx,(PCV[]){t153.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t153.cv())) goto _0;
		}
		{
			Variant t154;
			c.f.fLine=159;
			if (g->Call(ctx,(PCV[]){t154.cv(),lcolItems.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t154.cv())) goto _0;
		}
		{
			Bool t155;
			t155=Bool(1).get();
			c.f.fLine=160;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t155.cv())) goto _0;
		}
		{
			Variant t156;
			c.f.fLine=162;
			if (g->Call(ctx,(PCV[]){t156.cv(),lcolItems.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t157;
			if (g->OperationOnAny(ctx,5,t156.cv(),Num(0).cv(),t157.cv())) goto _0;
			if (!(t157.get())) goto _34;
		}
		{
			Obj t158;
			t158=loListItems.get();
			Col t159;
			c.f.fLine=163;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t158.cv()},t159.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t159.get();
		}
		{
			Variant t160;
			c.f.fLine=164;
			if (g->Call(ctx,(PCV[]){t160.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t161;
			if (g->OperationOnAny(ctx,6,t160.cv(),Num(1).cv(),t161.cv())) goto _0;
			if (!(t161.get())) goto _35;
		}
		{
			Obj t162;
			c.f.fLine=165;
			if (g->Call(ctx,(PCV[]){t162.cv()},0,1466)) goto _0;
			Variant t163;
			if (g->GetMember(ctx,t162.cv(),KeDBQuery.cv(),t163.cv())) goto _0;
			Variant t164;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t164.cv())) goto _0;
			Variant t165;
			if (g->GetMember(ctx,t164.cv(),KCategory.cv(),t165.cv())) goto _0;
			if (g->SetMember(ctx,t163.cv(),KCategory.cv(),t165.cv())) goto _0;
		}
_35:
		goto _36;
_34:
		c.f.fLine=169;
		if (g->Call(ctx,(PCV[]){nullptr,ko166k_hFrHs.cv()},1,41)) goto _0;
		g->Check(ctx);
_36:
		goto _6;
_31:
_6:
_5:
_0:
_1:
;
	}

}
