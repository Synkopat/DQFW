extern Txt K;
extern Txt K_20;
extern Txt K_20_3A;
extern Txt K_20_3A1;
extern Txt Kattributes;
extern Txt Klength;
extern Txt KlogicOPs;
extern Txt Koperators;
extern Txt Kparameters;
extern Txt KqryText;
extern Txt Kvalues;
extern unsigned char D_proc_DQFW__GETQUERYOBJ[];
void proc_DQFW__GETQUERYOBJ( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__GETQUERYOBJ);
	if (!ctx->doingAbort) {
		Txt ltIndex;
		Long liLine;
		Bool lJCPEREZ__20230206a;
		Obj l__4D__auto__iter__0;
		Obj loQrySettings;
		Bool lbValidParams;
		Txt ltAttr;
		Obj loQueryRequest;
		c.f.fLine=14;
		loQueryRequest=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=15;
		loQrySettings=Parm<Obj>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=16;
		if (g->SetMember(ctx,loQrySettings.cv(),KqryText.cv(),K.cv())) goto _0;
		{
			Col t0;
			c.f.fLine=17;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQrySettings.cv(),Kparameters.cv(),t0.cv())) goto _0;
		}
		{
			Variant t1;
			c.f.fLine=23;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t1.cv())) goto _0;
			Variant t2;
			if (g->GetMember(ctx,t1.cv(),Klength.cv(),t2.cv())) goto _0;
			Variant t3;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kvalues.cv(),t3.cv())) goto _0;
			Variant t4;
			if (g->GetMember(ctx,t3.cv(),Klength.cv(),t4.cv())) goto _0;
			Bool t5;
			if (g->OperationOnAny(ctx,6,t2.cv(),t4.cv(),t5.cv())) goto _0;
			lbValidParams=t5.get();
		}
		{
			Variant t6;
			c.f.fLine=24;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t6.cv())) goto _0;
			Variant t7;
			if (g->GetMember(ctx,t6.cv(),Klength.cv(),t7.cv())) goto _0;
			Variant t8;
			if (g->GetMember(ctx,loQueryRequest.cv(),Koperators.cv(),t8.cv())) goto _0;
			Variant t9;
			if (g->GetMember(ctx,t8.cv(),Klength.cv(),t9.cv())) goto _0;
			Bool t10;
			if (g->OperationOnAny(ctx,6,t7.cv(),t9.cv(),t10.cv())) goto _0;
			lbValidParams=lbValidParams.get()&&t10.get();
		}
		{
			Variant t12;
			c.f.fLine=25;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t12.cv())) goto _0;
			Variant t13;
			if (g->GetMember(ctx,t12.cv(),Klength.cv(),t13.cv())) goto _0;
			Variant t14;
			if (g->GetMember(ctx,loQueryRequest.cv(),KlogicOPs.cv(),t14.cv())) goto _0;
			Variant t15;
			if (g->GetMember(ctx,t14.cv(),Klength.cv(),t15.cv())) goto _0;
			Bool t16;
			if (g->OperationOnAny(ctx,6,t13.cv(),t15.cv(),t16.cv())) goto _0;
			lbValidParams=lbValidParams.get()&&t16.get();
		}
		{
			Variant t18;
			c.f.fLine=26;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t18.cv())) goto _0;
			Variant t19;
			if (g->GetMember(ctx,t18.cv(),Klength.cv(),t19.cv())) goto _0;
			Bool t20;
			if (g->OperationOnAny(ctx,5,t19.cv(),Num(0).cv(),t20.cv())) goto _0;
			lbValidParams=lbValidParams.get()&&t20.get();
		}
		if (!(lbValidParams.get())) goto _2;
		{
			Variant t22;
			c.f.fLine=29;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kvalues.cv(),t22.cv())) goto _0;
			if (g->SetMember(ctx,loQrySettings.cv(),Kparameters.cv(),t22.cv())) goto _0;
		}
		{
			Variant t23;
			c.f.fLine=30;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t23.cv())) goto _0;
			Variant t24;
			if (g->GetMember(ctx,t23.cv(),Long(0).cv(),t24.cv())) goto _0;
			Variant t25;
			if (g->OperationOnAny(ctx,0,t24.cv(),K_20.cv(),t25.cv())) goto _0;
			Variant t26;
			if (g->GetMember(ctx,loQueryRequest.cv(),Koperators.cv(),t26.cv())) goto _0;
			Variant t27;
			if (g->GetMember(ctx,t26.cv(),Long(0).cv(),t27.cv())) goto _0;
			Variant t28;
			if (g->OperationOnAny(ctx,0,t25.cv(),t27.cv(),t28.cv())) goto _0;
			Variant t29;
			if (g->OperationOnAny(ctx,0,t28.cv(),K_20_3A1.cv(),t29.cv())) goto _0;
			if (g->SetMember(ctx,loQrySettings.cv(),KqryText.cv(),t29.cv())) goto _0;
		}
		liLine=0;
		{
			Variant t30;
			c.f.fLine=32;
			if (g->GetMember(ctx,loQueryRequest.cv(),Kattributes.cv(),t30.cv())) goto _0;
			Ref t31;
			t31.setLocalRef(ctx,ltAttr.cv());
			Obj t32;
			if (g->Call(ctx,(PCV[]){t32.cv(),t31.cv(),t30.cv(),Long(1).cv()},3,1795)) goto _0;
			l__4D__auto__iter__0=t32.get();
		}
_3:
		{
			Bool t33;
			if (g->Call(ctx,(PCV[]){t33.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t33.get())) goto _4;
		}
		liLine=liLine.get()+1;
		{
			Long t35;
			t35=liLine.get()+1;
			Txt t36;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t36.cv(),t35.cv()},1,10)) goto _0;
			ltIndex=t36.get();
		}
		{
			Variant t37;
			c.f.fLine=35;
			if (g->GetMember(ctx,loQrySettings.cv(),KqryText.cv(),t37.cv())) goto _0;
			Variant t38;
			if (g->OperationOnAny(ctx,0,t37.cv(),K_20.cv(),t38.cv())) goto _0;
			Variant t39;
			if (g->GetMember(ctx,loQueryRequest.cv(),KlogicOPs.cv(),t39.cv())) goto _0;
			Variant t40;
			if (g->GetMember(ctx,t39.cv(),liLine.cv(),t40.cv())) goto _0;
			Variant t41;
			if (g->OperationOnAny(ctx,0,t38.cv(),t40.cv(),t41.cv())) goto _0;
			Variant t42;
			if (g->OperationOnAny(ctx,0,t41.cv(),K_20.cv(),t42.cv())) goto _0;
			Variant t43;
			if (g->OperationOnAny(ctx,0,t42.cv(),ltAttr.cv(),t43.cv())) goto _0;
			Variant t44;
			if (g->OperationOnAny(ctx,0,t43.cv(),K_20.cv(),t44.cv())) goto _0;
			Variant t45;
			if (g->GetMember(ctx,loQueryRequest.cv(),Koperators.cv(),t45.cv())) goto _0;
			Variant t46;
			if (g->GetMember(ctx,t45.cv(),liLine.cv(),t46.cv())) goto _0;
			Variant t47;
			if (g->OperationOnAny(ctx,0,t44.cv(),t46.cv(),t47.cv())) goto _0;
			Variant t48;
			if (g->OperationOnAny(ctx,0,t47.cv(),K_20_3A.cv(),t48.cv())) goto _0;
			Variant t49;
			if (g->OperationOnAny(ctx,0,t48.cv(),ltIndex.cv(),t49.cv())) goto _0;
			if (g->SetMember(ctx,loQrySettings.cv(),KqryText.cv(),t49.cv())) goto _0;
		}
		goto _3;
_4:
		{
			Obj t50;
			l__4D__auto__iter__0=t50.get();
		}
_2:
_0:
_1:
;
	}

}
