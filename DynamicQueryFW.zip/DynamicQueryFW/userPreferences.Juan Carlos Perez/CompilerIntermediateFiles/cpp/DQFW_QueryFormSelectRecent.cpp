extern Txt K;
extern Txt K400_2C100;
extern Txt KSingle;
extern Txt KSystem_2CLines;
extern Txt KbAutoComplete;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt KcolQryLines;
extern Txt Kcopy;
extern Txt Klength;
extern Txt Kpush;
extern Txt KtFormHeader;
extern Txt KtQueryName;
extern Txt KtSelectionMode;
extern Txt kUjF5du1y_4w;
extern Txt kh2tK_oDa4Jc;
Asm4d_Proc proc_WDGT__CONFIGCOLUMNS;
Asm4d_Proc proc_WDGT__SELECT;
extern unsigned char D_proc_DQFW__QUERYFORMSELECTRECENT[];
void proc_DQFW__QUERYFORMSELECTRECENT( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__QUERYFORMSELECTRECENT);
	if (!ctx->doingAbort) {
		Obj loItem;
		Txt ltHeaders;
		Col lcolItems;
		Txt ltCompOpList;
		Obj loRecentSys;
		Variant ltProperty;
		Obj l__4D__auto__iter__0;
		Col lcolRecentQueries;
		Obj l__4D__auto__iter__1;
		Col lcolRecent;
		Col lcolUserSelection;
		Obj loSystem;
		Bool lJCPEREZ__20241102;
		Txt ltHiddenCols;
		Obj loListItems;
		Txt ltHdrMap;
		Txt ltWidths;
		new ( outResult) Obj();
		c.f.fLine=14;
		{
			Variant t0;
			if (g->Call(ctx,(PCV[]){t0.cv(),Parm<Col>(ctx,inParams,inNbParam,1).cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Col t1;
			if (!g->GetValue(ctx,(PCV[]){t1.cv(),t0.cv(),nullptr})) goto _0;
			lcolRecentQueries=t1.get();
		}
		if (ctx->doingAbort) goto _0;
		{
			Obj t2;
			c.f.fLine=15;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loItem=t2.get();
		}
		{
			Col t3;
			c.f.fLine=21;
			if (g->Call(ctx,(PCV[]){t3.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolRecent=t3.get();
		}
		{
			Ref t4;
			t4.setLocalRef(ctx,loSystem.cv());
			Obj t5;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t5.cv(),t4.cv(),lcolRecentQueries.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t5.get();
		}
_2:
		{
			Bool t6;
			if (g->Call(ctx,(PCV[]){t6.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t6.get())) goto _3;
		}
		{
			Obj t7;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t7.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loRecentSys=t7.get();
		}
		{
			Ref t8;
			c.f.fLine=25;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t8.cv(),ltProperty.cv(),nullptr})) goto _0;
			Obj t9;
			if (g->Call(ctx,(PCV[]){t9.cv(),t8.cv(),loSystem.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t9.get();
		}
_4:
		{
			Bool t10;
			if (g->Call(ctx,(PCV[]){t10.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t10.get())) goto _5;
		}
		{
			Variant t11;
			c.f.fLine=26;
			if (!g->GetValue(ctx,(PCV[]){t11.cv(),ltProperty.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loRecentSys.cv(),KtQueryName.cv(),t11.cv())) goto _0;
		}
		{
			Variant t12;
			c.f.fLine=27;
			if (!g->GetValue(ctx,(PCV[]){t12.cv(),ltProperty.cv(),nullptr})) goto _0;
			Variant t13;
			if (g->GetMember(ctx,loSystem.cv(),t12.cv(),t13.cv())) goto _0;
			Variant t14;
			if (g->Call(ctx,(PCV[]){t14.cv(),t13.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loRecentSys.cv(),KcolQryLines.cv(),t14.cv())) goto _0;
		}
		goto _4;
_5:
		{
			Obj t15;
			l__4D__auto__iter__0=t15.get();
		}
		c.f.fLine=30;
		if (g->Call(ctx,(PCV[]){nullptr,lcolRecent.cv(),Kpush.cv(),loRecentSys.cv()},3,1500)) goto _0;
		g->Check(ctx);
		goto _2;
_3:
		{
			Obj t16;
			l__4D__auto__iter__1=t16.get();
		}
		ltHdrMap=kh2tK_oDa4Jc.get();
		ltHeaders=KSystem_2CLines.get();
		ltWidths=K400_2C100.get();
		ltHiddenCols=KcolQryLines.get();
		{
			Obj t17;
			c.f.fLine=38;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t17.get();
		}
		{
			Txt t18;
			t18=ltHiddenCols.get();
			Txt t19;
			t19=ltWidths.get();
			Txt t20;
			t20=ltHdrMap.get();
			Txt t21;
			t21=ltHeaders.get();
			Col t22;
			c.f.fLine=39;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t21.cv(),t20.cv(),t19.cv(),t18.cv()},t22.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t22.cv())) goto _0;
		}
		c.f.fLine=40;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),K.cv())) goto _0;
		c.f.fLine=41;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t23;
			c.f.fLine=42;
			if (g->Call(ctx,(PCV[]){t23.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t23.cv())) goto _0;
		}
		{
			Variant t24;
			c.f.fLine=43;
			if (g->Call(ctx,(PCV[]){t24.cv(),lcolRecent.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t24.cv())) goto _0;
		}
		{
			Bool t25;
			t25=Bool(1).get();
			c.f.fLine=44;
			if (g->SetMember(ctx,loListItems.cv(),KbAutoComplete.cv(),t25.cv())) goto _0;
		}
		{
			Variant t26;
			c.f.fLine=46;
			if (g->Call(ctx,(PCV[]){t26.cv(),lcolRecent.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t27;
			if (g->OperationOnAny(ctx,5,t26.cv(),Num(0).cv(),t27.cv())) goto _0;
			if (!(t27.get())) goto _6;
		}
		{
			Obj t28;
			t28=loListItems.get();
			Col t29;
			c.f.fLine=47;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t28.cv()},t29.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t29.get();
		}
		{
			Variant t30;
			c.f.fLine=48;
			if (g->Call(ctx,(PCV[]){t30.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t31;
			if (g->OperationOnAny(ctx,6,t30.cv(),Num(1).cv(),t31.cv())) goto _0;
			if (!(t31.get())) goto _7;
		}
		{
			Variant t32;
			c.f.fLine=49;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t32.cv())) goto _0;
			Obj t33;
			if (!g->GetValue(ctx,(PCV[]){t33.cv(),t32.cv(),nullptr})) goto _0;
			loItem=t33.get();
		}
_7:
		goto _8;
_6:
		c.f.fLine=53;
		if (g->Call(ctx,(PCV[]){nullptr,kUjF5du1y_4w.cv()},1,41)) goto _0;
		g->Check(ctx);
_8:
		c.f.fLine=57;
		Res<Obj>(outResult)=loItem.get();
_0:
_1:
;
	}

}
