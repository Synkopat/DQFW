extern Txt KBaseEntity;
extern Txt KBaseEntity_20_3D_20_3A1;
extern Txt KCategory;
extern Txt KDBQueries;
extern Txt KGroup;
extern Txt KID;
extern Txt KKey;
extern Txt KQueryName;
extern Txt K_20AND_20Group_20_3D_20_3A2;
extern Txt K_2ANEW__BASEENTITY;
extern Txt K_2ANEW__CATEGORY;
extern Txt K_2ANEW__GROUP;
extern Txt K_2ANEW__QUERY;
extern Txt Kfirst;
extern Txt Klength;
extern Txt Knew;
extern Txt Kquery;
extern Txt Ksave;
extern Txt kbOrzFr4P_io;
extern Txt kmLbBRNjeatk;
Asm4d_Proc proc_UTIL__SETOBJVALUES;
Asm4d_Proc proc_UTIL__VALIDATEATTRNAME;
extern unsigned char D_proc_SBK__SETSYSTEM[];
void proc_SBK__SETSYSTEM( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__SETSYSTEM);
	if (!ctx->doingAbort) {
		Obj leDBQuery;
		Bool lbAddIfNeeded;
		Obj lesDBQueries;
		Bool lJCPEREZ__20241102;
		Obj loDBQueryPK;
		new ( outResult) Long();
		c.f.fLine=13;
		Res<Long>(outResult)=0;
		lbAddIfNeeded=Bool(1).get();
		{
			Long t0;
			t0=inNbExplicitParam;
			if (2>t0.get()) goto _2;
		}
		c.f.fLine=20;
		lbAddIfNeeded=Parm<Bool>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
_2:
		{
			Obj t2;
			c.f.fLine=27;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loDBQueryPK=t2.get();
		}
		c.f.fLine=28;
		if (g->SetMember(ctx,loDBQueryPK.cv(),KBaseEntity.cv(),K_2ANEW__BASEENTITY.cv())) goto _0;
		c.f.fLine=29;
		if (g->SetMember(ctx,loDBQueryPK.cv(),KGroup.cv(),K_2ANEW__GROUP.cv())) goto _0;
		c.f.fLine=30;
		if (g->SetMember(ctx,loDBQueryPK.cv(),KCategory.cv(),K_2ANEW__CATEGORY.cv())) goto _0;
		c.f.fLine=31;
		if (g->SetMember(ctx,loDBQueryPK.cv(),KQueryName.cv(),K_2ANEW__QUERY.cv())) goto _0;
		{
			Obj t3;
			c.f.fLine=33;
			t3=Parm<Obj>(ctx,inParams,inNbParam,1).get();
			Obj t4;
			t4=loDBQueryPK.get();
			proc_UTIL__SETOBJVALUES(glob,ctx,2,2,(PCV[]){t4.cv(),t3.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		if (ctx->doingAbort) goto _0;
		{
			Obj t5;
			c.f.fLine=35;
			if (g->Call(ctx,(PCV[]){t5.cv()},0,1482)) goto _0;
			Variant t6;
			if (g->Call(ctx,(PCV[]){t6.cv(),t5.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t7;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_3D_20_3A2.get(),t7.get());
			Txt t8;
			g->AddString(t7.get(),kmLbBRNjeatk.get(),t8.get());
			Txt t9;
			g->AddString(t8.get(),kbOrzFr4P_io.get(),t9.get());
			Variant t10;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KBaseEntity.cv(),t10.cv())) goto _0;
			Variant t11;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KGroup.cv(),t11.cv())) goto _0;
			Variant t12;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KCategory.cv(),t12.cv())) goto _0;
			Variant t13;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KQueryName.cv(),t13.cv())) goto _0;
			Variant t14;
			if (g->Call(ctx,(PCV[]){t14.cv(),t6.cv(),Kquery.cv(),t9.cv(),t10.cv(),t11.cv(),t12.cv(),t13.cv()},7,1498)) goto _0;
			Obj t15;
			if (!g->GetValue(ctx,(PCV[]){t15.cv(),t14.cv(),nullptr})) goto _0;
			lesDBQueries=t15.get();
		}
		{
			Variant t16;
			c.f.fLine=37;
			if (g->GetMember(ctx,lesDBQueries.cv(),Klength.cv(),t16.cv())) goto _0;
			Bool t17;
			if (g->OperationOnAny(ctx,12,t16.cv(),Num(1).cv(),t17.cv())) goto _0;
			if (!(t17.get())) goto _3;
		}
		{
			Variant t18;
			c.f.fLine=38;
			if (g->Call(ctx,(PCV[]){t18.cv(),lesDBQueries.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t19;
			if (!g->GetValue(ctx,(PCV[]){t19.cv(),t18.cv(),nullptr})) goto _0;
			leDBQuery=t19.get();
		}
		goto _4;
_3:
		if (!(lbAddIfNeeded.get())) goto _5;
		{
			Obj t20;
			c.f.fLine=42;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1482)) goto _0;
			Variant t21;
			if (g->Call(ctx,(PCV[]){t21.cv(),t20.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t22;
			if (g->Call(ctx,(PCV[]){t22.cv(),t21.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t23;
			if (!g->GetValue(ctx,(PCV[]){t23.cv(),t22.cv(),nullptr})) goto _0;
			leDBQuery=t23.get();
		}
		{
			Obj t24;
			c.f.fLine=43;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1482)) goto _0;
			Variant t25;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KBaseEntity.cv(),t25.cv())) goto _0;
			Txt t26;
			if (!g->GetValue(ctx,(PCV[]){t26.cv(),t25.cv(),nullptr})) goto _0;
			Txt t27;
			proc_UTIL__VALIDATEATTRNAME(glob,ctx,2,2,(PCV[]){t24.cv(),t26.cv()},t27.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,leDBQuery.cv(),KBaseEntity.cv(),t27.cv())) goto _0;
		}
		{
			Variant t28;
			c.f.fLine=44;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KGroup.cv(),t28.cv())) goto _0;
			if (g->SetMember(ctx,leDBQuery.cv(),KGroup.cv(),t28.cv())) goto _0;
		}
		{
			Variant t29;
			c.f.fLine=45;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KCategory.cv(),t29.cv())) goto _0;
			if (g->SetMember(ctx,leDBQuery.cv(),KCategory.cv(),t29.cv())) goto _0;
		}
		{
			Variant t30;
			c.f.fLine=46;
			if (g->GetMember(ctx,loDBQueryPK.cv(),KQueryName.cv(),t30.cv())) goto _0;
			if (g->SetMember(ctx,leDBQuery.cv(),KQueryName.cv(),t30.cv())) goto _0;
		}
		{
			Variant t31;
			c.f.fLine=47;
			if (g->GetMember(ctx,leDBQuery.cv(),KBaseEntity.cv(),t31.cv())) goto _0;
			Variant t32;
			if (g->GetMember(ctx,leDBQuery.cv(),KGroup.cv(),t32.cv())) goto _0;
			Variant t33;
			if (g->OperationOnAny(ctx,0,t31.cv(),t32.cv(),t33.cv())) goto _0;
			Variant t34;
			if (g->GetMember(ctx,leDBQuery.cv(),KCategory.cv(),t34.cv())) goto _0;
			Variant t35;
			if (g->OperationOnAny(ctx,0,t33.cv(),t34.cv(),t35.cv())) goto _0;
			Variant t36;
			if (g->GetMember(ctx,leDBQuery.cv(),KQueryName.cv(),t36.cv())) goto _0;
			Variant t37;
			if (g->OperationOnAny(ctx,0,t35.cv(),t36.cv(),t37.cv())) goto _0;
			if (g->SetMember(ctx,leDBQuery.cv(),KKey.cv(),t37.cv())) goto _0;
		}
_5:
_4:
		{
			Bool t38;
			t38=!leDBQuery.isNull();
			if (!(t38.get())) goto _6;
		}
		{
			Obj t39;
			c.f.fLine=54;
			t39=Parm<Obj>(ctx,inParams,inNbParam,1).get();
			Obj t40;
			t40=leDBQuery.get();
			proc_UTIL__SETOBJVALUES(glob,ctx,2,2,(PCV[]){t40.cv(),t39.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		if (ctx->doingAbort) goto _0;
		c.f.fLine=55;
		if (g->Call(ctx,(PCV[]){nullptr,leDBQuery.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
		{
			Variant t41;
			c.f.fLine=56;
			if (g->GetMember(ctx,leDBQuery.cv(),KID.cv(),t41.cv())) goto _0;
			Long t42;
			if (!g->GetValue(ctx,(PCV[]){t42.cv(),t41.cv(),nullptr})) goto _0;
			Res<Long>(outResult)=t42.get();
		}
_6:
		c.f.fLine=59;
		Res<Long>(outResult)=Res<Long>(outResult).get();
_0:
_1:
;
	}

}
