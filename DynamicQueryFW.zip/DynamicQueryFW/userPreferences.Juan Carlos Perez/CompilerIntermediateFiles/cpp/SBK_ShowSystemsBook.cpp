extern Txt KSystems_20Book;
extern Txt K__;
extern Txt KtDBQueriesTitle;
extern Txt KtFormHeader;
extern Txt KtQueryTable;
extern Txt kJcmVSB$WMo0;
extern Txt kkhHWtXAdhMw;
extern Txt kyESkQ4NjOg0;
Asm4d_Proc proc_WIND__OPENWINDOW;
extern unsigned char D_proc_SBK__SHOWSYSTEMSBOOK[];
void proc_SBK__SHOWSYSTEMSBOOK( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__SHOWSYSTEMSBOOK);
	if (!ctx->doingAbort) {
		Long liWinRef;
		Obj loDBQueries;
		Ptr lpDBQueriesTable;
		Long liUpperCenter;
		Long liFormHeight;
		Long liFormWidth;
		Bool lJCPEREZ__20241102;
		Txt ltDBQueriesForm;
		c.f.fLine=10;
		lpDBQueriesTable=Parm<Ptr>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Ref t0;
			t0.setLocalRef(ctx,liFormHeight.cv());
			Ref t1;
			t1.setLocalRef(ctx,liFormWidth.cv());
			c.f.fLine=16;
			if (g->Call(ctx,(PCV[]){nullptr,kyESkQ4NjOg0.cv(),t1.cv(),t0.cv()},3,674)) goto _0;
			g->Check(ctx);
		}
		liUpperCenter=6;
		ltDBQueriesForm=kyESkQ4NjOg0.get();
		{
			Obj t2;
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loDBQueries=t2.get();
		}
		{
			Ptr t3;
			c.f.fLine=23;
			if (!g->GetValue(ctx,(PCV[]){t3.cv(),lpDBQueriesTable.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loDBQueries.cv(),kJcmVSB$WMo0.cv(),t3.cv())) goto _0;
		}
		{
			Ptr t4;
			c.f.fLine=24;
			if (!g->GetValue(ctx,(PCV[]){t4.cv(),lpDBQueriesTable.cv(),nullptr})) goto _0;
			Long t5;
			if (g->Call(ctx,(PCV[]){t5.cv(),t4.cv()},1,252)) goto _0;
			g->Check(ctx);
			Txt t6;
			if (g->Call(ctx,(PCV[]){t6.cv(),t5.cv()},1,256)) goto _0;
			if (g->SetMember(ctx,loDBQueries.cv(),kkhHWtXAdhMw.cv(),t6.cv())) goto _0;
		}
		{
			Variant t7;
			c.f.fLine=25;
			if (g->GetMember(ctx,loDBQueries.cv(),kkhHWtXAdhMw.cv(),t7.cv())) goto _0;
			Txt t8;
			if (g->Call(ctx,(PCV[]){t8.cv(),Long(32).cv()},1,90)) goto _0;
			Txt t9;
			if (!g->GetValue(ctx,(PCV[]){t9.cv(),t7.cv(),nullptr})) goto _0;
			Txt t10;
			if (g->Call(ctx,(PCV[]){t10.cv(),t9.cv(),K__.cv(),t8.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,loDBQueries.cv(),KtDBQueriesTitle.cv(),t10.cv())) goto _0;
		}
		{
			Variant t11;
			c.f.fLine=26;
			if (g->GetMember(ctx,loDBQueries.cv(),KtDBQueriesTitle.cv(),t11.cv())) goto _0;
			if (g->SetMember(ctx,loDBQueries.cv(),KtFormHeader.cv(),t11.cv())) goto _0;
		}
		{
			Variant t12;
			c.f.fLine=27;
			if (g->GetMember(ctx,loDBQueries.cv(),kkhHWtXAdhMw.cv(),t12.cv())) goto _0;
			if (g->SetMember(ctx,loDBQueries.cv(),KtQueryTable.cv(),t12.cv())) goto _0;
		}
		{
			Ptr t13;
			Txt t14;
			t14=ltDBQueriesForm.get();
			Txt t15;
			t15=KSystems_20Book.get();
			Long t16;
			t16=8;
			Long t17;
			t17=liUpperCenter.get();
			Long t18;
			t18=liFormHeight.get();
			Long t19;
			t19=liFormWidth.get();
			Long t20;
			c.f.fLine=31;
			proc_WIND__OPENWINDOW(glob,ctx,6,7,(PCV[]){t19.cv(),t18.cv(),t17.cv(),t16.cv(),t15.cv(),t14.cv(),t13.cv()},t20.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			liWinRef=t20.get();
		}
		c.f.fLine=32;
		if (g->Call(ctx,(PCV[]){nullptr,ltDBQueriesForm.cv(),loDBQueries.cv()},2,40)) goto _0;
		g->Check(ctx);
_0:
_1:
;
	}

}
