#include "$asm4d.h"
#include "cp4drt_shared.h"
#include "legacy_language_types.h"
Txt K;
Txt K150_2C300;
Txt K300;
Txt K300_2C100;
Txt K300_2C100_2C0;
Txt K300_2C300;
Txt K300_2C300_2C300;
Txt K400_2C100;
Txt KADVANCED;
Txt KAND;
Txt KAND_20_28;
Txt KAccept;
Txt KAdv;
Txt KAdvanced;
Txt KAlias;
Txt KAlias_2CAttribute;
Txt KAnd;
Txt KAnd_20_28;
Txt KAttribute;
Txt KBASIC;
Txt KBASIC__SHORTCUTS;
Txt KBaseEntity;
Txt KBaseEntity_20_3D_20_3A1;
Txt KBasic;
Txt KBttnAdd;
Txt KBttnAddQuestion;
Txt KBttnAddSystem;
Txt KBttnDelQuestion;
Txt KBttnDelete;
Txt KBttnRunQuery;
Txt KBttnSave;
Txt KBttnSaveSystem;
Txt KBttnSelectGroup;
Txt KCOMPANY__ID;
Txt KCancel;
Txt KCategory;
Txt KCategory_20_3D_20_3A1;
Txt KCompanies;
Txt KComparisonOps;
Txt KContainis;
Txt KCountries;
Txt KCountryOfOrigin;
Txt KCountry__ISO2;
Txt KCreateDate;
Txt KCreatedBy;
Txt KCreatedBy_20_3D_20_3A1;
Txt KDBAliases;
Txt KDBQueries;
Txt KDONE;
Txt KDQFW__QueryTable;
Txt KDataClass;
Txt KDelete;
Txt KDiscard;
Txt KDisplayQryText;
Txt KDisplayRole;
Txt KDone;
Txt KEND;
Txt KERROR__Handler;
Txt KEngName;
Txt KEngOverview;
Txt KGenres;
Txt KGroup;
Txt KGroup_20_3D_20_3A1;
Txt KID;
Txt KIsActive;
Txt KIsIndexed;
Txt KIs_20equal_20to;
Txt KIs_20greater_20than;
Txt KIs_20less_20than;
Txt KIs_20not_20equal_20to;
Txt KKey;
Txt KLeave;
Txt KLogicOps;
Txt KMovieID;
Txt KMovies;
Txt KNEW__QUERY__LINE;
Txt KNONE;
Txt KName;
Txt KNew_20Query_20Line;
Txt KOK;
Txt KOR;
Txt KOR_20_28;
Txt KObjectName;
Txt KObjectType;
Txt KObjectType_20_3D_20_3A1;
Txt KOr;
Txt KOr_20_28;
Txt KOriginalTitle;
Txt KParentDataClass;
Txt KProducers;
Txt KQryLines;
Txt KQryParams;
Txt KQryText;
Txt KQry__;
Txt KQueryName;
Txt KQueryName_20_3D_20_3A1;
Txt KRating;
Txt KReleaseDate;
Txt KRole_2CLines;
Txt KRuntime;
Txt KSBK__AddModify;
Txt KSBK__Manager;
Txt KSBK__Search;
Txt KSHORTCUTS;
Txt KSTART;
Txt KSTART_2FEND;
Txt KSave;
Txt KSearch_20;
Txt KSearch_20Database;
Txt KSelect_20a_20Role;
Txt KSelect_20an_20Item;
Txt KSelection_20List;
Txt KSingle;
Txt KSortNo;
Txt KSystem_20Name;
Txt KSystem_2CLines;
Txt KSystems_20Book;
Txt KTMDB__ID;
Txt KTMDB__ID_20_3D_20_3A1;
Txt KTRUE;
Txt KThis_2E;
Txt KTitle;
Txt KUI__SEARCH;
Txt KUSER;
Txt KUpdateDate;
Txt KUpdatedBy;
Txt K_20;
Txt K_20AND_20Group_20_23_20_3A2;
Txt K_20AND_20Group_20_3D_20_3A2;
Txt K_20IN_20_3A1;
Txt K_20_22_20;
Txt K_20_3A;
Txt K_20_3A1;
Txt K_20_3D_20_3A1;
Txt K_20system_2E_2E_3F;
Txt K_21_3D;
Txt K_23;
Txt K_29_20AND;
Txt K_29_20And;
Txt K_29_20OR;
Txt K_29_20Or;
Txt K_2ANEW__BASEENTITY;
Txt K_2ANEW__CATEGORY;
Txt K_2ANEW__GROUP;
Txt K_2ANEW__QUERY;
Txt K_2C;
Txt K_2C_20;
Txt K_2E;
Txt K_2F;
Txt K_3A;
Txt K_3B;
Txt K_3C;
Txt K_3C_3D;
Txt K_3D;
Txt K_3D_3D;
Txt K_3E;
Txt K_3E_3D;
Txt K_40;
Txt K_40SHORTCUTS_40;
Txt K_7B_7D;
Txt K_7C;
Txt K_7C_40;
Txt K__;
Txt Kattribute;
Txt Kattributes;
Txt KautoFilled;
Txt KbAutoComplete;
Txt KbEnableGrouping;
Txt KbFullAccess;
Txt KbHidden;
Txt KbHidden_20_3D_20_3A1;
Txt KbIsAdminUser;
Txt KbSaveRecord;
Txt KbSuccess;
Txt KbUpdateCache;
Txt KbUserSelected;
Txt KbttnAllRecords;
Txt KbttnCancel;
Txt KbttnClose;
Txt KbttnCloseSystem;
Txt KbttnExport;
Txt KbttnHideAdv;
Txt KbttnImport;
Txt KbttnLoadSystem_40;
Txt KbttnRecent_40;
Txt KbttnRun_40;
Txt KbttnSaveQueries;
Txt KbttnSelect;
Txt KbttnShortcut_40;
Txt KbttnShowAdv;
Txt KcharSet;
Txt Kclear;
Txt Kcode;
Txt Kcol;
Txt KcolCollection;
Txt KcolLBSetup;
Txt KcolListItems;
Txt KcolOperators;
Txt KcolOrigList;
Txt KcolQryLines;
Txt KcolRQ;
Txt KcolsDelim;
Txt KcolumnsMap;
Txt Kcombine;
Txt Kcopy;
Txt Kdistinct;
Txt Kdrop;
Txt KeDBQuery;
Txt KesSystems;
Txt Kextract;
Txt KfieldType;
Txt Kfile2Import;
Txt KfilePath;
Txt Kfirst;
Txt KfullName;
Txt Kgenres;
Txt Kget;
Txt KgetInfo;
Txt KgetText;
Txt KheaderRow;
Txt KiAdd2Selection;
Txt KiCreated;
Txt KiHdrLineIndx;
Txt KiItemIndx;
Txt KiPos;
Txt KiQryLineIndx;
Txt KiQrySelection;
Txt KiSkipped;
Txt KiUpdated;
Txt KiWidth;
Txt KiWinRef;
Txt Kid;
Txt KindexOf;
Txt Kindexed;
Txt Kindices;
Txt Kindx;
Txt Kinsert;
Txt KisNew;
Txt Kiso__3166__1;
Txt Kjoin;
Txt Kjsn;
Txt Kkind;
Txt KlbItemListMulti;
Txt KlbItemList_40;
Txt KlbQryLines;
Txt KlbQryLines_40;
Txt KlbSystemLines;
Txt Klength;
Txt KlogicOP;
Txt KlogicOPs;
Txt KlogicOp;
Txt Kmax;
Txt Kname;
Txt Knew;
Txt KnewSelection;
Txt KoHdrLine;
Txt KoItem;
Txt KoLogicOperators;
Txt KoNewQryLine;
Txt KoObject;
Txt KoQryLine;
Txt KobjectName;
Txt Koperator;
Txt Koperators;
Txt Kor;
Txt Koriginal__title;
Txt Koverview;
Txt Kparameters;
Txt KplatformPath;
Txt KprimaryKey;
Txt Kpush;
Txt KqryLines;
Txt KqryText;
Txt KqryValue;
Txt KqryValue_20_3D_20_3A1;
Txt Kquery;
Txt KrbAdd2Selection;
Txt KrbQrySelection;
Txt KrelatedEntities;
Txt KrelatedEntity;
Txt Krelated_40;
Txt Krelease__date;
Txt Kremove;
Txt Kresult;
Txt KrowsDelim;
Txt Kruntime;
Txt Ksave;
Txt KsetText;
Txt Kstorage;
Txt Ksuccess;
Txt Ksum;
Txt KtAlias;
Txt KtComparison;
Txt KtCurPage;
Txt KtDBQueriesTitle;
Txt KtDisplayName;
Txt KtError;
Txt KtFormHeader;
Txt KtHeader;
Txt KtLogic;
Txt KtName;
Txt KtOperator;
Txt KtQueryName;
Txt KtQueryTable;
Txt KtSelectionMode;
Txt KtShorcutsType;
Txt KtVariable;
Txt KtWildCard;
Txt KtWildcard;
Txt Ktitle;
Txt KtoCollection;
Txt KtoObject;
Txt KtotalRows;
Txt Ktouched;
Txt Ktype;
Txt Kundefined;
Txt KvValue;
Txt Kvalues;
Txt Kvote__average;
Txt k0Y5ZI0AruYM;
Txt k0hyJBtb3YKs;
Txt k1$MufgeWnJs;
Txt k34HMjgGobfs;
Txt k37ob$gUXo40;
Txt k4YwHrlt0lGo;
Txt k5eF30BpGehY;
Txt k5hs0QWHiwao;
Txt k6eRd$w4LQWE;
Txt k7aUcEud5d8s;
Txt k7nPzzMJ4l8k;
Txt k8pbYXc0IDa4;
Txt k99ZvUtw5fTk;
Txt k9HkhWTimNqc;
Txt k9IogFu290Rs;
Txt kA3$zPm7Wdtc;
Txt kBK2Q7apxEgw;
Txt kBsHDkvsGrPw;
Txt kBsrRGl7CXWk;
Txt kCPE6gzua87w;
Txt kEm7af4vYXiQ;
Txt kFC3mrBPpIRQ;
Txt kFEAgzPXQQ1U;
Txt kF_fhco9Ukug;
Txt kFft24fqABwU;
Txt kGk4SEXhP$g4;
Txt kGpkCbRdAut0;
Txt kHWbpQfb3ej0;
Txt kHrlR6C2oH1s;
Txt kI9o4oFrPi2g;
Txt kIbq0A3jgcHQ;
Txt kIzdY4SXjrXA;
Txt kJcmVSB$WMo0;
Txt kJpMovZgJmOE;
Txt kK0xZCxy7G4Y;
Txt kKF5$aMVUyGE;
Txt kLFmVOfq3Rog;
Txt kLGJAiSueMjo;
Txt kLceznZrfsTE;
Txt kM44XBFxGaXg;
Txt kM7ZrSE1z4ns;
Txt kME8WkbwCo5U;
Txt kMzsyXlqrMYY;
Txt kOJqFOvTiTzk;
Txt kRxZpk1vyTOQ;
Txt kSQrkHbQsyew;
Txt kSw3pZ8WhbHE;
Txt kTPKCwQqjmqo;
Txt kUUFh9UQqW4I;
Txt kUYzHRa1RkIw;
Txt kUjF5du1y_4w;
Txt kV4hd9u0tSd4;
Txt kVMWRzE2WNPY;
Txt kVfh0oqO1WwE;
Txt kVn4UTeilKOI;
Txt kW4zrIKzg05Q;
Txt kWs_Sv0eaXFo;
Txt kXe$hkKzzxyk;
Txt kY$vPzVyalUU;
Txt kY6jJBKNw4xE;
Txt kYK1g15csO4w;
Txt kYhLxOkZaZqg;
Txt kbOrzFr4P_io;
Txt kcshqzox9NQc;
Txt kdWqu0dBKCLQ;
Txt kdfhMtAt0bDs;
Txt kdhneN13oy0I;
Txt keDIZs3EOHqQ;
Txt keYpYHsodZMQ;
Txt kg9WZ56E4v0o;
Txt kguJir0$ZYI8;
Txt kh2tK_oDa4Jc;
Txt kiHFsVAYKZIQ;
Txt kifRyNcfJ4tA;
Txt kiin4rCiGwQ8;
Txt kjUh3rfCnjoI;
Txt kkFRmeFTH3a4;
Txt kkFuTiDDdsWI;
Txt kkhHWtXAdhMw;
Txt klQSV4ZoYWzw;
Txt klQq_$TIrnvA;
Txt kmLbBRNjeatk;
Txt knB7uuVmo8Xo;
Txt knBbNEZaGk_I;
Txt knT_OmB8KgS4;
Txt knVPnk6aYtd4;
Txt ko166k_hFrHs;
Txt kohe2eiRGiCQ;
Txt kpBUF4YZPrek;
Txt kqDYe8_Lb36A;
Txt krAvNTkjyYAg;
Txt ksjVmVct_m1g;
Txt ksqpcsLWR6go;
Txt ksv03rMKIa68;
Txt kt24wFY1HOc8;
Txt ku2OcsofPKtU;
Txt kumdMK_s5sbI;
Txt kvMa7T0CfUPc;
Txt kx70Q3Jyepmo;
Txt kxBemVzOKO4U;
Txt kyB6TMG4mH1Q;
Txt kyESkQ4NjOg0;
Txt kzcH0gI8C0HI;

struct Txt_info { Txt *t; const char16_t *s; size_t n;};
static const Txt_info constants[]=
{
	{&K,nullptr,0},
	{&K150_2C300,u"150,300",7},
	{&K300,u"300",3},
	{&K300_2C100,u"300,100",7},
	{&K300_2C100_2C0,u"300,100,0",9},
	{&K300_2C300,u"300,300",7},
	{&K300_2C300_2C300,u"300,300,300",11},
	{&K400_2C100,u"400,100",7},
	{&KADVANCED,u"ADVANCED",8},
	{&KAND,u"AND",3},
	{&KAND_20_28,u"AND (",5},
	{&KAccept,u"Accept",6},
	{&KAdv,u"Adv",3},
	{&KAdvanced,u"Advanced",8},
	{&KAlias,u"Alias",5},
	{&KAlias_2CAttribute,u"Alias,Attribute",15},
	{&KAnd,u"And",3},
	{&KAnd_20_28,u"And (",5},
	{&KAttribute,u"Attribute",9},
	{&KBASIC,u"BASIC",5},
	{&KBASIC__SHORTCUTS,u"BASIC_SHORTCUTS",15},
	{&KBaseEntity,u"BaseEntity",10},
	{&KBaseEntity_20_3D_20_3A1,u"BaseEntity = :1",15},
	{&KBasic,u"Basic",5},
	{&KBttnAdd,u"BttnAdd",7},
	{&KBttnAddQuestion,u"BttnAddQuestion",15},
	{&KBttnAddSystem,u"BttnAddSystem",13},
	{&KBttnDelQuestion,u"BttnDelQuestion",15},
	{&KBttnDelete,u"BttnDelete",10},
	{&KBttnRunQuery,u"BttnRunQuery",12},
	{&KBttnSave,u"BttnSave",8},
	{&KBttnSaveSystem,u"BttnSaveSystem",14},
	{&KBttnSelectGroup,u"BttnSelectGroup",15},
	{&KCOMPANY__ID,u"COMPANY_ID",10},
	{&KCancel,u"Cancel",6},
	{&KCategory,u"Category",8},
	{&KCategory_20_3D_20_3A1,u"Category = :1",13},
	{&KCompanies,u"Companies",9},
	{&KComparisonOps,u"ComparisonOps",13},
	{&KContainis,u"Containis",9},
	{&KCountries,u"Countries",9},
	{&KCountryOfOrigin,u"CountryOfOrigin",15},
	{&KCountry__ISO2,u"Country_ISO2",12},
	{&KCreateDate,u"CreateDate",10},
	{&KCreatedBy,u"CreatedBy",9},
	{&KCreatedBy_20_3D_20_3A1,u"CreatedBy = :1",14},
	{&KDBAliases,u"DBAliases",9},
	{&KDBQueries,u"DBQueries",9},
	{&KDONE,u"DONE",4},
	{&KDQFW__QueryTable,u"DQFW_QueryTable",15},
	{&KDataClass,u"DataClass",9},
	{&KDelete,u"Delete",6},
	{&KDiscard,u"Discard",7},
	{&KDisplayQryText,u"DisplayQryText",14},
	{&KDisplayRole,u"DisplayRole",11},
	{&KDone,u"Done",4},
	{&KEND,u"END",3},
	{&KERROR__Handler,u"ERROR_Handler",13},
	{&KEngName,u"EngName",7},
	{&KEngOverview,u"EngOverview",11},
	{&KGenres,u"Genres",6},
	{&KGroup,u"Group",5},
	{&KGroup_20_3D_20_3A1,u"Group = :1",10},
	{&KID,u"ID",2},
	{&KIsActive,u"IsActive",8},
	{&KIsIndexed,u"IsIndexed",9},
	{&KIs_20equal_20to,u"Is equal to",11},
	{&KIs_20greater_20than,u"Is greater than",15},
	{&KIs_20less_20than,u"Is less than",12},
	{&KIs_20not_20equal_20to,u"Is not equal to",15},
	{&KKey,u"Key",3},
	{&KLeave,u"Leave",5},
	{&KLogicOps,u"LogicOps",8},
	{&KMovieID,u"MovieID",7},
	{&KMovies,u"Movies",6},
	{&KNEW__QUERY__LINE,u"NEW_QUERY_LINE",14},
	{&KNONE,u"NONE",4},
	{&KName,u"Name",4},
	{&KNew_20Query_20Line,u"New Query Line",14},
	{&KOK,u"OK",2},
	{&KOR,u"OR",2},
	{&KOR_20_28,u"OR (",4},
	{&KObjectName,u"ObjectName",10},
	{&KObjectType,u"ObjectType",10},
	{&KObjectType_20_3D_20_3A1,u"ObjectType = :1",15},
	{&KOr,u"Or",2},
	{&KOr_20_28,u"Or (",4},
	{&KOriginalTitle,u"OriginalTitle",13},
	{&KParentDataClass,u"ParentDataClass",15},
	{&KProducers,u"Producers",9},
	{&KQryLines,u"QryLines",8},
	{&KQryParams,u"QryParams",9},
	{&KQryText,u"QryText",7},
	{&KQry__,u"Qry_",4},
	{&KQueryName,u"QueryName",9},
	{&KQueryName_20_3D_20_3A1,u"QueryName = :1",14},
	{&KRating,u"Rating",6},
	{&KReleaseDate,u"ReleaseDate",11},
	{&KRole_2CLines,u"Role,Lines",10},
	{&KRuntime,u"Runtime",7},
	{&KSBK__AddModify,u"SBK_AddModify",13},
	{&KSBK__Manager,u"SBK_Manager",11},
	{&KSBK__Search,u"SBK_Search",10},
	{&KSHORTCUTS,u"SHORTCUTS",9},
	{&KSTART,u"START",5},
	{&KSTART_2FEND,u"START/END",9},
	{&KSave,u"Save",4},
	{&KSearch_20,u"Search ",7},
	{&KSearch_20Database,u"Search Database",15},
	{&KSelect_20a_20Role,u"Select a Role",13},
	{&KSelect_20an_20Item,u"Select an Item",14},
	{&KSelection_20List,u"Selection List",14},
	{&KSingle,u"Single",6},
	{&KSortNo,u"SortNo",6},
	{&KSystem_20Name,u"System Name",11},
	{&KSystem_2CLines,u"System,Lines",12},
	{&KSystems_20Book,u"Systems Book",12},
	{&KTMDB__ID,u"TMDB_ID",7},
	{&KTMDB__ID_20_3D_20_3A1,u"TMDB_ID = :1",12},
	{&KTRUE,u"TRUE",4},
	{&KThis_2E,u"This.",5},
	{&KTitle,u"Title",5},
	{&KUI__SEARCH,u"UI_SEARCH",9},
	{&KUSER,u"USER",4},
	{&KUpdateDate,u"UpdateDate",10},
	{&KUpdatedBy,u"UpdatedBy",9},
	{&K_20,u" ",1},
	{&K_20AND_20Group_20_23_20_3A2,u" AND Group # :2",15},
	{&K_20AND_20Group_20_3D_20_3A2,u" AND Group = :2",15},
	{&K_20IN_20_3A1,u" IN :1",6},
	{&K_20_22_20,u"\x2022 ",2},
	{&K_20_3A,u" :",2},
	{&K_20_3A1,u" :1",3},
	{&K_20_3D_20_3A1,u" = :1",5},
	{&K_20system_2E_2E_3F,u" system..?",10},
	{&K_21_3D,u"!=",2},
	{&K_23,u"#",1},
	{&K_29_20AND,u") AND",5},
	{&K_29_20And,u") And",5},
	{&K_29_20OR,u") OR",4},
	{&K_29_20Or,u") Or",4},
	{&K_2ANEW__BASEENTITY,u"*NEW_BASEENTITY",15},
	{&K_2ANEW__CATEGORY,u"*NEW_CATEGORY",13},
	{&K_2ANEW__GROUP,u"*NEW_GROUP",10},
	{&K_2ANEW__QUERY,u"*NEW_QUERY",10},
	{&K_2C,u",",1},
	{&K_2C_20,u", ",2},
	{&K_2E,u".",1},
	{&K_2F,u"/",1},
	{&K_3A,u":",1},
	{&K_3B,u";",1},
	{&K_3C,u"<",1},
	{&K_3C_3D,u"<=",2},
	{&K_3D,u"=",1},
	{&K_3D_3D,u"==",2},
	{&K_3E,u">",1},
	{&K_3E_3D,u">=",2},
	{&K_40,u"@",1},
	{&K_40SHORTCUTS_40,u"@SHORTCUTS@",11},
	{&K_7B_7D,u"{}",2},
	{&K_7C,u"|",1},
	{&K_7C_40,u"|@",2},
	{&K__,u"_",1},
	{&Kattribute,u"attribute",9},
	{&Kattributes,u"attributes",10},
	{&KautoFilled,u"autoFilled",10},
	{&KbAutoComplete,u"bAutoComplete",13},
	{&KbEnableGrouping,u"bEnableGrouping",15},
	{&KbFullAccess,u"bFullAccess",11},
	{&KbHidden,u"bHidden",7},
	{&KbHidden_20_3D_20_3A1,u"bHidden = :1",12},
	{&KbIsAdminUser,u"bIsAdminUser",12},
	{&KbSaveRecord,u"bSaveRecord",11},
	{&KbSuccess,u"bSuccess",8},
	{&KbUpdateCache,u"bUpdateCache",12},
	{&KbUserSelected,u"bUserSelected",13},
	{&KbttnAllRecords,u"bttnAllRecords",14},
	{&KbttnCancel,u"bttnCancel",10},
	{&KbttnClose,u"bttnClose",9},
	{&KbttnCloseSystem,u"bttnCloseSystem",15},
	{&KbttnExport,u"bttnExport",10},
	{&KbttnHideAdv,u"bttnHideAdv",11},
	{&KbttnImport,u"bttnImport",10},
	{&KbttnLoadSystem_40,u"bttnLoadSystem@",15},
	{&KbttnRecent_40,u"bttnRecent@",11},
	{&KbttnRun_40,u"bttnRun@",8},
	{&KbttnSaveQueries,u"bttnSaveQueries",15},
	{&KbttnSelect,u"bttnSelect",10},
	{&KbttnShortcut_40,u"bttnShortcut@",13},
	{&KbttnShowAdv,u"bttnShowAdv",11},
	{&KcharSet,u"charSet",7},
	{&Kclear,u"clear",5},
	{&Kcode,u"code",4},
	{&Kcol,u"col",3},
	{&KcolCollection,u"colCollection",13},
	{&KcolLBSetup,u"colLBSetup",10},
	{&KcolListItems,u"colListItems",12},
	{&KcolOperators,u"colOperators",12},
	{&KcolOrigList,u"colOrigList",11},
	{&KcolQryLines,u"colQryLines",11},
	{&KcolRQ,u"colRQ",5},
	{&KcolsDelim,u"colsDelim",9},
	{&KcolumnsMap,u"columnsMap",10},
	{&Kcombine,u"combine",7},
	{&Kcopy,u"copy",4},
	{&Kdistinct,u"distinct",8},
	{&Kdrop,u"drop",4},
	{&KeDBQuery,u"eDBQuery",8},
	{&KesSystems,u"esSystems",9},
	{&Kextract,u"extract",7},
	{&KfieldType,u"fieldType",9},
	{&Kfile2Import,u"file2Import",11},
	{&KfilePath,u"filePath",8},
	{&Kfirst,u"first",5},
	{&KfullName,u"fullName",8},
	{&Kgenres,u"genres",6},
	{&Kget,u"get",3},
	{&KgetInfo,u"getInfo",7},
	{&KgetText,u"getText",7},
	{&KheaderRow,u"headerRow",9},
	{&KiAdd2Selection,u"iAdd2Selection",14},
	{&KiCreated,u"iCreated",8},
	{&KiHdrLineIndx,u"iHdrLineIndx",12},
	{&KiItemIndx,u"iItemIndx",9},
	{&KiPos,u"iPos",4},
	{&KiQryLineIndx,u"iQryLineIndx",12},
	{&KiQrySelection,u"iQrySelection",13},
	{&KiSkipped,u"iSkipped",8},
	{&KiUpdated,u"iUpdated",8},
	{&KiWidth,u"iWidth",6},
	{&KiWinRef,u"iWinRef",7},
	{&Kid,u"id",2},
	{&KindexOf,u"indexOf",7},
	{&Kindexed,u"indexed",7},
	{&Kindices,u"indices",7},
	{&Kindx,u"indx",4},
	{&Kinsert,u"insert",6},
	{&KisNew,u"isNew",5},
	{&Kiso__3166__1,u"iso_3166_1",10},
	{&Kjoin,u"join",4},
	{&Kjsn,u"jsn",3},
	{&Kkind,u"kind",4},
	{&KlbItemListMulti,u"lbItemListMulti",15},
	{&KlbItemList_40,u"lbItemList@",11},
	{&KlbQryLines,u"lbQryLines",10},
	{&KlbQryLines_40,u"lbQryLines@",11},
	{&KlbSystemLines,u"lbSystemLines",13},
	{&Klength,u"length",6},
	{&KlogicOP,u"logicOP",7},
	{&KlogicOPs,u"logicOPs",8},
	{&KlogicOp,u"logicOp",7},
	{&Kmax,u"max",3},
	{&Kname,u"name",4},
	{&Knew,u"new",3},
	{&KnewSelection,u"newSelection",12},
	{&KoHdrLine,u"oHdrLine",8},
	{&KoItem,u"oItem",5},
	{&KoLogicOperators,u"oLogicOperators",15},
	{&KoNewQryLine,u"oNewQryLine",11},
	{&KoObject,u"oObject",7},
	{&KoQryLine,u"oQryLine",8},
	{&KobjectName,u"objectName",10},
	{&Koperator,u"operator",8},
	{&Koperators,u"operators",9},
	{&Kor,u"or",2},
	{&Koriginal__title,u"original_title",14},
	{&Koverview,u"overview",8},
	{&Kparameters,u"parameters",10},
	{&KplatformPath,u"platformPath",12},
	{&KprimaryKey,u"primaryKey",10},
	{&Kpush,u"push",4},
	{&KqryLines,u"qryLines",8},
	{&KqryText,u"qryText",7},
	{&KqryValue,u"qryValue",8},
	{&KqryValue_20_3D_20_3A1,u"qryValue = :1",13},
	{&Kquery,u"query",5},
	{&KrbAdd2Selection,u"rbAdd2Selection",15},
	{&KrbQrySelection,u"rbQrySelection",14},
	{&KrelatedEntities,u"relatedEntities",15},
	{&KrelatedEntity,u"relatedEntity",13},
	{&Krelated_40,u"related@",8},
	{&Krelease__date,u"release_date",12},
	{&Kremove,u"remove",6},
	{&Kresult,u"result",6},
	{&KrowsDelim,u"rowsDelim",9},
	{&Kruntime,u"runtime",7},
	{&Ksave,u"save",4},
	{&KsetText,u"setText",7},
	{&Kstorage,u"storage",7},
	{&Ksuccess,u"success",7},
	{&Ksum,u"sum",3},
	{&KtAlias,u"tAlias",6},
	{&KtComparison,u"tComparison",11},
	{&KtCurPage,u"tCurPage",8},
	{&KtDBQueriesTitle,u"tDBQueriesTitle",15},
	{&KtDisplayName,u"tDisplayName",12},
	{&KtError,u"tError",6},
	{&KtFormHeader,u"tFormHeader",11},
	{&KtHeader,u"tHeader",7},
	{&KtLogic,u"tLogic",6},
	{&KtName,u"tName",5},
	{&KtOperator,u"tOperator",9},
	{&KtQueryName,u"tQueryName",10},
	{&KtQueryTable,u"tQueryTable",11},
	{&KtSelectionMode,u"tSelectionMode",14},
	{&KtShorcutsType,u"tShorcutsType",13},
	{&KtVariable,u"tVariable",9},
	{&KtWildCard,u"tWildCard",9},
	{&KtWildcard,u"tWildcard",9},
	{&Ktitle,u"title",5},
	{&KtoCollection,u"toCollection",12},
	{&KtoObject,u"toObject",8},
	{&KtotalRows,u"totalRows",9},
	{&Ktouched,u"touched",7},
	{&Ktype,u"type",4},
	{&Kundefined,u"undefined",9},
	{&KvValue,u"vValue",6},
	{&Kvalues,u"values",6},
	{&Kvote__average,u"vote_average",12},
	{&k0Y5ZI0AruYM,u"https://api.themoviedb.org/3/movie/",35},
	{&k0hyJBtb3YKs,u"colRecentQueries",16},
	{&k1$MufgeWnJs,u"Add/Modify System Book",22},
	{&k34HMjgGobfs,u"Please select an attribute first!",33},
	{&k37ob$gUXo40,u"UI_SEARCHSHORTCUTSNEW_QUERY_LINE",32},
	{&k4YwHrlt0lGo,u"INVALID PARAMETER: ",19},
	{&k5eF30BpGehY,u"ADVANCED_SHORTCUTS",18},
	{&k5hs0QWHiwao,u"DisplayRole,QryText,QryLines",28},
	{&k6eRd$w4LQWE,u"Key = :1 AND BaseEntity = :2",28},
	{&k7aUcEud5d8s,u",\x22logicOP\x22:\x22\x22,\x22operator\x22:\x22=\x22,\x22qryValue\x22:\x22\x22,\x22tAlias\x22:\x22\x22,\x22tComparison\x22:\x22\x22,\x22tLogic\x22:\x22\x22,\x22vValue\x22:\x22\x22}\xd]\xd}",100},
	{&k7nPzzMJ4l8k,u"esTableSelection",16},
	{&k8pbYXc0IDa4,u"BaseEntity = :1 AND Group != :2",31},
	{&k99ZvUtw5fTk,u"No data imported. file not found: ",34},
	{&k9HkhWTimNqc,u"Invalid Query!. Make sure you have selected attributes for all questions",72},
	{&k9IogFu290Rs,u"BttnSearchSystem",16},
	{&kA3$zPm7Wdtc,u"application/json",16},
	{&kBK2Q7apxEgw,u"Do you want to leave this form?",31},
	{&kBsHDkvsGrPw,u"Invalid dataclass: ",19},
	{&kBsrRGl7CXWk,u"BttnDeleteSystem",16},
	{&kCPE6gzua87w,u"Unable to display choice list. Contact your system administrator",64},
	{&kEm7af4vYXiQ,u"Unable to parse JSON File: ",27},
	{&kFC3mrBPpIRQ,u"SystemsQueryResults",19},
	{&kFEAgzPXQQ1U,u"Invalid system file. Import aborted",35},
	{&kF_fhco9Ukug,u"Unique key(s) do not exists in: ",32},
	{&kFft24fqABwU,u"Country_ISO2 = :1",17},
	{&kGk4SEXhP$g4,u"BaseEntity = :1 AND Group = :2",30},
	{&kGpkCbRdAut0,u"System saved successfully",25},
	{&kHWbpQfb3ej0,u"Invalid system file (Missing Collection of Query Lines). Import aborted",71},
	{&kHrlR6C2oH1s,u"Are you sure you want to delete the current record?",51},
	{&kI9o4oFrPi2g,u"colRecentQryList",16},
	{&kIbq0A3jgcHQ,u"BttnDelQuestion@",16},
	{&kIzdY4SXjrXA,u"Comparison,Operator",19},
	{&kJcmVSB$WMo0,u"DBQueriesTablePtr",17},
	{&kJpMovZgJmOE,u"BttnAllRecordsMain",18},
	{&kK0xZCxy7G4Y,u"oComparisonOperators",20},
	{&kKF5$aMVUyGE,u"System Book Add/Modify",22},
	{&kLFmVOfq3Rog,u"{\x22qryLines\x22:[{\x22\x61ttribute\x22:\x22\x22,\x22line\x22:1,\x22logicOP\x22:\x22\x22,\x22operator\x22:\x22=\x22,\x22qryValue\x22:\x22\x22,\x22tAlias\x22:\x22\x22,\x22tComparison\x22:\x22Is equal to\x22,\x22tLogic\x22:\x22\x22,\x22vValue\x22:\x22\x22}]}",146},
	{&kLGJAiSueMjo,u"BttnSelectCategory",18},
	{&kLceznZrfsTE,u"BaseEntity = :1 AND ID = :2",27},
	{&kM44XBFxGaXg,u"bttnSaveShortcut@",17},
	{&kM7ZrSE1z4ns,u"System Book Entry",17},
	{&kME8WkbwCo5U,u"Comparison,Operator,Wildcard",28},
	{&kMzsyXlqrMYY,u"WDGT_SelectionList",18},
	{&kOJqFOvTiTzk,u"Error reading file. No rows detected",36},
	{&kRxZpk1vyTOQ,u"Please select a System first.",29},
	{&kSQrkHbQsyew,u"Is greater than or equal to",27},
	{&kSw3pZ8WhbHE,u"Invalid system file (Collection in wrong format). Import aborted",64},
	{&kTPKCwQqjmqo,u"https://api.themoviedb.org/3/authentication?api_key=180c9b29d15c2a6d6aace6a7282c9431",84},
	{&kUUFh9UQqW4I,u"lbItemListSingle",16},
	{&kUYzHRa1RkIw,u"Does not contain",16},
	{&kUjF5du1y_4w,u"No recent queries available",27},
	{&kV4hd9u0tSd4,u"Do you want to discard your changes?",36},
	{&kVMWRzE2WNPY,u"BaseEntity = :1 AND Group # :2 ",31},
	{&kVfh0oqO1WwE,u"tQueryScreenType",16},
	{&kVn4UTeilKOI,u"BttnAddQuestion@",16},
	{&kW4zrIKzg05Q,u"DisplayRole,QryLines",20},
	{&kWs_Sv0eaXFo,u"Alias,ObjectName",16},
	{&kXe$hkKzzxyk,u"Do you want to save the current system before creating a new one?",65},
	{&kY$vPzVyalUU,u"Search System Book",18},
	{&kY6jJBKNw4xE,u"No data imported. Missing column map",36},
	{&kYK1g15csO4w,u"System was deleted succesfuly...!",33},
	{&kYhLxOkZaZqg,u"Unable to parse query line. Contact your system administrator",61},
	{&kbOrzFr4P_io,u" AND QueryName = :4",19},
	{&kcshqzox9NQc,u"tDisplayName,tOperator",22},
	{&kdWqu0dBKCLQ,u"tDisplayName,tOperator,tWildcard",32},
	{&kdfhMtAt0bDs,u"Movies;Companies;Countries;Producers;CountryOfOrigin",52},
	{&kdhneN13oy0I,u"Export successful. File located at: ",36},
	{&keDIZs3EOHqQ,u"DisplayRole = :1",16},
	{&keYpYHsodZMQ,u" -  Invalid Object: ",20},
	{&kg9WZ56E4v0o,u"Error saving system...!",23},
	{&kguJir0$ZYI8,u"System was updated succesfuly...!",33},
	{&kh2tK_oDa4Jc,u"tQueryName,colQryLines",22},
	{&kiHFsVAYKZIQ,u" List is not available. Contact your system administrator",57},
	{&kifRyNcfJ4tA,u"Group list is empty",19},
	{&kiin4rCiGwQ8,u"Do you want to save the discard your changes?",45},
	{&kjUh3rfCnjoI,u"Are you sure you want to delete ",32},
	{&kkFRmeFTH3a4,u"{\x22qryLines\x22:[\xd    {\x22\x61ttribute\x22:\x22\x22,\x22line\x22:",41},
	{&kkFuTiDDdsWI,u"No records found!",17},
	{&kkhHWtXAdhMw,u"tDBQueriesTableName",19},
	{&klQSV4ZoYWzw,u"colSelectedItems",16},
	{&klQq_$TIrnvA,u"tOperator,tWildcard",19},
	{&kmLbBRNjeatk,u" AND Category = :3",18},
	{&knB7uuVmo8Xo,u"BttnModifySystem",16},
	{&knBbNEZaGk_I,u"Please select a query item..!",29},
	{&knT_OmB8KgS4,u"production_companies",20},
	{&knVPnk6aYtd4,u"relatedDataClass",16},
	{&ko166k_hFrHs,u"Category list is empty",22},
	{&kohe2eiRGiCQ,u"ObjectType = :1 AND AvailInDBQueries = :2",41},
	{&kpBUF4YZPrek,u"bIsExistingSelectionAvail",25},
	{&kqDYe8_Lb36A,u"?api_key=180c9b29d15c2a6d6aace6a7282c9431",41},
	{&krAvNTkjyYAg,u" AND ParentDataClass = :2",25},
	{&ksjVmVct_m1g,u"Error deleting system...!",25},
	{&ksqpcsLWR6go,u"Role,Query,Lines",16},
	{&ksv03rMKIa68,u"tRecentQryCacheName",19},
	{&kt24wFY1HOc8,u"Is less than or equal to",24},
	{&ku2OcsofPKtU,u"{\x22qryLines\x22:[\xd    {\x22\x61ttribute\x22:\x22\x22,\x22line\x22:1,\x22logicOP\x22:\x22\x22,\x22operator\x22:\x22=\x22,\x22qryValue\x22:\x22\x22,\x22tAlias\x22:\x22\x22,\x22tComparison\x22:\x22\x22,\x22tLogic\x22:\x22\x22,\x22vValue\x22:\x22\x22}\xd]\xd}",142},
	{&kumdMK_s5sbI,u"System Book Search",18},
	{&kvMa7T0CfUPc,u"ObjectType = :1 AND ParentDataClass = :2 AND ObjectName = :3",60},
	{&kx70Q3Jyepmo,u"Edit System Book",16},
	{&kxBemVzOKO4U,u"The following fields cannot be blank:",37},
	{&kyB6TMG4mH1Q,u"production_countries",20},
	{&kyESkQ4NjOg0,u"SBK_Administration",18},
	{&kzcH0gI8C0HI,u"AvailInDBQueries",16},
	{nullptr,nullptr,0}
};

void InitConstants()
{
	for( const Txt_info *i = constants ; i->t != nullptr; ++i)
		g->AssignUniChars(i->t->cv(),i->s,i->n);
}

void DeInitConstants()
{
	for( const Txt_info *i = constants ; i->t != nullptr; ++i)
		i->t->setNull();
}
