extern Txt K;
extern Txt KAlias;
extern Txt KComparisonOps;
extern Txt KEND;
extern Txt KLogicOps;
extern Txt KNONE;
extern Txt KObjectName;
extern Txt KSTART;
extern Txt KSTART_2FEND;
extern Txt K_40;
extern Txt Kattribute;
extern Txt Kcode;
extern Txt KcolQryLines;
extern Txt KfieldType;
extern Txt KlbQryLines_40;
extern Txt KlogicOp;
extern Txt KobjectName;
extern Txt Koperator;
extern Txt KqryValue;
extern Txt KtAlias;
extern Txt KtComparison;
extern Txt KtCurPage;
extern Txt KtDisplayName;
extern Txt KtLogic;
extern Txt KtOperator;
extern Txt KtQueryTable;
extern Txt KtWildCard;
extern Txt KtWildcard;
extern Txt KvValue;
extern Txt k34HMjgGobfs;
Asm4d_Proc proc_DQFW__QUERYFORMLBXSELECT;
Asm4d_Proc proc_UTIL__CHANGETYPE;
extern unsigned char D_proc_DQFW__QUERYFORMLBXHNDL[];
void proc_DQFW__QUERYFORMLBXHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__QUERYFORMLBXHNDL);
	if (!ctx->doingAbort) {
		Long liValueType;
		Long liRow;
		Obj ltoFormEvent;
		Obj loFormEvent;
		Obj loSelectedItem;
		Long liCol;
		Long liType;
		Bool lJCPEREZ__20241102;
		Txt ltValue;
		Variant lvDlft;
		c.f.fLine=13;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=15;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t0.cv())) goto _0;
			Bool t1;
			if (g->OperationOnAny(ctx,7,t0.cv(),Value_null().cv(),t1.cv())) goto _0;
			if (!(t1.get())) goto _2;
		}
		{
			Variant t2;
			c.f.fLine=17;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t2.cv())) goto _0;
			Bool t3;
			if (g->OperationOnAny(ctx,6,t2.cv(),KlbQryLines_40.cv(),t3.cv())) goto _0;
			if (!(t3.get())) goto _4;
		}
		{
			Variant t4;
			c.f.fLine=19;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t4.cv())) goto _0;
			Ref t5;
			t5.setLocalRef(ctx,liRow.cv());
			Ref t6;
			t6.setLocalRef(ctx,liCol.cv());
			Txt t7;
			if (!g->GetValue(ctx,(PCV[]){t7.cv(),t4.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t7.cv(),t6.cv(),t5.cv()},4,971)) goto _0;
			g->Check(ctx);
		}
		if (0>=liRow.get()) goto _5;
		{
			Variant t9;
			c.f.fLine=23;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t9.cv())) goto _0;
			Bool t10;
			if (g->OperationOnAny(ctx,6,t9.cv(),Long(28).cv(),t10.cv())) goto _0;
			Variant t11;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t11.cv())) goto _0;
			Bool t12;
			if (g->OperationOnAny(ctx,6,t11.cv(),Long(13).cv(),t12.cv())) goto _0;
			Bool t13;
			t13=t10.get()||t12.get();
			if (!(t13.get())) goto _7;
		}
		if (1!=liCol.get()) goto _9;
		if (1>=liRow.get()) goto _10;
		{
			Txt t16;
			c.f.fLine=28;
			if (g->Call(ctx,(PCV[]){t16.cv()},0,655)) goto _0;
			g->Check(ctx);
			Bool t18;
			t18=Bool(0).get();
			Txt t19;
			t19=KLogicOps.get();
			Obj t20;
			proc_DQFW__QUERYFORMLBXSELECT(glob,ctx,2,3,(PCV[]){t19.cv(),t16.cv(),t18.cv()},t20.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loSelectedItem=t20.get();
		}
		{
			Bool t21;
			c.f.fLine=29;
			if (g->Call(ctx,(PCV[]){t21.cv(),loSelectedItem.cv()},1,1297)) goto _0;
			g->Check(ctx);
			Bool t22;
			t22=t21.get();
			Bool t23;
			t23=!(t22.get());
			if (!(t23.get())) goto _11;
		}
		{
			Obj t24;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1466)) goto _0;
			Variant t25;
			if (g->GetMember(ctx,t24.cv(),KcolQryLines.cv(),t25.cv())) goto _0;
			Long t26;
			t26=liRow.get()-1;
			Variant t27;
			if (g->GetMember(ctx,t25.cv(),t26.cv(),t27.cv())) goto _0;
			Variant t28;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtDisplayName.cv(),t28.cv())) goto _0;
			if (g->SetMember(ctx,t27.cv(),KtLogic.cv(),t28.cv())) goto _0;
		}
		{
			Obj t29;
			c.f.fLine=31;
			if (g->Call(ctx,(PCV[]){t29.cv()},0,1466)) goto _0;
			Variant t30;
			if (g->GetMember(ctx,t29.cv(),KcolQryLines.cv(),t30.cv())) goto _0;
			Long t31;
			t31=liRow.get()-1;
			Variant t32;
			if (g->GetMember(ctx,t30.cv(),t31.cv(),t32.cv())) goto _0;
			Variant t33;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtOperator.cv(),t33.cv())) goto _0;
			if (g->SetMember(ctx,t32.cv(),KlogicOp.cv(),t33.cv())) goto _0;
		}
		{
			Obj t34;
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){t34.cv()},0,1466)) goto _0;
			Obj t35;
			if (g->Call(ctx,(PCV[]){t35.cv()},0,1466)) goto _0;
			Variant t36;
			if (g->GetMember(ctx,t35.cv(),KcolQryLines.cv(),t36.cv())) goto _0;
			if (g->SetMember(ctx,t34.cv(),KcolQryLines.cv(),t36.cv())) goto _0;
		}
_11:
_10:
		goto _8;
_9:
		if (2!=liCol.get()) goto _12;
		{
			Obj t38;
			c.f.fLine=41;
			if (g->Call(ctx,(PCV[]){t38.cv()},0,1466)) goto _0;
			Variant t39;
			if (g->GetMember(ctx,t38.cv(),KtQueryTable.cv(),t39.cv())) goto _0;
			Txt t40;
			if (g->Call(ctx,(PCV[]){t40.cv()},0,655)) goto _0;
			g->Check(ctx);
			Bool t42;
			t42=Bool(0).get();
			Txt t43;
			if (!g->GetValue(ctx,(PCV[]){t43.cv(),t39.cv(),nullptr})) goto _0;
			Obj t44;
			proc_DQFW__QUERYFORMLBXSELECT(glob,ctx,2,3,(PCV[]){t43.cv(),t40.cv(),t42.cv()},t44.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loSelectedItem=t44.get();
		}
		{
			Bool t45;
			c.f.fLine=43;
			if (g->Call(ctx,(PCV[]){t45.cv(),loSelectedItem.cv()},1,1297)) goto _0;
			g->Check(ctx);
			Bool t46;
			t46=t45.get();
			Bool t47;
			t47=!(t46.get());
			if (!(t47.get())) goto _13;
		}
		{
			Obj t48;
			c.f.fLine=44;
			if (g->Call(ctx,(PCV[]){t48.cv()},0,1466)) goto _0;
			Variant t49;
			if (g->GetMember(ctx,t48.cv(),KcolQryLines.cv(),t49.cv())) goto _0;
			Long t50;
			t50=liRow.get()-1;
			Variant t51;
			if (g->GetMember(ctx,t49.cv(),t50.cv(),t51.cv())) goto _0;
			Variant t52;
			if (g->GetMember(ctx,loSelectedItem.cv(),KAlias.cv(),t52.cv())) goto _0;
			if (g->SetMember(ctx,t51.cv(),KtAlias.cv(),t52.cv())) goto _0;
		}
		{
			Obj t53;
			c.f.fLine=45;
			if (g->Call(ctx,(PCV[]){t53.cv()},0,1466)) goto _0;
			Variant t54;
			if (g->GetMember(ctx,t53.cv(),KcolQryLines.cv(),t54.cv())) goto _0;
			Long t55;
			t55=liRow.get()-1;
			Variant t56;
			if (g->GetMember(ctx,t54.cv(),t55.cv(),t56.cv())) goto _0;
			Variant t57;
			if (g->GetMember(ctx,loSelectedItem.cv(),KObjectName.cv(),t57.cv())) goto _0;
			if (g->SetMember(ctx,t56.cv(),Kattribute.cv(),t57.cv())) goto _0;
		}
		{
			Obj t58;
			c.f.fLine=46;
			if (g->Call(ctx,(PCV[]){t58.cv()},0,1466)) goto _0;
			Obj t59;
			if (g->Call(ctx,(PCV[]){t59.cv()},0,1466)) goto _0;
			Variant t60;
			if (g->GetMember(ctx,t59.cv(),KcolQryLines.cv(),t60.cv())) goto _0;
			if (g->SetMember(ctx,t58.cv(),KcolQryLines.cv(),t60.cv())) goto _0;
		}
		{
			Obj t61;
			c.f.fLine=49;
			if (g->Call(ctx,(PCV[]){t61.cv()},0,1466)) goto _0;
			Variant t62;
			if (g->GetMember(ctx,t61.cv(),KcolQryLines.cv(),t62.cv())) goto _0;
			Long t63;
			t63=liRow.get()-1;
			Variant t64;
			if (g->GetMember(ctx,t62.cv(),t63.cv(),t64.cv())) goto _0;
			Obj t65;
			if (g->Call(ctx,(PCV[]){t65.cv()},0,1466)) goto _0;
			Variant t66;
			if (g->GetMember(ctx,t65.cv(),KcolQryLines.cv(),t66.cv())) goto _0;
			Long t67;
			t67=liRow.get()-1;
			Variant t68;
			if (g->GetMember(ctx,t66.cv(),t67.cv(),t68.cv())) goto _0;
			Variant t69;
			if (g->GetMember(ctx,t68.cv(),KvValue.cv(),t69.cv())) goto _0;
			Variant t70;
			Long t71;
			t71=2;
			Variant t72;
			proc_UTIL__CHANGETYPE(glob,ctx,2,3,(PCV[]){t69.cv(),t71.cv(),t70.cv()},t72.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,t64.cv(),KvValue.cv(),t72.cv())) goto _0;
		}
		{
			Obj t73;
			c.f.fLine=51;
			if (g->Call(ctx,(PCV[]){t73.cv()},0,1482)) goto _0;
			Obj t74;
			if (g->Call(ctx,(PCV[]){t74.cv()},0,1466)) goto _0;
			Variant t75;
			if (g->GetMember(ctx,t74.cv(),KtQueryTable.cv(),t75.cv())) goto _0;
			Variant t76;
			if (g->GetMember(ctx,t73.cv(),t75.cv(),t76.cv())) goto _0;
			Variant t77;
			if (g->GetMember(ctx,loSelectedItem.cv(),KObjectName.cv(),t77.cv())) goto _0;
			Variant t78;
			if (g->GetMember(ctx,t76.cv(),t77.cv(),t78.cv())) goto _0;
			Variant t79;
			if (g->GetMember(ctx,t78.cv(),KfieldType.cv(),t79.cv())) goto _0;
			Long t80;
			if (!g->GetValue(ctx,(PCV[]){t80.cv(),t79.cv(),nullptr})) goto _0;
			liType=t80.get();
		}
		if (4!=liType.get()) goto _15;
		{
			Date t82;
			c.f.fLine=55;
			if (g->Call(ctx,(PCV[]){t82.cv()},0,33)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t82.cv(),lvDlft.cv(),nullptr})) goto _0;
		}
		goto _14;
_15:
		{
			Bool t83;
			t83=9==liType.get();
			Bool t84;
			t84=1==liType.get();
			if (!( t83.get()||t84.get())) goto _16;
		}
		c.f.fLine=58;
		if (!g->SetValue(ctx,(PCV[]){Num(0).cv(),lvDlft.cv(),nullptr})) goto _0;
		goto _14;
_16:
		if (6!=liType.get()) goto _17;
		c.f.fLine=61;
		if (!g->SetValue(ctx,(PCV[]){Bool(1).cv(),lvDlft.cv(),nullptr})) goto _0;
		goto _14;
_17:
		{
			Txt t87;
			t87=K.get();
			c.f.fLine=65;
			if (!g->SetValue(ctx,(PCV[]){t87.cv(),lvDlft.cv(),nullptr})) goto _0;
		}
_14:
		{
			Obj t88;
			c.f.fLine=69;
			if (g->Call(ctx,(PCV[]){t88.cv()},0,1466)) goto _0;
			Variant t89;
			if (g->GetMember(ctx,t88.cv(),KcolQryLines.cv(),t89.cv())) goto _0;
			Long t90;
			t90=liRow.get()-1;
			Variant t91;
			if (g->GetMember(ctx,t89.cv(),t90.cv(),t91.cv())) goto _0;
			Variant t92;
			if (g->GetMember(ctx,t91.cv(),KvValue.cv(),t92.cv())) goto _0;
			Bool t93;
			if (g->OperationOnAny(ctx,6,t92.cv(),K.cv(),t93.cv())) goto _0;
			if (!(t93.get())) goto _18;
		}
		{
			Obj t94;
			c.f.fLine=70;
			if (g->Call(ctx,(PCV[]){t94.cv()},0,1466)) goto _0;
			Variant t95;
			if (g->GetMember(ctx,t94.cv(),KcolQryLines.cv(),t95.cv())) goto _0;
			Long t96;
			t96=liRow.get()-1;
			Variant t97;
			if (g->GetMember(ctx,t95.cv(),t96.cv(),t97.cv())) goto _0;
			Variant t98;
			if (!g->GetValue(ctx,(PCV[]){t98.cv(),lvDlft.cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,t97.cv(),KvValue.cv(),t98.cv())) goto _0;
		}
		goto _19;
_18:
		{
			Obj t99;
			c.f.fLine=72;
			if (g->Call(ctx,(PCV[]){t99.cv()},0,1466)) goto _0;
			Variant t100;
			if (g->GetMember(ctx,t99.cv(),KcolQryLines.cv(),t100.cv())) goto _0;
			Long t101;
			t101=liRow.get()-1;
			Variant t102;
			if (g->GetMember(ctx,t100.cv(),t101.cv(),t102.cv())) goto _0;
			Obj t103;
			if (g->Call(ctx,(PCV[]){t103.cv()},0,1466)) goto _0;
			Variant t104;
			if (g->GetMember(ctx,t103.cv(),KcolQryLines.cv(),t104.cv())) goto _0;
			Long t105;
			t105=liRow.get()-1;
			Variant t106;
			if (g->GetMember(ctx,t104.cv(),t105.cv(),t106.cv())) goto _0;
			Variant t107;
			if (g->GetMember(ctx,t106.cv(),KvValue.cv(),t107.cv())) goto _0;
			Variant t108;
			Long t109;
			t109=liType.get();
			Variant t110;
			proc_UTIL__CHANGETYPE(glob,ctx,2,3,(PCV[]){t107.cv(),t109.cv(),t108.cv()},t110.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,t102.cv(),KvValue.cv(),t110.cv())) goto _0;
		}
_19:
		{
			Obj t111;
			c.f.fLine=75;
			if (g->Call(ctx,(PCV[]){t111.cv()},0,1466)) goto _0;
			Variant t112;
			if (g->GetMember(ctx,t111.cv(),KcolQryLines.cv(),t112.cv())) goto _0;
			Long t113;
			t113=liRow.get()-1;
			Variant t114;
			if (g->GetMember(ctx,t112.cv(),t113.cv(),t114.cv())) goto _0;
			Obj t115;
			if (g->Call(ctx,(PCV[]){t115.cv()},0,1466)) goto _0;
			Variant t116;
			if (g->GetMember(ctx,t115.cv(),KcolQryLines.cv(),t116.cv())) goto _0;
			Long t117;
			t117=liRow.get()-1;
			Variant t118;
			if (g->GetMember(ctx,t116.cv(),t117.cv(),t118.cv())) goto _0;
			Variant t119;
			if (g->GetMember(ctx,t118.cv(),KvValue.cv(),t119.cv())) goto _0;
			if (g->SetMember(ctx,t114.cv(),KqryValue.cv(),t119.cv())) goto _0;
		}
_13:
		goto _8;
_12:
		if (3!=liCol.get()) goto _20;
		{
			Obj t121;
			c.f.fLine=80;
			if (g->Call(ctx,(PCV[]){t121.cv()},0,1466)) goto _0;
			Variant t122;
			if (g->GetMember(ctx,t121.cv(),KcolQryLines.cv(),t122.cv())) goto _0;
			Long t123;
			t123=liRow.get()-1;
			Variant t124;
			if (g->GetMember(ctx,t122.cv(),t123.cv(),t124.cv())) goto _0;
			Variant t125;
			if (g->GetMember(ctx,t124.cv(),KvValue.cv(),t125.cv())) goto _0;
			Long t126;
			if (g->Call(ctx,(PCV[]){t126.cv(),t125.cv()},1,1509)) goto _0;
			liValueType=t126.get();
		}
		{
			Txt t127;
			c.f.fLine=81;
			if (g->Call(ctx,(PCV[]){t127.cv()},0,655)) goto _0;
			g->Check(ctx);
			Bool t129;
			t129=2==liValueType.get();
			Txt t130;
			t130=KComparisonOps.get();
			Obj t131;
			proc_DQFW__QUERYFORMLBXSELECT(glob,ctx,3,3,(PCV[]){t130.cv(),t127.cv(),t129.cv()},t131.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loSelectedItem=t131.get();
		}
		{
			Bool t132;
			c.f.fLine=82;
			if (g->Call(ctx,(PCV[]){t132.cv(),loSelectedItem.cv()},1,1297)) goto _0;
			g->Check(ctx);
			Bool t133;
			t133=t132.get();
			Bool t134;
			t134=!(t133.get());
			if (!(t134.get())) goto _21;
		}
		{
			Obj t135;
			c.f.fLine=83;
			if (g->Call(ctx,(PCV[]){t135.cv()},0,1466)) goto _0;
			Variant t136;
			if (g->GetMember(ctx,t135.cv(),KcolQryLines.cv(),t136.cv())) goto _0;
			Long t137;
			t137=liRow.get()-1;
			Variant t138;
			if (g->GetMember(ctx,t136.cv(),t137.cv(),t138.cv())) goto _0;
			Variant t139;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtDisplayName.cv(),t139.cv())) goto _0;
			if (g->SetMember(ctx,t138.cv(),KtComparison.cv(),t139.cv())) goto _0;
		}
		{
			Obj t140;
			c.f.fLine=84;
			if (g->Call(ctx,(PCV[]){t140.cv()},0,1466)) goto _0;
			Variant t141;
			if (g->GetMember(ctx,t140.cv(),KcolQryLines.cv(),t141.cv())) goto _0;
			Long t142;
			t142=liRow.get()-1;
			Variant t143;
			if (g->GetMember(ctx,t141.cv(),t142.cv(),t143.cv())) goto _0;
			Variant t144;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtOperator.cv(),t144.cv())) goto _0;
			if (g->SetMember(ctx,t143.cv(),Koperator.cv(),t144.cv())) goto _0;
		}
		{
			Obj t145;
			c.f.fLine=86;
			if (g->Call(ctx,(PCV[]){t145.cv()},0,1466)) goto _0;
			Variant t146;
			if (g->GetMember(ctx,t145.cv(),KcolQryLines.cv(),t146.cv())) goto _0;
			Long t147;
			t147=liRow.get()-1;
			Variant t148;
			if (g->GetMember(ctx,t146.cv(),t147.cv(),t148.cv())) goto _0;
			Variant t149;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtWildcard.cv(),t149.cv())) goto _0;
			if (g->SetMember(ctx,t148.cv(),KtWildCard.cv(),t149.cv())) goto _0;
		}
		if (2!=liValueType.get()) goto _22;
		{
			Variant t151;
			c.f.fLine=88;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtWildcard.cv(),t151.cv())) goto _0;
			Bool t152;
			if (g->OperationOnAny(ctx,7,t151.cv(),KNONE.cv(),t152.cv())) goto _0;
			if (!(t152.get())) goto _23;
		}
		{
			Obj t153;
			c.f.fLine=89;
			if (g->Call(ctx,(PCV[]){t153.cv()},0,1466)) goto _0;
			Variant t154;
			if (g->GetMember(ctx,t153.cv(),KcolQryLines.cv(),t154.cv())) goto _0;
			Long t155;
			t155=liRow.get()-1;
			Variant t156;
			if (g->GetMember(ctx,t154.cv(),t155.cv(),t156.cv())) goto _0;
			Obj t157;
			if (g->Call(ctx,(PCV[]){t157.cv()},0,1466)) goto _0;
			Variant t158;
			if (g->GetMember(ctx,t157.cv(),KcolQryLines.cv(),t158.cv())) goto _0;
			Long t159;
			t159=liRow.get()-1;
			Variant t160;
			if (g->GetMember(ctx,t158.cv(),t159.cv(),t160.cv())) goto _0;
			Variant t161;
			if (g->GetMember(ctx,t160.cv(),KvValue.cv(),t161.cv())) goto _0;
			Txt t162;
			if (!g->GetValue(ctx,(PCV[]){t162.cv(),t161.cv(),nullptr})) goto _0;
			Txt t163;
			if (g->Call(ctx,(PCV[]){t163.cv(),t162.cv(),K_40.cv(),K.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,t156.cv(),KqryValue.cv(),t163.cv())) goto _0;
		}
		{
			Variant t164;
			c.f.fLine=91;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtWildcard.cv(),t164.cv())) goto _0;
			Bool t165;
			if (g->OperationOnAny(ctx,6,t164.cv(),KSTART_2FEND.cv(),t165.cv())) goto _0;
			if (!(t165.get())) goto _25;
		}
		{
			Obj t166;
			c.f.fLine=92;
			if (g->Call(ctx,(PCV[]){t166.cv()},0,1466)) goto _0;
			Variant t167;
			if (g->GetMember(ctx,t166.cv(),KcolQryLines.cv(),t167.cv())) goto _0;
			Long t168;
			t168=liRow.get()-1;
			Variant t169;
			if (g->GetMember(ctx,t167.cv(),t168.cv(),t169.cv())) goto _0;
			Obj t170;
			if (g->Call(ctx,(PCV[]){t170.cv()},0,1466)) goto _0;
			Variant t171;
			if (g->GetMember(ctx,t170.cv(),KcolQryLines.cv(),t171.cv())) goto _0;
			Long t172;
			t172=liRow.get()-1;
			Variant t173;
			if (g->GetMember(ctx,t171.cv(),t172.cv(),t173.cv())) goto _0;
			Variant t174;
			if (g->GetMember(ctx,t173.cv(),KqryValue.cv(),t174.cv())) goto _0;
			Variant t175;
			if (g->OperationOnAny(ctx,0,K_40.cv(),t174.cv(),t175.cv())) goto _0;
			Variant t176;
			if (g->OperationOnAny(ctx,0,t175.cv(),K_40.cv(),t176.cv())) goto _0;
			if (g->SetMember(ctx,t169.cv(),KqryValue.cv(),t176.cv())) goto _0;
		}
		goto _24;
_25:
		{
			Variant t177;
			c.f.fLine=94;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtWildcard.cv(),t177.cv())) goto _0;
			Bool t178;
			if (g->OperationOnAny(ctx,6,t177.cv(),KSTART.cv(),t178.cv())) goto _0;
			if (!(t178.get())) goto _26;
		}
		{
			Obj t179;
			c.f.fLine=95;
			if (g->Call(ctx,(PCV[]){t179.cv()},0,1466)) goto _0;
			Variant t180;
			if (g->GetMember(ctx,t179.cv(),KcolQryLines.cv(),t180.cv())) goto _0;
			Long t181;
			t181=liRow.get()-1;
			Variant t182;
			if (g->GetMember(ctx,t180.cv(),t181.cv(),t182.cv())) goto _0;
			Obj t183;
			if (g->Call(ctx,(PCV[]){t183.cv()},0,1466)) goto _0;
			Variant t184;
			if (g->GetMember(ctx,t183.cv(),KcolQryLines.cv(),t184.cv())) goto _0;
			Long t185;
			t185=liRow.get()-1;
			Variant t186;
			if (g->GetMember(ctx,t184.cv(),t185.cv(),t186.cv())) goto _0;
			Variant t187;
			if (g->GetMember(ctx,t186.cv(),KqryValue.cv(),t187.cv())) goto _0;
			Variant t188;
			if (g->OperationOnAny(ctx,0,K_40.cv(),t187.cv(),t188.cv())) goto _0;
			if (g->SetMember(ctx,t182.cv(),KqryValue.cv(),t188.cv())) goto _0;
		}
		goto _24;
_26:
		{
			Variant t189;
			c.f.fLine=97;
			if (g->GetMember(ctx,loSelectedItem.cv(),KtWildcard.cv(),t189.cv())) goto _0;
			Bool t190;
			if (g->OperationOnAny(ctx,6,t189.cv(),KEND.cv(),t190.cv())) goto _0;
			if (!(t190.get())) goto _27;
		}
		{
			Obj t191;
			c.f.fLine=98;
			if (g->Call(ctx,(PCV[]){t191.cv()},0,1466)) goto _0;
			Variant t192;
			if (g->GetMember(ctx,t191.cv(),KcolQryLines.cv(),t192.cv())) goto _0;
			Long t193;
			t193=liRow.get()-1;
			Variant t194;
			if (g->GetMember(ctx,t192.cv(),t193.cv(),t194.cv())) goto _0;
			Obj t195;
			if (g->Call(ctx,(PCV[]){t195.cv()},0,1466)) goto _0;
			Variant t196;
			if (g->GetMember(ctx,t195.cv(),KcolQryLines.cv(),t196.cv())) goto _0;
			Long t197;
			t197=liRow.get()-1;
			Variant t198;
			if (g->GetMember(ctx,t196.cv(),t197.cv(),t198.cv())) goto _0;
			Variant t199;
			if (g->GetMember(ctx,t198.cv(),KqryValue.cv(),t199.cv())) goto _0;
			Variant t200;
			if (g->OperationOnAny(ctx,0,t199.cv(),K_40.cv(),t200.cv())) goto _0;
			if (g->SetMember(ctx,t194.cv(),KqryValue.cv(),t200.cv())) goto _0;
		}
		goto _24;
_27:
_24:
		goto _28;
_23:
		{
			Obj t201;
			c.f.fLine=105;
			if (g->Call(ctx,(PCV[]){t201.cv()},0,1466)) goto _0;
			Variant t202;
			if (g->GetMember(ctx,t201.cv(),KcolQryLines.cv(),t202.cv())) goto _0;
			Long t203;
			t203=liRow.get()-1;
			Variant t204;
			if (g->GetMember(ctx,t202.cv(),t203.cv(),t204.cv())) goto _0;
			Variant t205;
			if (g->GetMember(ctx,t204.cv(),KvValue.cv(),t205.cv())) goto _0;
			Txt t206;
			if (!g->GetValue(ctx,(PCV[]){t206.cv(),t205.cv(),nullptr})) goto _0;
			Long t207;
			if (g->Call(ctx,(PCV[]){t207.cv(),K_40.cv(),t206.cv()},2,15)) goto _0;
			Bool t208;
			t208=0>=t207.get();
			if (!(t208.get())) goto _29;
		}
		{
			Obj t209;
			c.f.fLine=106;
			if (g->Call(ctx,(PCV[]){t209.cv()},0,1466)) goto _0;
			Variant t210;
			if (g->GetMember(ctx,t209.cv(),KcolQryLines.cv(),t210.cv())) goto _0;
			Long t211;
			t211=liRow.get()-1;
			Variant t212;
			if (g->GetMember(ctx,t210.cv(),t211.cv(),t212.cv())) goto _0;
			Obj t213;
			if (g->Call(ctx,(PCV[]){t213.cv()},0,1466)) goto _0;
			Variant t214;
			if (g->GetMember(ctx,t213.cv(),KcolQryLines.cv(),t214.cv())) goto _0;
			Long t215;
			t215=liRow.get()-1;
			Variant t216;
			if (g->GetMember(ctx,t214.cv(),t215.cv(),t216.cv())) goto _0;
			Variant t217;
			if (g->GetMember(ctx,t216.cv(),KqryValue.cv(),t217.cv())) goto _0;
			Txt t218;
			if (!g->GetValue(ctx,(PCV[]){t218.cv(),t217.cv(),nullptr})) goto _0;
			Txt t219;
			if (g->Call(ctx,(PCV[]){t219.cv(),t218.cv(),K_40.cv(),K.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,t212.cv(),KqryValue.cv(),t219.cv())) goto _0;
		}
_29:
_28:
_22:
		{
			Obj t220;
			c.f.fLine=114;
			if (g->Call(ctx,(PCV[]){t220.cv()},0,1466)) goto _0;
			Obj t221;
			if (g->Call(ctx,(PCV[]){t221.cv()},0,1466)) goto _0;
			Variant t222;
			if (g->GetMember(ctx,t221.cv(),KcolQryLines.cv(),t222.cv())) goto _0;
			if (g->SetMember(ctx,t220.cv(),KcolQryLines.cv(),t222.cv())) goto _0;
		}
_21:
		goto _8;
_20:
_8:
		goto _6;
_7:
		{
			Variant t223;
			c.f.fLine=123;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t223.cv())) goto _0;
			Bool t224;
			if (g->OperationOnAny(ctx,6,t223.cv(),Long(4).cv(),t224.cv())) goto _0;
			if (!(t224.get())) goto _30;
		}
		{
			Bool t225;
			t225=4==liCol.get();
			Bool t226;
			t226=3==liCol.get();
			if (!( t225.get()||t226.get())) goto _32;
		}
		{
			Obj t228;
			c.f.fLine=126;
			if (g->Call(ctx,(PCV[]){t228.cv()},0,1466)) goto _0;
			Variant t229;
			if (g->GetMember(ctx,t228.cv(),KcolQryLines.cv(),t229.cv())) goto _0;
			Long t230;
			t230=liRow.get()-1;
			Variant t231;
			if (g->GetMember(ctx,t229.cv(),t230.cv(),t231.cv())) goto _0;
			Variant t232;
			if (g->GetMember(ctx,t231.cv(),KtAlias.cv(),t232.cv())) goto _0;
			Bool t233;
			if (g->OperationOnAny(ctx,6,t232.cv(),K.cv(),t233.cv())) goto _0;
			if (!(t233.get())) goto _33;
		}
		c.f.fLine=127;
		if (g->Call(ctx,(PCV[]){nullptr,k34HMjgGobfs.cv()},1,41)) goto _0;
		g->Check(ctx);
		{
			Obj t234;
			c.f.fLine=128;
			if (g->Call(ctx,(PCV[]){t234.cv()},0,1466)) goto _0;
			Variant t235;
			if (g->GetMember(ctx,t234.cv(),KtCurPage.cv(),t235.cv())) goto _0;
			Variant t236;
			if (g->OperationOnAny(ctx,0,KtAlias.cv(),t235.cv(),t236.cv())) goto _0;
			Txt t237;
			if (!g->GetValue(ctx,(PCV[]){t237.cv(),t236.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t237.cv()},2,870)) goto _0;
			g->Check(ctx);
		}
_33:
		goto _31;
_32:
_31:
		goto _6;
_30:
		{
			Variant t238;
			c.f.fLine=136;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t238.cv())) goto _0;
			Bool t239;
			if (g->OperationOnAny(ctx,6,t238.cv(),Long(20).cv(),t239.cv())) goto _0;
			if (!(t239.get())) goto _34;
		}
		if (4!=liCol.get()) goto _36;
		{
			Obj t241;
			c.f.fLine=140;
			if (g->Call(ctx,(PCV[]){t241.cv()},0,1466)) goto _0;
			Variant t242;
			if (g->GetMember(ctx,t241.cv(),KcolQryLines.cv(),t242.cv())) goto _0;
			Long t243;
			t243=liRow.get()-1;
			Variant t244;
			if (g->GetMember(ctx,t242.cv(),t243.cv(),t244.cv())) goto _0;
			Obj t245;
			if (g->Call(ctx,(PCV[]){t245.cv()},0,1466)) goto _0;
			Variant t246;
			if (g->GetMember(ctx,t245.cv(),KcolQryLines.cv(),t246.cv())) goto _0;
			Long t247;
			t247=liRow.get()-1;
			Variant t248;
			if (g->GetMember(ctx,t246.cv(),t247.cv(),t248.cv())) goto _0;
			Variant t249;
			if (g->GetMember(ctx,t248.cv(),KvValue.cv(),t249.cv())) goto _0;
			if (g->SetMember(ctx,t244.cv(),KqryValue.cv(),t249.cv())) goto _0;
		}
		{
			Obj t250;
			c.f.fLine=142;
			if (g->Call(ctx,(PCV[]){t250.cv()},0,1466)) goto _0;
			Variant t251;
			if (g->GetMember(ctx,t250.cv(),KcolQryLines.cv(),t251.cv())) goto _0;
			Long t252;
			t252=liRow.get()-1;
			Variant t253;
			if (g->GetMember(ctx,t251.cv(),t252.cv(),t253.cv())) goto _0;
			Variant t254;
			if (g->GetMember(ctx,t253.cv(),KtWildCard.cv(),t254.cv())) goto _0;
			Bool t255;
			if (g->OperationOnAny(ctx,7,t254.cv(),Value_null().cv(),t255.cv())) goto _0;
			if (!(t255.get())) goto _37;
		}
		{
			Obj t256;
			c.f.fLine=143;
			if (g->Call(ctx,(PCV[]){t256.cv()},0,1466)) goto _0;
			Variant t257;
			if (g->GetMember(ctx,t256.cv(),KcolQryLines.cv(),t257.cv())) goto _0;
			Long t258;
			t258=liRow.get()-1;
			Variant t259;
			if (g->GetMember(ctx,t257.cv(),t258.cv(),t259.cv())) goto _0;
			Variant t260;
			if (g->GetMember(ctx,t259.cv(),KtWildCard.cv(),t260.cv())) goto _0;
			Bool t261;
			if (g->OperationOnAny(ctx,7,t260.cv(),KNONE.cv(),t261.cv())) goto _0;
			Obj t262;
			if (g->Call(ctx,(PCV[]){t262.cv()},0,1466)) goto _0;
			Variant t263;
			if (g->GetMember(ctx,t262.cv(),KcolQryLines.cv(),t263.cv())) goto _0;
			Long t264;
			t264=liRow.get()-1;
			Variant t265;
			if (g->GetMember(ctx,t263.cv(),t264.cv(),t265.cv())) goto _0;
			Variant t266;
			if (g->GetMember(ctx,t265.cv(),KqryValue.cv(),t266.cv())) goto _0;
			Long t267;
			if (g->Call(ctx,(PCV[]){t267.cv(),t266.cv()},1,1509)) goto _0;
			Bool t268;
			t268=2==t267.get();
			Bool t269;
			t269=t261.get()&&t268.get();
			if (!(t269.get())) goto _38;
		}
		{
			Obj t270;
			c.f.fLine=144;
			if (g->Call(ctx,(PCV[]){t270.cv()},0,1466)) goto _0;
			Variant t271;
			if (g->GetMember(ctx,t270.cv(),KcolQryLines.cv(),t271.cv())) goto _0;
			Long t272;
			t272=liRow.get()-1;
			Variant t273;
			if (g->GetMember(ctx,t271.cv(),t272.cv(),t273.cv())) goto _0;
			Variant t274;
			if (g->GetMember(ctx,t273.cv(),KvValue.cv(),t274.cv())) goto _0;
			Txt t275;
			if (!g->GetValue(ctx,(PCV[]){t275.cv(),t274.cv(),nullptr})) goto _0;
			Txt t276;
			if (g->Call(ctx,(PCV[]){t276.cv(),t275.cv(),K_40.cv(),K.cv()},3,233)) goto _0;
			ltValue=t276.get();
		}
		{
			Obj t277;
			c.f.fLine=145;
			if (g->Call(ctx,(PCV[]){t277.cv()},0,1466)) goto _0;
			Variant t278;
			if (g->GetMember(ctx,t277.cv(),KcolQryLines.cv(),t278.cv())) goto _0;
			Long t279;
			t279=liRow.get()-1;
			Variant t280;
			if (g->GetMember(ctx,t278.cv(),t279.cv(),t280.cv())) goto _0;
			Obj t281;
			if (g->Call(ctx,(PCV[]){t281.cv()},0,1466)) goto _0;
			Variant t282;
			if (g->GetMember(ctx,t281.cv(),KcolQryLines.cv(),t282.cv())) goto _0;
			Long t283;
			t283=liRow.get()-1;
			Variant t284;
			if (g->GetMember(ctx,t282.cv(),t283.cv(),t284.cv())) goto _0;
			Variant t285;
			if (g->GetMember(ctx,t284.cv(),KqryValue.cv(),t285.cv())) goto _0;
			Txt t286;
			if (!g->GetValue(ctx,(PCV[]){t286.cv(),t285.cv(),nullptr})) goto _0;
			Txt t287;
			if (g->Call(ctx,(PCV[]){t287.cv(),t286.cv(),K_40.cv(),K.cv()},3,233)) goto _0;
			if (g->SetMember(ctx,t280.cv(),KqryValue.cv(),t287.cv())) goto _0;
		}
		{
			Obj t288;
			c.f.fLine=147;
			if (g->Call(ctx,(PCV[]){t288.cv()},0,1466)) goto _0;
			Variant t289;
			if (g->GetMember(ctx,t288.cv(),KcolQryLines.cv(),t289.cv())) goto _0;
			Long t290;
			t290=liRow.get()-1;
			Variant t291;
			if (g->GetMember(ctx,t289.cv(),t290.cv(),t291.cv())) goto _0;
			Variant t292;
			if (g->GetMember(ctx,t291.cv(),KtWildCard.cv(),t292.cv())) goto _0;
			Bool t293;
			if (g->OperationOnAny(ctx,6,t292.cv(),KSTART_2FEND.cv(),t293.cv())) goto _0;
			if (!(t293.get())) goto _40;
		}
		{
			Obj t294;
			c.f.fLine=148;
			if (g->Call(ctx,(PCV[]){t294.cv()},0,1466)) goto _0;
			Variant t295;
			if (g->GetMember(ctx,t294.cv(),KcolQryLines.cv(),t295.cv())) goto _0;
			Long t296;
			t296=liRow.get()-1;
			Variant t297;
			if (g->GetMember(ctx,t295.cv(),t296.cv(),t297.cv())) goto _0;
			Txt t298;
			g->AddString(K_40.get(),ltValue.get(),t298.get());
			Txt t299;
			g->AddString(t298.get(),K_40.get(),t299.get());
			if (g->SetMember(ctx,t297.cv(),KqryValue.cv(),t299.cv())) goto _0;
		}
		goto _39;
_40:
		{
			Obj t300;
			c.f.fLine=150;
			if (g->Call(ctx,(PCV[]){t300.cv()},0,1466)) goto _0;
			Variant t301;
			if (g->GetMember(ctx,t300.cv(),KcolQryLines.cv(),t301.cv())) goto _0;
			Long t302;
			t302=liRow.get()-1;
			Variant t303;
			if (g->GetMember(ctx,t301.cv(),t302.cv(),t303.cv())) goto _0;
			Variant t304;
			if (g->GetMember(ctx,t303.cv(),KtWildCard.cv(),t304.cv())) goto _0;
			Bool t305;
			if (g->OperationOnAny(ctx,6,t304.cv(),KSTART.cv(),t305.cv())) goto _0;
			if (!(t305.get())) goto _41;
		}
		{
			Obj t306;
			c.f.fLine=151;
			if (g->Call(ctx,(PCV[]){t306.cv()},0,1466)) goto _0;
			Variant t307;
			if (g->GetMember(ctx,t306.cv(),KcolQryLines.cv(),t307.cv())) goto _0;
			Long t308;
			t308=liRow.get()-1;
			Variant t309;
			if (g->GetMember(ctx,t307.cv(),t308.cv(),t309.cv())) goto _0;
			Txt t310;
			g->AddString(K_40.get(),ltValue.get(),t310.get());
			if (g->SetMember(ctx,t309.cv(),KqryValue.cv(),t310.cv())) goto _0;
		}
		goto _39;
_41:
		{
			Obj t311;
			c.f.fLine=153;
			if (g->Call(ctx,(PCV[]){t311.cv()},0,1466)) goto _0;
			Variant t312;
			if (g->GetMember(ctx,t311.cv(),KcolQryLines.cv(),t312.cv())) goto _0;
			Long t313;
			t313=liRow.get()-1;
			Variant t314;
			if (g->GetMember(ctx,t312.cv(),t313.cv(),t314.cv())) goto _0;
			Variant t315;
			if (g->GetMember(ctx,t314.cv(),KtWildCard.cv(),t315.cv())) goto _0;
			Bool t316;
			if (g->OperationOnAny(ctx,6,t315.cv(),KEND.cv(),t316.cv())) goto _0;
			if (!(t316.get())) goto _42;
		}
		{
			Obj t317;
			c.f.fLine=154;
			if (g->Call(ctx,(PCV[]){t317.cv()},0,1466)) goto _0;
			Variant t318;
			if (g->GetMember(ctx,t317.cv(),KcolQryLines.cv(),t318.cv())) goto _0;
			Long t319;
			t319=liRow.get()-1;
			Variant t320;
			if (g->GetMember(ctx,t318.cv(),t319.cv(),t320.cv())) goto _0;
			Txt t321;
			g->AddString(ltValue.get(),K_40.get(),t321.get());
			if (g->SetMember(ctx,t320.cv(),KqryValue.cv(),t321.cv())) goto _0;
		}
		goto _39;
_42:
_39:
_38:
_37:
		goto _35;
_36:
_35:
		goto _6;
_34:
_6:
_5:
		goto _3;
_4:
_3:
_2:
_0:
_1:
;
	}

}
