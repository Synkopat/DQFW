extern Txt K;
extern Txt KAlias;
extern Txt KAttribute;
extern Txt KDBAliases;
extern Txt KDataClass;
extern Txt KDone;
extern Txt KIsIndexed;
extern Txt KObjectName;
extern Txt KObjectType;
extern Txt KParentDataClass;
extern Txt K_3B;
extern Txt Kfirst;
extern Txt Kindexed;
extern Txt Kkind;
extern Txt Knew;
extern Txt Kquery;
extern Txt Ksave;
extern Txt Kstorage;
extern Txt kdfhMtAt0bDs;
extern Txt kvMa7T0CfUPc;
extern Txt kzcH0gI8C0HI;
extern unsigned char D_proc_DQFW__INITDBALIASES[];
void proc_DQFW__INITDBALIASES( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__INITDBALIASES);
	if (!ctx->doingAbort) {
		Col lcolDataClasses;
		Txt ltDataClasses;
		Txt ltDataClass;
		Obj loDataClass;
		Obj l__4D__auto__iter__0;
		Obj l__4D__auto__iter__1;
		Txt ltAtrrb;
		Obj leAlias;
		Bool lbSetAlias;
		Bool lJCPEREZ__20241102;
		ltDataClasses=kdfhMtAt0bDs.get();
		{
			Long t0;
			t0=inNbExplicitParam;
			if (1>t0.get()) goto _2;
		}
		c.f.fLine=15;
		ltDataClasses=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
_2:
		{
			Col t2;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolDataClasses=t2.get();
		}
		{
			Col t3;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t3.cv(),ltDataClasses.cv(),K_3B.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolDataClasses=t3.get();
		}
		{
			Ref t4;
			t4.setLocalRef(ctx,ltDataClass.cv());
			Obj t5;
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){t5.cv(),t4.cv(),lcolDataClasses.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t5.get();
		}
_3:
		{
			Bool t6;
			if (g->Call(ctx,(PCV[]){t6.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t6.get())) goto _4;
		}
		{
			Obj t7;
			c.f.fLine=28;
			if (g->Call(ctx,(PCV[]){t7.cv()},0,1482)) goto _0;
			Variant t8;
			if (g->Call(ctx,(PCV[]){t8.cv(),t7.cv(),KDBAliases.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t9;
			if (g->Call(ctx,(PCV[]){t9.cv(),t8.cv(),Kquery.cv(),kvMa7T0CfUPc.cv(),KDataClass.cv(),K.cv(),ltDataClass.cv()},6,1498)) goto _0;
			Variant t10;
			if (g->Call(ctx,(PCV[]){t10.cv(),t9.cv(),Kfirst.cv()},2,1498)) goto _0;
			Obj t11;
			if (!g->GetValue(ctx,(PCV[]){t11.cv(),t10.cv(),nullptr})) goto _0;
			leAlias=t11.get();
		}
		{
			Bool t12;
			t12=leAlias.isNull();
			if (!(t12.get())) goto _5;
		}
		{
			Obj t13;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t13.cv()},0,1482)) goto _0;
			Variant t14;
			if (g->Call(ctx,(PCV[]){t14.cv(),t13.cv(),KDBAliases.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t15;
			if (g->Call(ctx,(PCV[]){t15.cv(),t14.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t16;
			if (!g->GetValue(ctx,(PCV[]){t16.cv(),t15.cv(),nullptr})) goto _0;
			leAlias=t16.get();
		}
		c.f.fLine=31;
		if (g->SetMember(ctx,leAlias.cv(),KObjectType.cv(),KDataClass.cv())) goto _0;
		c.f.fLine=32;
		if (g->SetMember(ctx,leAlias.cv(),KParentDataClass.cv(),K.cv())) goto _0;
		c.f.fLine=33;
		if (g->SetMember(ctx,leAlias.cv(),KObjectName.cv(),ltDataClass.cv())) goto _0;
		c.f.fLine=34;
		if (g->SetMember(ctx,leAlias.cv(),KAlias.cv(),ltDataClass.cv())) goto _0;
		{
			Bool t17;
			t17=Bool(1).get();
			c.f.fLine=35;
			if (g->SetMember(ctx,leAlias.cv(),kzcH0gI8C0HI.cv(),t17.cv())) goto _0;
		}
		{
			Bool t18;
			t18=Bool(0).get();
			c.f.fLine=36;
			if (g->SetMember(ctx,leAlias.cv(),KIsIndexed.cv(),t18.cv())) goto _0;
		}
		c.f.fLine=37;
		if (g->Call(ctx,(PCV[]){nullptr,leAlias.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
_5:
		{
			Obj t19;
			c.f.fLine=41;
			if (g->Call(ctx,(PCV[]){t19.cv()},0,1482)) goto _0;
			Variant t20;
			if (g->GetMember(ctx,t19.cv(),ltDataClass.cv(),t20.cv())) goto _0;
			Obj t21;
			if (!g->GetValue(ctx,(PCV[]){t21.cv(),t20.cv(),nullptr})) goto _0;
			loDataClass=t21.get();
		}
		{
			Ref t22;
			t22.setLocalRef(ctx,ltAtrrb.cv());
			Obj t23;
			c.f.fLine=42;
			if (g->Call(ctx,(PCV[]){t23.cv(),t22.cv(),loDataClass.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t23.get();
		}
_6:
		{
			Bool t24;
			if (g->Call(ctx,(PCV[]){t24.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t24.get())) goto _7;
		}
		{
			Variant t25;
			c.f.fLine=43;
			if (g->GetMember(ctx,loDataClass.cv(),ltAtrrb.cv(),t25.cv())) goto _0;
			Variant t26;
			if (g->GetMember(ctx,t25.cv(),Kkind.cv(),t26.cv())) goto _0;
			Bool t27;
			if (g->OperationOnAny(ctx,6,t26.cv(),Kstorage.cv(),t27.cv())) goto _0;
			lbSetAlias=t27.get();
		}
		if (!(lbSetAlias.get())) goto _8;
		{
			Obj t28;
			c.f.fLine=45;
			if (g->Call(ctx,(PCV[]){t28.cv()},0,1482)) goto _0;
			Variant t29;
			if (g->Call(ctx,(PCV[]){t29.cv(),t28.cv(),KDBAliases.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t30;
			if (g->Call(ctx,(PCV[]){t30.cv(),t29.cv(),Kquery.cv(),kvMa7T0CfUPc.cv(),KAttribute.cv(),ltDataClass.cv(),ltAtrrb.cv()},6,1498)) goto _0;
			Variant t31;
			if (g->Call(ctx,(PCV[]){t31.cv(),t30.cv(),Kfirst.cv()},2,1498)) goto _0;
			Obj t32;
			if (!g->GetValue(ctx,(PCV[]){t32.cv(),t31.cv(),nullptr})) goto _0;
			leAlias=t32.get();
		}
		{
			Bool t33;
			t33=leAlias.isNull();
			if (!(t33.get())) goto _9;
		}
		{
			Obj t34;
			c.f.fLine=48;
			if (g->Call(ctx,(PCV[]){t34.cv()},0,1482)) goto _0;
			Variant t35;
			if (g->Call(ctx,(PCV[]){t35.cv(),t34.cv(),KDBAliases.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t36;
			if (g->Call(ctx,(PCV[]){t36.cv(),t35.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t37;
			if (!g->GetValue(ctx,(PCV[]){t37.cv(),t36.cv(),nullptr})) goto _0;
			leAlias=t37.get();
		}
		c.f.fLine=49;
		if (g->SetMember(ctx,leAlias.cv(),KObjectType.cv(),KAttribute.cv())) goto _0;
		c.f.fLine=50;
		if (g->SetMember(ctx,leAlias.cv(),KParentDataClass.cv(),ltDataClass.cv())) goto _0;
		c.f.fLine=51;
		if (g->SetMember(ctx,leAlias.cv(),KObjectName.cv(),ltAtrrb.cv())) goto _0;
		c.f.fLine=52;
		if (g->SetMember(ctx,leAlias.cv(),KAlias.cv(),ltAtrrb.cv())) goto _0;
		{
			Variant t38;
			c.f.fLine=53;
			if (g->GetMember(ctx,loDataClass.cv(),ltAtrrb.cv(),t38.cv())) goto _0;
			Variant t39;
			if (g->GetMember(ctx,t38.cv(),Kindexed.cv(),t39.cv())) goto _0;
			Bool t40;
			if (g->Call(ctx,(PCV[]){t40.cv(),t39.cv()},1,1537)) goto _0;
			Bool t41;
			t41=t40.get();
			if (g->SetMember(ctx,leAlias.cv(),kzcH0gI8C0HI.cv(),t41.cv())) goto _0;
		}
		{
			Variant t42;
			c.f.fLine=54;
			if (g->GetMember(ctx,loDataClass.cv(),ltAtrrb.cv(),t42.cv())) goto _0;
			Variant t43;
			if (g->GetMember(ctx,t42.cv(),Kindexed.cv(),t43.cv())) goto _0;
			Bool t44;
			if (g->Call(ctx,(PCV[]){t44.cv(),t43.cv()},1,1537)) goto _0;
			Bool t45;
			t45=t44.get();
			if (g->SetMember(ctx,leAlias.cv(),KIsIndexed.cv(),t45.cv())) goto _0;
		}
		c.f.fLine=55;
		if (g->Call(ctx,(PCV[]){nullptr,leAlias.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
_9:
_8:
		goto _6;
_7:
		{
			Obj t46;
			l__4D__auto__iter__0=t46.get();
		}
		goto _3;
_4:
		{
			Obj t47;
			l__4D__auto__iter__1=t47.get();
		}
		c.f.fLine=64;
		if (g->Call(ctx,(PCV[]){nullptr,KDone.cv()},1,41)) goto _0;
		g->Check(ctx);
_0:
_1:
;
	}

}
