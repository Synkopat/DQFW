Asm4d_Proc proc_SBK__ADMINISTRATIONHNDL;
extern unsigned char D_obj_p_87_SBK__Administration_00bttnImport[];
void obj_p_87_SBK__Administration_00bttnImport( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_obj_p_87_SBK__Administration_00bttnImport);
	if (!ctx->doingAbort) {
		{
			Obj t0;
			c.f.fLine=10;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1606)) goto _0;
			g->Check(ctx);
			proc_SBK__ADMINISTRATIONHNDL(glob,ctx,1,1,(PCV[]){t0.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
_0:
_1:
;
	}

}
