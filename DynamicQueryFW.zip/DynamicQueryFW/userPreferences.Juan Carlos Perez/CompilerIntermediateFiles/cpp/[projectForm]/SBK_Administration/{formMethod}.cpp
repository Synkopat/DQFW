extern Txt KobjectName;
Asm4d_Proc proc_SBK__ADMINISTRATIONHNDL;
extern unsigned char D_form_p_SBK__Administration[];
void form_p_SBK__Administration( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_form_p_SBK__Administration);
	if (!ctx->doingAbort) {
		{
			Obj t0;
			c.f.fLine=9;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1606)) goto _0;
			g->Check(ctx);
			Variant t1;
			if (g->GetMember(ctx,t0.cv(),KobjectName.cv(),t1.cv())) goto _0;
			Bool t2;
			if (g->OperationOnAny(ctx,6,t1.cv(),Value_null().cv(),t2.cv())) goto _0;
			if (!(t2.get())) goto _2;
		}
		{
			Obj t3;
			c.f.fLine=10;
			if (g->Call(ctx,(PCV[]){t3.cv()},0,1606)) goto _0;
			g->Check(ctx);
			proc_SBK__ADMINISTRATIONHNDL(glob,ctx,1,1,(PCV[]){t3.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
_2:
_0:
_1:
;
	}

}
