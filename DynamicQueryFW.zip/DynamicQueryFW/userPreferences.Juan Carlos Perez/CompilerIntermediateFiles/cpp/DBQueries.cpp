extern unsigned char D_proc_DBQUERIES[];
void proc_DBQUERIES( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DBQUERIES);
	if (!ctx->doingAbort) {
_0:
_1:
;
	}

}
