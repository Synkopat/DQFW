extern unsigned char D_proc_UTIL__SETOBJVALUES[];
void proc_UTIL__SETOBJVALUES( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_UTIL__SETOBJVALUES);
	if (!ctx->doingAbort) {
		Col lcolKeys;
		Value_array_text latProperties;
		Txt ltKey;
		Obj loOrig;
		Obj loSource;
		Obj l__4D__auto__iter__0;
		Bool lJCPEREZ__20241102;
		c.f.fLine=11;
		loOrig=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=12;
		loSource=Parm<Obj>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		{
			Ref t0;
			t0.setLocalRef(ctx,latProperties.cv());
			c.f.fLine=16;
			if (g->Call(ctx,(PCV[]){nullptr,t0.cv(),Long(0).cv()},2,222)) goto _0;
		}
		{
			Col t1;
			c.f.fLine=18;
			if (g->Call(ctx,(PCV[]){t1.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolKeys=t1.get();
		}
		{
			Ref t2;
			t2.setLocalRef(ctx,latProperties.cv());
			c.f.fLine=19;
			if (g->Call(ctx,(PCV[]){nullptr,loOrig.cv(),t2.cv()},2,1232)) goto _0;
			g->Check(ctx);
		}
		{
			Ref t3;
			t3.setLocalRef(ctx,latProperties.cv());
			c.f.fLine=20;
			if (g->Call(ctx,(PCV[]){nullptr,lcolKeys.cv(),t3.cv()},2,1563)) goto _0;
			g->Check(ctx);
		}
		{
			Bool t4;
			t4=!loSource.isNull();
			if (!(t4.get())) goto _2;
		}
		{
			Ref t5;
			t5.setLocalRef(ctx,ltKey.cv());
			Obj t6;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t6.cv(),t5.cv(),lcolKeys.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t6.get();
		}
_3:
		{
			Bool t7;
			if (g->Call(ctx,(PCV[]){t7.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t7.get())) goto _4;
		}
		{
			Variant t8;
			c.f.fLine=24;
			if (g->GetMember(ctx,loSource.cv(),ltKey.cv(),t8.cv())) goto _0;
			Bool t9;
			if (g->OperationOnAny(ctx,7,t8.cv(),Value_null().cv(),t9.cv())) goto _0;
			if (!(t9.get())) goto _5;
		}
		{
			Variant t10;
			c.f.fLine=25;
			if (g->GetMember(ctx,loSource.cv(),ltKey.cv(),t10.cv())) goto _0;
			if (g->SetMember(ctx,loOrig.cv(),ltKey.cv(),t10.cv())) goto _0;
		}
_5:
		goto _3;
_4:
		{
			Obj t11;
			l__4D__auto__iter__0=t11.get();
		}
_2:
_0:
_1:
;
	}

}
