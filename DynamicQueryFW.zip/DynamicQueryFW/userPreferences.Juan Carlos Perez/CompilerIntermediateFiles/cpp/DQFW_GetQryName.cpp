extern Txt K;
extern Txt KQry__;
extern Txt K_20;
extern Txt K_2F;
extern Txt K_3A;
extern Txt K__;
extern Txt Kjoin;
extern Txt Kpush;
extern Txt KtAlias;
extern Txt KtComparison;
extern Txt KtLogic;
extern Txt KvValue;
Asm4d_Proc proc_UTIL__CHANGETYPE;
extern unsigned char D_proc_DQFW__GETQRYNAME[];
void proc_DQFW__GETQRYNAME( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__GETQRYNAME);
	if (!ctx->doingAbort) {
		Txt ltQryName;
		Long li;
		Col lcolQryLines;
		Obj l__4D__auto__iter__0;
		Obj loQryLine;
		Col lcolStrings;
		Bool lJCPEREZ__20241102;
		Variant ltValue;
		new ( outResult) Txt();
		c.f.fLine=31;
		lcolQryLines=Parm<Col>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Long t0;
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,459)) goto _0;
			Txt t1;
			if (g->Call(ctx,(PCV[]){t1.cv(),t0.cv()},1,10)) goto _0;
			g->AddString(KQry__.get(),t1.get(),ltQryName.get());
		}
		{
			Col t3;
			c.f.fLine=38;
			if (g->Call(ctx,(PCV[]){t3.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolStrings=t3.get();
		}
		li=0;
		{
			Ref t4;
			t4.setLocalRef(ctx,loQryLine.cv());
			Obj t5;
			c.f.fLine=41;
			if (g->Call(ctx,(PCV[]){t5.cv(),t4.cv(),lcolQryLines.cv(),Long(0).cv(),Long(3).cv()},4,1795)) goto _0;
			l__4D__auto__iter__0=t5.get();
		}
_2:
		{
			Bool t6;
			if (g->Call(ctx,(PCV[]){t6.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t6.get())) goto _3;
		}
		li=li.get()+1;
		if (3<li.get()) goto _4;
		{
			Variant t9;
			c.f.fLine=44;
			if (g->GetMember(ctx,loQryLine.cv(),KtLogic.cv(),t9.cv())) goto _0;
			Bool t10;
			if (g->OperationOnAny(ctx,7,t9.cv(),K.cv(),t10.cv())) goto _0;
			if (!(t10.get())) goto _5;
		}
		{
			Variant t11;
			c.f.fLine=45;
			if (g->GetMember(ctx,loQryLine.cv(),KtLogic.cv(),t11.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,lcolStrings.cv(),Kpush.cv(),t11.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_5:
		{
			Variant t12;
			c.f.fLine=48;
			if (g->GetMember(ctx,loQryLine.cv(),KtAlias.cv(),t12.cv())) goto _0;
			Bool t13;
			if (g->OperationOnAny(ctx,7,t12.cv(),K.cv(),t13.cv())) goto _0;
			if (!(t13.get())) goto _6;
		}
		{
			Variant t14;
			c.f.fLine=49;
			if (g->GetMember(ctx,loQryLine.cv(),KtAlias.cv(),t14.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,lcolStrings.cv(),Kpush.cv(),t14.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_6:
		{
			Variant t15;
			c.f.fLine=52;
			if (g->GetMember(ctx,loQryLine.cv(),KtComparison.cv(),t15.cv())) goto _0;
			Bool t16;
			if (g->OperationOnAny(ctx,7,t15.cv(),K.cv(),t16.cv())) goto _0;
			if (!(t16.get())) goto _7;
		}
		{
			Variant t17;
			c.f.fLine=53;
			if (g->GetMember(ctx,loQryLine.cv(),KtComparison.cv(),t17.cv())) goto _0;
			Txt t18;
			if (!g->GetValue(ctx,(PCV[]){t18.cv(),t17.cv(),nullptr})) goto _0;
			Txt t19;
			if (g->Call(ctx,(PCV[]){t19.cv(),t18.cv(),K_20.cv(),K__.cv()},3,233)) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,lcolStrings.cv(),Kpush.cv(),t19.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_7:
		{
			Variant t20;
			c.f.fLine=56;
			if (g->GetMember(ctx,loQryLine.cv(),KvValue.cv(),t20.cv())) goto _0;
			Variant t21;
			Long t22;
			t22=2;
			Variant t23;
			proc_UTIL__CHANGETYPE(glob,ctx,2,3,(PCV[]){t20.cv(),t22.cv(),t21.cv()},t23.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t23.cv(),ltValue.cv(),nullptr})) goto _0;
		}
		{
			Variant t24;
			c.f.fLine=57;
			if (!g->GetValue(ctx,(PCV[]){t24.cv(),ltValue.cv(),nullptr})) goto _0;
			Bool t25;
			if (g->OperationOnAny(ctx,7,t24.cv(),K.cv(),t25.cv())) goto _0;
			if (!(t25.get())) goto _8;
		}
		{
			Txt t26;
			c.f.fLine=58;
			if (!g->GetValue(ctx,(PCV[]){t26.cv(),ltValue.cv(),nullptr})) goto _0;
			Txt t27;
			if (g->Call(ctx,(PCV[]){t27.cv(),t26.cv(),K_2F.cv(),K.cv()},3,233)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t27.cv(),ltValue.cv(),nullptr})) goto _0;
		}
		{
			Txt t28;
			c.f.fLine=59;
			if (!g->GetValue(ctx,(PCV[]){t28.cv(),ltValue.cv(),nullptr})) goto _0;
			Txt t29;
			if (g->Call(ctx,(PCV[]){t29.cv(),t28.cv(),K_3A.cv(),K.cv()},3,233)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t29.cv(),ltValue.cv(),nullptr})) goto _0;
		}
		{
			Txt t30;
			c.f.fLine=60;
			if (!g->GetValue(ctx,(PCV[]){t30.cv(),ltValue.cv(),nullptr})) goto _0;
			Txt t31;
			if (g->Call(ctx,(PCV[]){t31.cv(),t30.cv(),K_20.cv(),K__.cv()},3,233)) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t31.cv(),ltValue.cv(),nullptr})) goto _0;
		}
		{
			Variant t32;
			c.f.fLine=61;
			if (!g->GetValue(ctx,(PCV[]){t32.cv(),ltValue.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,lcolStrings.cv(),Kpush.cv(),t32.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_8:
_4:
		goto _2;
_3:
		{
			Obj t33;
			l__4D__auto__iter__0=t33.get();
		}
		{
			Variant t34;
			c.f.fLine=67;
			if (g->Call(ctx,(PCV[]){t34.cv(),lcolStrings.cv(),Kjoin.cv(),K__.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Txt t35;
			if (!g->GetValue(ctx,(PCV[]){t35.cv(),t34.cv(),nullptr})) goto _0;
			ltQryName=t35.get();
		}
		c.f.fLine=69;
		Res<Txt>(outResult)=ltQryName.get();
_0:
_1:
;
	}

}
