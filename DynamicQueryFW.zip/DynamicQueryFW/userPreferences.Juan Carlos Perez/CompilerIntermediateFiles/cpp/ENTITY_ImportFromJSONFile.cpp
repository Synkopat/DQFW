extern int32_t vDOCUMENT;
extern int32_t vOK;
extern Txt K;
extern Txt KAND;
extern Txt K_20_22_20;
extern Txt K_2C_20;
extern Txt K_3D;
extern Txt K_7C;
extern Txt Kattributes;
extern Txt KbSuccess;
extern Txt KcolCollection;
extern Txt Kfirst;
extern Txt KfullName;
extern Txt KgetText;
extern Txt KiCreated;
extern Txt KiSkipped;
extern Txt KiUpdated;
extern Txt Kjoin;
extern Txt Kjsn;
extern Txt Klength;
extern Txt KlogicOPs;
extern Txt Knew;
extern Txt Koperators;
extern Txt Kpush;
extern Txt KqryText;
extern Txt Kquery;
extern Txt Ksave;
extern Txt KtError;
extern Txt Kvalues;
extern Txt kBsHDkvsGrPw;
extern Txt kEm7af4vYXiQ;
extern Txt kF_fhco9Ukug;
Asm4d_Proc proc_DQFW__GETQUERYOBJ;
Asm4d_Proc proc_UTIL__IMPORTENTITY;
Asm4d_Proc proc_UTIL__PARSEJSONSTR;
Asm4d_Proc proc_UTIL__VALIDATEATTRNAME;
extern unsigned char D_proc_ENTITY__IMPORTFROMJSONFILE[];
void proc_ENTITY__IMPORTFROMJSONFILE( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_ENTITY__IMPORTFROMJSONFILE);
	if (!ctx->doingAbort) {
		Obj leEntity;
		Obj loValResults;
		Long li;
		Col lcolAttributes2Skip;
		Obj loEntity;
		Txt ltKey;
		Txt ltValidDataClass;
		Col lcolImportedEntities;
		Txt ltDataClass;
		Col lcolKeyAttributes;
		Bool lbValidKeys;
		Obj l__4D__auto__iter__0;
		Obj l__4D__auto__iter__1;
		Obj l__4D__auto__iter__2;
		Obj loQrySettings;
		Time lhImportDoc;
		Obj loResults;
		Col lcolInvalidKeys;
		Value_array_text latDataclasses;
		Obj loImportFile;
		Variant lesEntities;
		Obj loQryRequest;
		Value_array_text latAttrs;
		Bool lJCPEREZ__20241102;
		Txt ltImportedEntities;
		Txt ltAttrName;
		new ( outResult) Obj();
		c.f.fLine=13;
		ltDataClass=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=14;
		lcolKeyAttributes=Parm<Col>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		{
			Ref t0;
			t0.setLocalRef(ctx,latAttrs.cv());
			c.f.fLine=21;
			if (g->Call(ctx,(PCV[]){nullptr,t0.cv(),Long(0).cv()},2,222)) goto _0;
		}
		{
			Ref t1;
			t1.setLocalRef(ctx,latDataclasses.cv());
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){nullptr,t1.cv(),Long(0).cv()},2,222)) goto _0;
		}
		{
			Obj t2;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loResults=t2.get();
		}
		{
			Bool t3;
			t3=Bool(1).get();
			c.f.fLine=25;
			if (g->SetMember(ctx,loResults.cv(),KbSuccess.cv(),t3.cv())) goto _0;
		}
		c.f.fLine=26;
		if (g->SetMember(ctx,loResults.cv(),KtError.cv(),K.cv())) goto _0;
		c.f.fLine=27;
		if (g->SetMember(ctx,loResults.cv(),KiUpdated.cv(),Long(0).cv())) goto _0;
		c.f.fLine=28;
		if (g->SetMember(ctx,loResults.cv(),KiCreated.cv(),Long(0).cv())) goto _0;
		c.f.fLine=29;
		if (g->SetMember(ctx,loResults.cv(),KiSkipped.cv(),Long(0).cv())) goto _0;
		{
			Obj t4;
			c.f.fLine=31;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loQryRequest=t4.get();
		}
		{
			Obj t5;
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){t5.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loQrySettings=t5.get();
		}
		{
			Col t6;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t6.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolInvalidKeys=t6.get();
		}
		{
			Col t7;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t7.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolImportedEntities=t7.get();
		}
		{
			Obj t8;
			c.f.fLine=36;
			if (g->Call(ctx,(PCV[]){t8.cv()},0,1482)) goto _0;
			Txt t9;
			t9=ltDataClass.get();
			Txt t10;
			proc_UTIL__VALIDATEATTRNAME(glob,ctx,2,2,(PCV[]){t8.cv(),t9.cv()},t10.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			ltValidDataClass=t10.get();
		}
		{
			Bool t11;
			t11=g->CompareString(ctx,ltValidDataClass.get(),K.get())!=0;
			if (!(t11.get())) goto _2;
		}
		ltDataClass=ltValidDataClass.get();
		lbValidKeys=Bool(1).get();
		li=-1;
		{
			Ref t12;
			t12.setLocalRef(ctx,ltKey.cv());
			Obj t13;
			c.f.fLine=44;
			if (g->Call(ctx,(PCV[]){t13.cv(),t12.cv(),lcolKeyAttributes.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t13.get();
		}
_3:
		{
			Bool t14;
			if (g->Call(ctx,(PCV[]){t14.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			Bool t15;
			t15=t14.get();
			if (!(t14.get())) goto _4;
			{
				t15=lbValidKeys.get();
			}
_4:
			if (!(t15.get())) goto _5;
		}
		li=li.get()+1;
		{
			Obj t17;
			c.f.fLine=46;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1482)) goto _0;
			Variant t18;
			if (g->GetMember(ctx,t17.cv(),ltDataClass.cv(),t18.cv())) goto _0;
			Txt t19;
			t19=ltKey.get();
			Obj t20;
			if (!g->GetValue(ctx,(PCV[]){t20.cv(),t18.cv(),nullptr})) goto _0;
			Txt t21;
			proc_UTIL__VALIDATEATTRNAME(glob,ctx,2,2,(PCV[]){t20.cv(),t19.cv()},t21.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			ltAttrName=t21.get();
		}
		{
			Bool t22;
			t22=g->CompareString(ctx,ltAttrName.get(),K.get())!=0;
			if (!(t22.get())) goto _6;
		}
		c.f.fLine=48;
		if (g->SetMember(ctx,lcolKeyAttributes.cv(),li.cv(),ltAttrName.cv())) goto _0;
		goto _7;
_6:
		lbValidKeys=Bool(0).get();
		c.f.fLine=51;
		if (g->Call(ctx,(PCV[]){nullptr,lcolInvalidKeys.cv(),Kpush.cv(),ltKey.cv()},3,1500)) goto _0;
		g->Check(ctx);
_7:
		goto _3;
_5:
		{
			Obj t23;
			l__4D__auto__iter__0=t23.get();
		}
		if (!(lbValidKeys.get())) goto _8;
		{
			Time t24;
			c.f.fLine=58;
			if (g->Call(ctx,(PCV[]){t24.cv(),K.cv(),Kjsn.cv()},2,264)) goto _0;
			g->Check(ctx);
			lhImportDoc=t24.get();
		}
		if (1!=Var<Long>(ctx,vOK).get()) goto _9;
		{
			Time t26;
			t26=lhImportDoc.get();
			c.f.fLine=61;
			if (g->Call(ctx,(PCV[]){nullptr,t26.cv()},1,267)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t27;
			c.f.fLine=62;
			if (g->Call(ctx,(PCV[]){t27.cv(),Var<Txt>(ctx,vDOCUMENT).cv(),Long(1).cv()},2,1566)) goto _0;
			g->Check(ctx);
			loImportFile=t27.get();
		}
		{
			Variant t28;
			c.f.fLine=63;
			if (g->Call(ctx,(PCV[]){t28.cv(),loImportFile.cv(),KgetText.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Txt t29;
			if (!g->GetValue(ctx,(PCV[]){t29.cv(),t28.cv(),nullptr})) goto _0;
			ltImportedEntities=t29.get();
		}
		{
			Long t30;
			t30=42;
			Txt t31;
			t31=ltImportedEntities.get();
			Obj t32;
			c.f.fLine=65;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t31.cv(),t30.cv()},t32.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loValResults=t32.get();
		}
		{
			Variant t33;
			c.f.fLine=67;
			if (g->GetMember(ctx,loValResults.cv(),KbSuccess.cv(),t33.cv())) goto _0;
			Bool t34;
			if (!g->GetValue(ctx,(PCV[]){t34.cv(),t33.cv(),nullptr})) goto _0;
			if (!(t34.get())) goto _10;
		}
		{
			Variant t35;
			c.f.fLine=69;
			if (g->GetMember(ctx,loValResults.cv(),KcolCollection.cv(),t35.cv())) goto _0;
			Col t36;
			if (!g->GetValue(ctx,(PCV[]){t36.cv(),t35.cv(),nullptr})) goto _0;
			lcolImportedEntities=t36.get();
		}
		{
			Ref t37;
			t37.setLocalRef(ctx,loEntity.cv());
			Obj t38;
			c.f.fLine=71;
			if (g->Call(ctx,(PCV[]){t38.cv(),t37.cv(),lcolImportedEntities.cv()},2,1795)) goto _0;
			l__4D__auto__iter__2=t38.get();
		}
_11:
		{
			Bool t39;
			if (g->Call(ctx,(PCV[]){t39.cv(),l__4D__auto__iter__2.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t39.get())) goto _12;
		}
		{
			Col t40;
			c.f.fLine=74;
			if (g->Call(ctx,(PCV[]){t40.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQryRequest.cv(),Kattributes.cv(),t40.cv())) goto _0;
		}
		{
			Col t41;
			c.f.fLine=75;
			if (g->Call(ctx,(PCV[]){t41.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQryRequest.cv(),Kvalues.cv(),t41.cv())) goto _0;
		}
		{
			Col t42;
			c.f.fLine=76;
			if (g->Call(ctx,(PCV[]){t42.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQryRequest.cv(),Koperators.cv(),t42.cv())) goto _0;
		}
		{
			Col t43;
			c.f.fLine=77;
			if (g->Call(ctx,(PCV[]){t43.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loQryRequest.cv(),KlogicOPs.cv(),t43.cv())) goto _0;
		}
		lbValidKeys=Bool(1).get();
		{
			Ref t44;
			t44.setLocalRef(ctx,ltKey.cv());
			Obj t45;
			c.f.fLine=80;
			if (g->Call(ctx,(PCV[]){t45.cv(),t44.cv(),lcolKeyAttributes.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t45.get();
		}
_13:
		{
			Bool t46;
			if (g->Call(ctx,(PCV[]){t46.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			g->Check(ctx);
			Bool t47;
			t47=t46.get();
			if (!(t46.get())) goto _14;
			{
				t47=lbValidKeys.get();
			}
_14:
			if (!(t47.get())) goto _15;
		}
		{
			Variant t48;
			c.f.fLine=81;
			if (g->GetMember(ctx,loQryRequest.cv(),Kattributes.cv(),t48.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t48.cv(),Kpush.cv(),ltKey.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t49;
			c.f.fLine=82;
			if (g->GetMember(ctx,loQryRequest.cv(),Koperators.cv(),t49.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t49.cv(),Kpush.cv(),K_3D.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t50;
			c.f.fLine=83;
			if (g->GetMember(ctx,loQryRequest.cv(),KlogicOPs.cv(),t50.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t50.cv(),Kpush.cv(),KAND.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Long t51;
			c.f.fLine=85;
			if (g->Call(ctx,(PCV[]){t51.cv(),loEntity.cv(),ltKey.cv()},2,1230)) goto _0;
			g->Check(ctx);
			if (5==t51.get()) goto _16;
		}
		{
			Variant t53;
			c.f.fLine=86;
			if (g->GetMember(ctx,loQryRequest.cv(),Kvalues.cv(),t53.cv())) goto _0;
			Variant t54;
			if (g->GetMember(ctx,loEntity.cv(),ltKey.cv(),t54.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t53.cv(),Kpush.cv(),t54.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		goto _17;
_16:
		lbValidKeys=Bool(0).get();
_17:
		goto _13;
_15:
		{
			Obj t55;
			l__4D__auto__iter__1=t55.get();
		}
		if (!(lbValidKeys.get())) goto _18;
		{
			Obj t56;
			t56=loQrySettings.get();
			Obj t57;
			t57=loQryRequest.get();
			c.f.fLine=95;
			proc_DQFW__GETQUERYOBJ(glob,ctx,2,2,(PCV[]){t57.cv(),t56.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Obj t58;
			c.f.fLine=96;
			if (g->Call(ctx,(PCV[]){t58.cv()},0,1482)) goto _0;
			Variant t59;
			if (g->GetMember(ctx,t58.cv(),ltDataClass.cv(),t59.cv())) goto _0;
			Variant t60;
			if (g->GetMember(ctx,loQrySettings.cv(),KqryText.cv(),t60.cv())) goto _0;
			Variant t61;
			if (g->Call(ctx,(PCV[]){t61.cv(),t59.cv(),Kquery.cv(),t60.cv(),loQrySettings.cv()},4,1498)) goto _0;
			g->Check(ctx);
			if (!g->SetValue(ctx,(PCV[]){t61.cv(),lesEntities.cv(),nullptr})) goto _0;
		}
		{
			Variant t62;
			c.f.fLine=99;
			if (!g->GetValue(ctx,(PCV[]){t62.cv(),lesEntities.cv(),nullptr})) goto _0;
			Variant t63;
			if (g->Call(ctx,(PCV[]){t63.cv(),t62.cv(),Klength.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Bool t64;
			if (g->OperationOnAny(ctx,5,t63.cv(),Num(1).cv(),t64.cv())) goto _0;
			if (!(t64.get())) goto _20;
		}
		{
			Obj t65;
			leEntity=t65.get();
		}
		{
			Variant t66;
			c.f.fLine=102;
			if (g->GetMember(ctx,loResults.cv(),KiSkipped.cv(),t66.cv())) goto _0;
			Variant t67;
			if (g->OperationOnAny(ctx,0,t66.cv(),Num(1).cv(),t67.cv())) goto _0;
			if (g->SetMember(ctx,loResults.cv(),KiSkipped.cv(),t67.cv())) goto _0;
		}
		goto _19;
_20:
		{
			Variant t68;
			c.f.fLine=104;
			if (!g->GetValue(ctx,(PCV[]){t68.cv(),lesEntities.cv(),nullptr})) goto _0;
			Variant t69;
			if (g->Call(ctx,(PCV[]){t69.cv(),t68.cv(),Klength.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Bool t70;
			if (g->OperationOnAny(ctx,6,t69.cv(),Num(0).cv(),t70.cv())) goto _0;
			if (!(t70.get())) goto _21;
		}
		{
			Obj t71;
			c.f.fLine=105;
			if (g->Call(ctx,(PCV[]){t71.cv()},0,1482)) goto _0;
			Variant t72;
			if (g->GetMember(ctx,t71.cv(),ltDataClass.cv(),t72.cv())) goto _0;
			Variant t73;
			if (g->Call(ctx,(PCV[]){t73.cv(),t72.cv(),Knew.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t74;
			if (!g->GetValue(ctx,(PCV[]){t74.cv(),t73.cv(),nullptr})) goto _0;
			leEntity=t74.get();
		}
		c.f.fLine=106;
		if (g->Call(ctx,(PCV[]){nullptr,leEntity.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
		{
			Variant t75;
			c.f.fLine=107;
			if (g->GetMember(ctx,loResults.cv(),KiCreated.cv(),t75.cv())) goto _0;
			Variant t76;
			if (g->OperationOnAny(ctx,0,t75.cv(),Num(1).cv(),t76.cv())) goto _0;
			if (g->SetMember(ctx,loResults.cv(),KiCreated.cv(),t76.cv())) goto _0;
		}
		goto _19;
_21:
		{
			Variant t77;
			c.f.fLine=110;
			if (!g->GetValue(ctx,(PCV[]){t77.cv(),lesEntities.cv(),nullptr})) goto _0;
			Variant t78;
			if (g->Call(ctx,(PCV[]){t78.cv(),t77.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t79;
			if (!g->GetValue(ctx,(PCV[]){t79.cv(),t78.cv(),nullptr})) goto _0;
			leEntity=t79.get();
		}
		{
			Variant t80;
			c.f.fLine=111;
			if (g->GetMember(ctx,loResults.cv(),KiUpdated.cv(),t80.cv())) goto _0;
			Variant t81;
			if (g->OperationOnAny(ctx,0,t80.cv(),Num(1).cv(),t81.cv())) goto _0;
			if (g->SetMember(ctx,loResults.cv(),KiUpdated.cv(),t81.cv())) goto _0;
		}
_19:
		{
			Bool t82;
			t82=!leEntity.isNull();
			if (!(t82.get())) goto _22;
		}
		{
			Obj t83;
			t83=loEntity.get();
			Obj t84;
			t84=leEntity.get();
			Txt t85;
			t85=ltDataClass.get();
			c.f.fLine=116;
			proc_UTIL__IMPORTENTITY(glob,ctx,3,3,(PCV[]){t85.cv(),t84.cv(),t83.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
_22:
		goto _23;
_18:
		{
			Variant t86;
			c.f.fLine=120;
			if (g->GetMember(ctx,loResults.cv(),KiSkipped.cv(),t86.cv())) goto _0;
			Variant t87;
			if (g->OperationOnAny(ctx,0,t86.cv(),Num(1).cv(),t87.cv())) goto _0;
			if (g->SetMember(ctx,loResults.cv(),KiSkipped.cv(),t87.cv())) goto _0;
		}
_23:
		goto _11;
_12:
		{
			Obj t88;
			l__4D__auto__iter__2=t88.get();
		}
		goto _24;
_10:
		{
			Bool t89;
			t89=Bool(0).get();
			c.f.fLine=127;
			if (g->SetMember(ctx,loResults.cv(),KbSuccess.cv(),t89.cv())) goto _0;
		}
		{
			Variant t90;
			c.f.fLine=128;
			if (g->GetMember(ctx,loImportFile.cv(),KfullName.cv(),t90.cv())) goto _0;
			Variant t91;
			if (g->OperationOnAny(ctx,0,kEm7af4vYXiQ.cv(),t90.cv(),t91.cv())) goto _0;
			Txt t92;
			if (g->Call(ctx,(PCV[]){t92.cv(),Long(13).cv()},1,90)) goto _0;
			Variant t93;
			if (g->OperationOnAny(ctx,0,t91.cv(),t92.cv(),t93.cv())) goto _0;
			Variant t94;
			if (g->OperationOnAny(ctx,0,t93.cv(),K_20_22_20.cv(),t94.cv())) goto _0;
			Variant t95;
			if (g->GetMember(ctx,loValResults.cv(),KtError.cv(),t95.cv())) goto _0;
			Variant t96;
			if (g->OperationOnAny(ctx,0,t94.cv(),t95.cv(),t96.cv())) goto _0;
			if (g->SetMember(ctx,loResults.cv(),KtError.cv(),t96.cv())) goto _0;
		}
_24:
_9:
		goto _25;
_8:
		{
			Bool t97;
			t97=Bool(0).get();
			c.f.fLine=135;
			if (g->SetMember(ctx,loResults.cv(),KbSuccess.cv(),t97.cv())) goto _0;
		}
		{
			Txt t98;
			g->AddString(kF_fhco9Ukug.get(),ltDataClass.get(),t98.get());
			Txt t99;
			g->AddString(t98.get(),K_7C.get(),t99.get());
			Variant t100;
			c.f.fLine=136;
			if (g->Call(ctx,(PCV[]){t100.cv(),lcolInvalidKeys.cv(),Kjoin.cv(),K_2C_20.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Variant t101;
			if (g->OperationOnAny(ctx,0,t99.cv(),t100.cv(),t101.cv())) goto _0;
			if (g->SetMember(ctx,loResults.cv(),KtError.cv(),t101.cv())) goto _0;
		}
_25:
		goto _26;
_2:
		{
			Bool t102;
			t102=Bool(0).get();
			c.f.fLine=141;
			if (g->SetMember(ctx,loResults.cv(),KbSuccess.cv(),t102.cv())) goto _0;
		}
		{
			Txt t103;
			g->AddString(kBsHDkvsGrPw.get(),ltDataClass.get(),t103.get());
			c.f.fLine=142;
			if (g->SetMember(ctx,loResults.cv(),KtError.cv(),t103.cv())) goto _0;
		}
_26:
		c.f.fLine=146;
		Res<Obj>(outResult)=loResults.get();
_0:
_1:
;
	}

}
