extern Txt KDBQueries;
extern Txt Kfirst;
extern Txt Klength;
extern Txt Kquery;
extern Txt k6eRd$w4LQWE;
extern unsigned char D_proc_SBK__GET[];
void proc_SBK__GET( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__GET);
	if (!ctx->doingAbort) {
		Obj leDBQuery;
		Txt ltKey;
		Obj lesDBQueries;
		Bool lJCPEREZ__20241102;
		Txt ltBaseEntity;
		new ( outResult) Obj();
		c.f.fLine=12;
		ltBaseEntity=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=13;
		ltKey=Parm<Txt>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		{
			Obj t0;
			c.f.fLine=17;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1482)) goto _0;
			Variant t1;
			if (g->Call(ctx,(PCV[]){t1.cv(),t0.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t2;
			if (g->Call(ctx,(PCV[]){t2.cv(),t1.cv(),Kquery.cv(),k6eRd$w4LQWE.cv(),ltKey.cv(),ltBaseEntity.cv()},5,1498)) goto _0;
			Obj t3;
			if (!g->GetValue(ctx,(PCV[]){t3.cv(),t2.cv(),nullptr})) goto _0;
			lesDBQueries=t3.get();
		}
		{
			Variant t4;
			c.f.fLine=19;
			if (g->GetMember(ctx,lesDBQueries.cv(),Klength.cv(),t4.cv())) goto _0;
			Bool t5;
			if (g->OperationOnAny(ctx,6,t4.cv(),Num(1).cv(),t5.cv())) goto _0;
			if (!(t5.get())) goto _2;
		}
		{
			Variant t6;
			c.f.fLine=20;
			if (g->Call(ctx,(PCV[]){t6.cv(),lesDBQueries.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t7;
			if (!g->GetValue(ctx,(PCV[]){t7.cv(),t6.cv(),nullptr})) goto _0;
			leDBQuery=t7.get();
		}
_2:
		c.f.fLine=23;
		Res<Obj>(outResult)=leDBQuery.get();
_0:
_1:
;
	}

}
