extern int32_t vDOCUMENT;
extern int32_t vOK;
extern Txt K;
extern Txt K300_2C300;
extern Txt KAND;
extern Txt KAdv;
extern Txt KBaseEntity;
extern Txt KBaseEntity_20_3D_20_3A1;
extern Txt KBttnAddQuestion;
extern Txt KBttnAddSystem;
extern Txt KBttnDelQuestion;
extern Txt KCancel;
extern Txt KCategory;
extern Txt KCreatedBy;
extern Txt KDBQueries;
extern Txt KDisplayQryText;
extern Txt KGroup;
extern Txt KID;
extern Txt KIsActive;
extern Txt KLeave;
extern Txt KQryLines;
extern Txt KQryParams;
extern Txt KQryText;
extern Txt KQueryName;
extern Txt KRole_2CLines;
extern Txt KSelect_20a_20Role;
extern Txt KSingle;
extern Txt KUI__SEARCH;
extern Txt KUSER;
extern Txt K_20AND_20Group_20_23_20_3A2;
extern Txt K_20system_2E_2E_3F;
extern Txt K_40SHORTCUTS_40;
extern Txt KbSuccess;
extern Txt KbttnCloseSystem;
extern Txt KbttnExport;
extern Txt KbttnImport;
extern Txt KbttnSaveQueries;
extern Txt KbttnShortcut_40;
extern Txt Kcode;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt KcolQryLines;
extern Txt Kcopy;
extern Txt Kdrop;
extern Txt KesSystems;
extern Txt Kfirst;
extern Txt Kget;
extern Txt KgetText;
extern Txt KiHdrLineIndx;
extern Txt KiQryLineIndx;
extern Txt Kjsn;
extern Txt KlbQryLines;
extern Txt KlbSystemLines;
extern Txt Klength;
extern Txt KlogicOP;
extern Txt KoObject;
extern Txt KobjectName;
extern Txt KplatformPath;
extern Txt Kpush;
extern Txt KqryLines;
extern Txt KqryText;
extern Txt Kquery;
extern Txt Kremove;
extern Txt Ksave;
extern Txt KsetText;
extern Txt Ksuccess;
extern Txt KtAlias;
extern Txt KtCurPage;
extern Txt KtFormHeader;
extern Txt KtLogic;
extern Txt KtQueryTable;
extern Txt KtSelectionMode;
extern Txt KtoCollection;
extern Txt k7aUcEud5d8s;
extern Txt k9IogFu290Rs;
extern Txt kBK2Q7apxEgw;
extern Txt kBsrRGl7CXWk;
extern Txt kFC3mrBPpIRQ;
extern Txt kFEAgzPXQQ1U;
extern Txt kGk4SEXhP$g4;
extern Txt kGpkCbRdAut0;
extern Txt kHWbpQfb3ej0;
extern Txt kJpMovZgJmOE;
extern Txt kLceznZrfsTE;
extern Txt kRxZpk1vyTOQ;
extern Txt kSw3pZ8WhbHE;
extern Txt kW4zrIKzg05Q;
extern Txt kYK1g15csO4w;
extern Txt kYhLxOkZaZqg;
extern Txt kdhneN13oy0I;
extern Txt kg9WZ56E4v0o;
extern Txt kguJir0$ZYI8;
extern Txt kjUh3rfCnjoI;
extern Txt kkFRmeFTH3a4;
extern Txt kkFuTiDDdsWI;
extern Txt kkhHWtXAdhMw;
extern Txt knB7uuVmo8Xo;
extern Txt knBbNEZaGk_I;
extern Txt ksjVmVct_m1g;
extern Txt ku2OcsofPKtU;
Asm4d_Proc proc_DQFW__GETQRYNAME;
Asm4d_Proc proc_DQFW__PARSEQUERY;
Asm4d_Proc proc_SBK__ADDMODIFY;
Asm4d_Proc proc_SBK__ADMINISTRATIONLBXHNDL;
Asm4d_Proc proc_SBK__SEARCH;
Asm4d_Proc proc_UTIL__PARSEJSONSTR;
Asm4d_Proc proc_WDGT__CONFIGCOLUMNS;
Asm4d_Proc proc_WDGT__SELECT;
extern unsigned char D_proc_SBK__ADMINISTRATIONHNDL[];
void proc_SBK__ADMINISTRATIONHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__ADMINISTRATIONHNDL);
	if (!ctx->doingAbort) {
		Long lid;
		Txt ltCategory;
		Obj loQry;
		Obj lesSystems;
		Obj loExportFile;
		Bool lJCPEREZ__20241102a;
		Obj loItem;
		Txt ltObjectString;
		Txt ltHeaders;
		Long liLines;
		Obj loNewBlankQuery;
		Txt ltGroup;
		Obj leSystem;
		Obj lesDBQueries;
		Txt ltLine;
		Obj loResults;
		Obj loFormEvent;
		Obj loImportFile;
		Time lhDoc;
		Col lcolUserSelection;
		Obj leSystemFirst;
		Bool lVICENTE__20241102a;
		Obj loSysBook;
		Txt ltHiddenCols;
		Obj loListItems;
		Txt ltQueryLines;
		Txt ltHdrMap;
		Bool lbContinue;
		Obj loResult;
		Txt ltWidths;
		c.f.fLine=12;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=14;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t0.cv())) goto _0;
			Bool t1;
			if (g->OperationOnAny(ctx,6,t0.cv(),Value_null().cv(),t1.cv())) goto _0;
			if (!(t1.get())) goto _2;
		}
		{
			Variant t2;
			c.f.fLine=17;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t2.cv())) goto _0;
			Bool t3;
			if (g->OperationOnAny(ctx,6,t2.cv(),Long(1).cv(),t3.cv())) goto _0;
			if (!(t3.get())) goto _4;
		}
		c.f.fLine=18;
		if (g->Call(ctx,(PCV[]){nullptr,Long(1).cv()},1,247)) goto _0;
		g->Check(ctx);
		{
			Obj t4;
			c.f.fLine=19;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t4.cv(),KtCurPage.cv(),KAdv.cv())) goto _0;
		}
		{
			Obj t5;
			t5=loFormEvent.get();
			c.f.fLine=20;
			proc_SBK__ADMINISTRATIONLBXHNDL(glob,ctx,1,1,(PCV[]){t5.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		goto _3;
_4:
_3:
		goto _5;
_2:
		{
			Variant t6;
			c.f.fLine=26;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t6.cv())) goto _0;
			Bool t7;
			if (g->OperationOnAny(ctx,6,t6.cv(),KlbSystemLines.cv(),t7.cv())) goto _0;
			if (!(t7.get())) goto _7;
		}
		{
			Obj t8;
			t8=loFormEvent.get();
			c.f.fLine=27;
			proc_SBK__ADMINISTRATIONLBXHNDL(glob,ctx,1,1,(PCV[]){t8.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		goto _6;
_7:
		{
			Variant t9;
			c.f.fLine=28;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t9.cv())) goto _0;
			Bool t10;
			if (g->OperationOnAny(ctx,6,t9.cv(),KbttnShortcut_40.cv(),t10.cv())) goto _0;
			if (!(t10.get())) goto _8;
		}
		{
			Obj t11;
			c.f.fLine=29;
			if (g->Call(ctx,(PCV[]){t11.cv()},0,1466)) goto _0;
			Variant t12;
			if (g->GetMember(ctx,t11.cv(),KiHdrLineIndx.cv(),t12.cv())) goto _0;
			Bool t13;
			if (g->OperationOnAny(ctx,6,t12.cv(),Num(0).cv(),t13.cv())) goto _0;
			if (!(t13.get())) goto _9;
		}
		c.f.fLine=30;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
		goto _10;
_9:
		ltGroup=KUI__SEARCH.get();
		ltCategory=K_40SHORTCUTS_40.get();
		ltHdrMap=kW4zrIKzg05Q.get();
		ltHeaders=KRole_2CLines.get();
		ltWidths=K300_2C300.get();
		ltHiddenCols=KQryLines.get();
		{
			Obj t14;
			c.f.fLine=43;
			if (g->Call(ctx,(PCV[]){t14.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t14.get();
		}
		{
			Txt t15;
			t15=ltHiddenCols.get();
			Txt t16;
			t16=ltWidths.get();
			Txt t17;
			t17=ltHdrMap.get();
			Txt t18;
			t18=ltHeaders.get();
			Col t19;
			c.f.fLine=44;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t18.cv(),t17.cv(),t16.cv(),t15.cv()},t19.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t19.cv())) goto _0;
		}
		c.f.fLine=45;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),KSelect_20a_20Role.cv())) goto _0;
		c.f.fLine=46;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t20;
			c.f.fLine=47;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t20.cv())) goto _0;
		}
		{
			Obj t21;
			c.f.fLine=49;
			if (g->Call(ctx,(PCV[]){t21.cv()},0,1482)) goto _0;
			Variant t22;
			if (g->Call(ctx,(PCV[]){t22.cv(),t21.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Obj t23;
			if (g->Call(ctx,(PCV[]){t23.cv()},0,1466)) goto _0;
			Variant t24;
			if (g->GetMember(ctx,t23.cv(),KtQueryTable.cv(),t24.cv())) goto _0;
			Variant t25;
			if (g->Call(ctx,(PCV[]){t25.cv(),t22.cv(),Kquery.cv(),kGk4SEXhP$g4.cv(),t24.cv(),ltGroup.cv()},5,1498)) goto _0;
			Obj t26;
			if (!g->GetValue(ctx,(PCV[]){t26.cv(),t25.cv(),nullptr})) goto _0;
			lesSystems=t26.get();
		}
		{
			Bool t27;
			t27=!lesSystems.isNull();
			if (!(t27.get())) goto _11;
		}
		{
			Variant t28;
			c.f.fLine=52;
			if (g->Call(ctx,(PCV[]){t28.cv(),lesSystems.cv(),KtoCollection.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t28.cv())) goto _0;
		}
_11:
		{
			Obj t29;
			t29=loListItems.get();
			Col t30;
			c.f.fLine=55;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t29.cv()},t30.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t30.get();
		}
		{
			Variant t31;
			c.f.fLine=57;
			if (g->Call(ctx,(PCV[]){t31.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t32;
			if (g->OperationOnAny(ctx,6,t31.cv(),Num(1).cv(),t32.cv())) goto _0;
			if (!(t32.get())) goto _12;
		}
		{
			Variant t33;
			c.f.fLine=58;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t33.cv())) goto _0;
			Variant t34;
			if (g->GetMember(ctx,t33.cv(),KQryLines.cv(),t34.cv())) goto _0;
			Long t35;
			t35=38;
			Txt t36;
			if (!g->GetValue(ctx,(PCV[]){t36.cv(),t34.cv(),nullptr})) goto _0;
			Obj t37;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t36.cv(),t35.cv()},t37.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t38;
			if (g->GetMember(ctx,t37.cv(),KoObject.cv(),t38.cv())) goto _0;
			Obj t39;
			if (!g->GetValue(ctx,(PCV[]){t39.cv(),t38.cv(),nullptr})) goto _0;
			loQry=t39.get();
		}
		{
			Bool t40;
			t40=!loQry.isNull();
			if (!(t40.get())) goto _13;
		}
		{
			Obj t41;
			c.f.fLine=61;
			if (g->Call(ctx,(PCV[]){t41.cv()},0,1466)) goto _0;
			Variant t42;
			if (g->GetMember(ctx,t41.cv(),KcolQryLines.cv(),t42.cv())) goto _0;
			Variant t43;
			if (g->GetMember(ctx,t42.cv(),Klength.cv(),t43.cv())) goto _0;
			Bool t44;
			if (g->OperationOnAny(ctx,5,t43.cv(),Num(0).cv(),t44.cv())) goto _0;
			if (!(t44.get())) goto _14;
		}
_14:
		{
			Obj t45;
			c.f.fLine=66;
			if (g->Call(ctx,(PCV[]){t45.cv()},0,1466)) goto _0;
			Variant t46;
			if (g->GetMember(ctx,loQry.cv(),KqryLines.cv(),t46.cv())) goto _0;
			Variant t47;
			if (g->Call(ctx,(PCV[]){t47.cv(),t46.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t45.cv(),KcolQryLines.cv(),t47.cv())) goto _0;
		}
		{
			Obj t48;
			c.f.fLine=67;
			if (g->Call(ctx,(PCV[]){t48.cv()},0,1466)) goto _0;
			Variant t49;
			if (g->GetMember(ctx,t48.cv(),KtCurPage.cv(),t49.cv())) goto _0;
			Variant t50;
			if (g->OperationOnAny(ctx,0,KlbQryLines.cv(),t49.cv(),t50.cv())) goto _0;
			Txt t51;
			if (!g->GetValue(ctx,(PCV[]){t51.cv(),t50.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t51.cv()},2,206)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t52;
			c.f.fLine=68;
			if (g->Call(ctx,(PCV[]){t52.cv()},0,1466)) goto _0;
			Variant t53;
			if (g->GetMember(ctx,t52.cv(),KtCurPage.cv(),t53.cv())) goto _0;
			Variant t54;
			if (g->OperationOnAny(ctx,0,KtAlias.cv(),t53.cv(),t54.cv())) goto _0;
			Obj t55;
			if (g->Call(ctx,(PCV[]){t55.cv()},0,1466)) goto _0;
			Variant t56;
			if (g->GetMember(ctx,t55.cv(),KcolQryLines.cv(),t56.cv())) goto _0;
			Variant t57;
			if (g->GetMember(ctx,t56.cv(),Klength.cv(),t57.cv())) goto _0;
			Txt t58;
			if (!g->GetValue(ctx,(PCV[]){t58.cv(),t54.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t58.cv(),t57.cv()},3,870)) goto _0;
			g->Check(ctx);
		}
		goto _15;
_13:
		c.f.fLine=71;
		if (g->Call(ctx,(PCV[]){nullptr,kYhLxOkZaZqg.cv()},1,41)) goto _0;
		g->Check(ctx);
_15:
_12:
_10:
		goto _6;
_8:
		{
			Variant t59;
			c.f.fLine=75;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t59.cv())) goto _0;
			Bool t60;
			if (g->OperationOnAny(ctx,6,t59.cv(),KbttnImport.cv(),t60.cv())) goto _0;
			if (!(t60.get())) goto _16;
		}
		{
			Obj t61;
			c.f.fLine=76;
			if (g->Call(ctx,(PCV[]){t61.cv()},0,1466)) goto _0;
			Variant t62;
			if (g->GetMember(ctx,t61.cv(),KiHdrLineIndx.cv(),t62.cv())) goto _0;
			Bool t63;
			if (g->OperationOnAny(ctx,6,t62.cv(),Num(0).cv(),t63.cv())) goto _0;
			if (!(t63.get())) goto _17;
		}
		c.f.fLine=77;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
		goto _18;
_17:
		{
			Time t64;
			c.f.fLine=84;
			if (g->Call(ctx,(PCV[]){t64.cv(),K.cv(),Kjsn.cv()},2,264)) goto _0;
			g->Check(ctx);
			lhDoc=t64.get();
		}
		if (1!=Var<Long>(ctx,vOK).get()) goto _19;
		{
			Time t66;
			t66=lhDoc.get();
			c.f.fLine=87;
			if (g->Call(ctx,(PCV[]){nullptr,t66.cv()},1,267)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t67;
			c.f.fLine=88;
			if (g->Call(ctx,(PCV[]){t67.cv(),Var<Txt>(ctx,vDOCUMENT).cv(),Long(1).cv()},2,1566)) goto _0;
			g->Check(ctx);
			loImportFile=t67.get();
		}
		{
			Variant t68;
			c.f.fLine=89;
			if (g->Call(ctx,(PCV[]){t68.cv(),loImportFile.cv(),KgetText.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Txt t69;
			if (!g->GetValue(ctx,(PCV[]){t69.cv(),t68.cv(),nullptr})) goto _0;
			ltQueryLines=t69.get();
		}
		{
			Long t70;
			t70=0;
			Txt t71;
			t71=ltQueryLines.get();
			Obj t72;
			c.f.fLine=90;
			proc_UTIL__PARSEJSONSTR(glob,ctx,1,2,(PCV[]){t71.cv(),t70.cv()},t72.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loResult=t72.get();
		}
		{
			Variant t73;
			c.f.fLine=92;
			if (g->GetMember(ctx,loResult.cv(),KbSuccess.cv(),t73.cv())) goto _0;
			Bool t74;
			if (!g->GetValue(ctx,(PCV[]){t74.cv(),t73.cv(),nullptr})) goto _0;
			if (!(t74.get())) goto _20;
		}
		{
			Variant t75;
			c.f.fLine=93;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t75.cv())) goto _0;
			Variant t76;
			if (g->GetMember(ctx,t75.cv(),KcolQryLines.cv(),t76.cv())) goto _0;
			Bool t77;
			if (g->OperationOnAny(ctx,7,t76.cv(),Value_null().cv(),t77.cv())) goto _0;
			if (!(t77.get())) goto _21;
		}
		{
			Variant t78;
			c.f.fLine=94;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t78.cv())) goto _0;
			Obj t79;
			if (!g->GetValue(ctx,(PCV[]){t79.cv(),t78.cv(),nullptr})) goto _0;
			Long t80;
			if (g->Call(ctx,(PCV[]){t80.cv(),t79.cv(),KcolQryLines.cv()},2,1230)) goto _0;
			g->Check(ctx);
			Bool t81;
			t81=42==t80.get();
			if (!(t81.get())) goto _22;
		}
		{
			Obj t82;
			c.f.fLine=95;
			if (g->Call(ctx,(PCV[]){t82.cv()},0,1466)) goto _0;
			Variant t83;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t83.cv())) goto _0;
			Variant t84;
			if (g->GetMember(ctx,t83.cv(),KcolQryLines.cv(),t84.cv())) goto _0;
			Variant t85;
			if (g->Call(ctx,(PCV[]){t85.cv(),t84.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t82.cv(),KcolQryLines.cv(),t85.cv())) goto _0;
		}
		goto _23;
_22:
		c.f.fLine=98;
		if (g->Call(ctx,(PCV[]){nullptr,kSw3pZ8WhbHE.cv()},1,41)) goto _0;
		g->Check(ctx);
_23:
		goto _24;
_21:
		c.f.fLine=102;
		if (g->Call(ctx,(PCV[]){nullptr,kHWbpQfb3ej0.cv()},1,41)) goto _0;
		g->Check(ctx);
_24:
		goto _25;
_20:
		c.f.fLine=107;
		if (g->Call(ctx,(PCV[]){nullptr,kFEAgzPXQQ1U.cv()},1,41)) goto _0;
		g->Check(ctx);
_25:
_19:
_18:
		goto _6;
_16:
		{
			Variant t86;
			c.f.fLine=113;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t86.cv())) goto _0;
			Bool t87;
			if (g->OperationOnAny(ctx,6,t86.cv(),KbttnExport.cv(),t87.cv())) goto _0;
			if (!(t87.get())) goto _26;
		}
		{
			Obj t88;
			c.f.fLine=114;
			if (g->Call(ctx,(PCV[]){t88.cv()},0,1466)) goto _0;
			Variant t89;
			if (g->GetMember(ctx,t88.cv(),KiHdrLineIndx.cv(),t89.cv())) goto _0;
			Bool t90;
			if (g->OperationOnAny(ctx,6,t89.cv(),Num(0).cv(),t90.cv())) goto _0;
			if (!(t90.get())) goto _27;
		}
		c.f.fLine=115;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
		goto _28;
_27:
		{
			Obj t91;
			c.f.fLine=122;
			if (g->Call(ctx,(PCV[]){t91.cv()},0,1466)) goto _0;
			Variant t92;
			if (g->GetMember(ctx,t91.cv(),KcolQryLines.cv(),t92.cv())) goto _0;
			Variant t93;
			if (g->GetMember(ctx,t92.cv(),Klength.cv(),t93.cv())) goto _0;
			Bool t94;
			if (g->OperationOnAny(ctx,5,t93.cv(),Num(0).cv(),t94.cv())) goto _0;
			if (!(t94.get())) goto _29;
		}
		{
			Time t95;
			c.f.fLine=123;
			if (g->Call(ctx,(PCV[]){t95.cv(),K.cv(),Kjsn.cv()},2,266)) goto _0;
			g->Check(ctx);
			lhDoc=t95.get();
		}
		if (1!=Var<Long>(ctx,vOK).get()) goto _30;
		{
			Time t97;
			t97=lhDoc.get();
			c.f.fLine=126;
			if (g->Call(ctx,(PCV[]){nullptr,t97.cv()},1,267)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t98;
			c.f.fLine=127;
			if (g->Call(ctx,(PCV[]){t98.cv(),Var<Txt>(ctx,vDOCUMENT).cv(),Long(1).cv()},2,1566)) goto _0;
			g->Check(ctx);
			loExportFile=t98.get();
		}
		{
			Obj t99;
			c.f.fLine=128;
			if (g->Call(ctx,(PCV[]){t99.cv()},0,1466)) goto _0;
			Variant t100;
			if (g->GetMember(ctx,t99.cv(),KcolQryLines.cv(),t100.cv())) goto _0;
			Obj t101;
			if (g->Call(ctx,(PCV[]){t101.cv(),KcolQryLines.cv(),t100.cv()},2,1471)) goto _0;
			g->Check(ctx);
			Txt t102;
			if (g->Call(ctx,(PCV[]){t102.cv(),t101.cv()},1,1217)) goto _0;
			ltQueryLines=t102.get();
		}
		c.f.fLine=130;
		if (g->Call(ctx,(PCV[]){nullptr,loExportFile.cv(),KsetText.cv(),ltQueryLines.cv()},3,1500)) goto _0;
		g->Check(ctx);
		{
			Variant t103;
			c.f.fLine=131;
			if (g->GetMember(ctx,loExportFile.cv(),KplatformPath.cv(),t103.cv())) goto _0;
			Variant t104;
			if (g->OperationOnAny(ctx,0,kdhneN13oy0I.cv(),t103.cv(),t104.cv())) goto _0;
			Txt t105;
			if (!g->GetValue(ctx,(PCV[]){t105.cv(),t104.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t105.cv()},1,41)) goto _0;
			g->Check(ctx);
		}
_30:
_29:
_28:
		goto _6;
_26:
		{
			Variant t106;
			c.f.fLine=138;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t106.cv())) goto _0;
			Bool t107;
			if (g->OperationOnAny(ctx,6,t106.cv(),k9IogFu290Rs.cv(),t107.cv())) goto _0;
			if (!(t107.get())) goto _31;
		}
		{
			Obj t108;
			c.f.fLine=141;
			if (g->Call(ctx,(PCV[]){t108.cv()},0,1471)) goto _0;
			g->Check(ctx);
			lesSystems=t108.get();
		}
		{
			Obj t109;
			c.f.fLine=142;
			if (g->Call(ctx,(PCV[]){t109.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSysBook=t109.get();
		}
		{
			Obj t110;
			c.f.fLine=144;
			if (g->Call(ctx,(PCV[]){t110.cv()},0,1466)) goto _0;
			Variant t111;
			if (g->GetMember(ctx,t110.cv(),KtQueryTable.cv(),t111.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KBaseEntity.cv(),t111.cv())) goto _0;
		}
		c.f.fLine=145;
		if (g->SetMember(ctx,loSysBook.cv(),kFC3mrBPpIRQ.cv(),lesSystems.cv())) goto _0;
		{
			Obj t112;
			t112=loSysBook.get();
			Obj t113;
			c.f.fLine=147;
			proc_SBK__SEARCH(glob,ctx,1,1,(PCV[]){t112.cv()},t113.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lesSystems=t113.get();
		}
		{
			Bool t114;
			t114=!lesSystems.isNull();
			if (!(t114.get())) goto _32;
		}
		{
			Obj t115;
			c.f.fLine=150;
			if (g->Call(ctx,(PCV[]){t115.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t115.cv(),KesSystems.cv(),lesSystems.cv())) goto _0;
		}
		{
			Obj t116;
			c.f.fLine=152;
			if (g->Call(ctx,(PCV[]){t116.cv()},0,1466)) goto _0;
			Variant t117;
			if (g->GetMember(ctx,t116.cv(),KesSystems.cv(),t117.cv())) goto _0;
			Variant t118;
			if (g->Call(ctx,(PCV[]){t118.cv(),t117.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t119;
			if (!g->GetValue(ctx,(PCV[]){t119.cv(),t118.cv(),nullptr})) goto _0;
			leSystemFirst=t119.get();
		}
		{
			Obj t120;
			c.f.fLine=153;
			if (g->Call(ctx,(PCV[]){t120.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t120.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		{
			Obj t121;
			c.f.fLine=154;
			if (g->Call(ctx,(PCV[]){t121.cv()},0,1466)) goto _0;
			Col t122;
			if (g->Call(ctx,(PCV[]){t122.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t121.cv(),KcolQryLines.cv(),t122.cv())) goto _0;
		}
		{
			Obj t123;
			c.f.fLine=155;
			if (g->Call(ctx,(PCV[]){t123.cv()},0,1466)) goto _0;
			Variant t124;
			if (g->GetMember(ctx,leSystemFirst.cv(),KQryLines.cv(),t124.cv())) goto _0;
			Long t125;
			t125=38;
			Txt t126;
			if (!g->GetValue(ctx,(PCV[]){t126.cv(),t124.cv(),nullptr})) goto _0;
			Obj t127;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t126.cv(),t125.cv()},t127.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t128;
			if (g->GetMember(ctx,t127.cv(),KoObject.cv(),t128.cv())) goto _0;
			Variant t129;
			if (g->GetMember(ctx,t128.cv(),KqryLines.cv(),t129.cv())) goto _0;
			if (g->SetMember(ctx,t123.cv(),KcolQryLines.cv(),t129.cv())) goto _0;
		}
		{
			Obj t130;
			c.f.fLine=157;
			if (g->Call(ctx,(PCV[]){t130.cv()},0,1466)) goto _0;
			Variant t131;
			if (g->GetMember(ctx,t130.cv(),KcolQryLines.cv(),t131.cv())) goto _0;
			Bool t132;
			if (g->OperationOnAny(ctx,6,t131.cv(),Value_null().cv(),t132.cv())) goto _0;
			if (!(t132.get())) goto _33;
		}
		liLines=0;
		ltObjectString=ku2OcsofPKtU.get();
		{
			Long t133;
			t133=38;
			Txt t134;
			t134=ltObjectString.get();
			Obj t135;
			c.f.fLine=165;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t134.cv(),t133.cv()},t135.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t136;
			if (g->GetMember(ctx,t135.cv(),KoObject.cv(),t136.cv())) goto _0;
			Variant t137;
			if (g->GetMember(ctx,t136.cv(),KqryLines.cv(),t137.cv())) goto _0;
			Variant t138;
			if (g->GetMember(ctx,t137.cv(),Long(0).cv(),t138.cv())) goto _0;
			Obj t139;
			if (!g->GetValue(ctx,(PCV[]){t139.cv(),t138.cv(),nullptr})) goto _0;
			loNewBlankQuery=t139.get();
		}
		{
			Obj t140;
			c.f.fLine=166;
			if (g->Call(ctx,(PCV[]){t140.cv()},0,1466)) goto _0;
			Col t141;
			if (g->Call(ctx,(PCV[]){t141.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t140.cv(),KcolQryLines.cv(),t141.cv())) goto _0;
		}
		{
			Obj t142;
			c.f.fLine=167;
			if (g->Call(ctx,(PCV[]){t142.cv()},0,1466)) goto _0;
			Variant t143;
			if (g->GetMember(ctx,t142.cv(),KcolQryLines.cv(),t143.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t143.cv(),Kpush.cv(),loNewBlankQuery.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_33:
		goto _34;
_32:
		{
			Obj t144;
			c.f.fLine=171;
			if (g->Call(ctx,(PCV[]){t144.cv()},0,1466)) goto _0;
			Variant t145;
			t145.setNull();
			if (g->SetMember(ctx,t144.cv(),KesSystems.cv(),t145.cv())) goto _0;
		}
		{
			Obj t146;
			c.f.fLine=172;
			if (g->Call(ctx,(PCV[]){t146.cv()},0,1466)) goto _0;
			Variant t147;
			t147.setNull();
			if (g->SetMember(ctx,t146.cv(),KcolQryLines.cv(),t147.cv())) goto _0;
		}
_34:
		goto _6;
_31:
		{
			Variant t148;
			c.f.fLine=176;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t148.cv())) goto _0;
			Bool t149;
			if (g->OperationOnAny(ctx,6,t148.cv(),KbttnCloseSystem.cv(),t149.cv())) goto _0;
			if (!(t149.get())) goto _35;
		}
		c.f.fLine=177;
		if (g->Call(ctx,(PCV[]){nullptr,kBK2Q7apxEgw.cv(),KLeave.cv(),KCancel.cv()},3,162)) goto _0;
		g->Check(ctx);
		if (1!=Var<Long>(ctx,vOK).get()) goto _36;
		c.f.fLine=179;
		if (g->Call(ctx,(PCV[]){nullptr},0,270)) goto _0;
		g->Check(ctx);
_36:
		goto _6;
_35:
		{
			Variant t151;
			c.f.fLine=181;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t151.cv())) goto _0;
			Bool t152;
			if (g->OperationOnAny(ctx,6,t151.cv(),KBttnAddQuestion.cv(),t152.cv())) goto _0;
			if (!(t152.get())) goto _37;
		}
		{
			Obj t153;
			c.f.fLine=182;
			if (g->Call(ctx,(PCV[]){t153.cv()},0,1466)) goto _0;
			Variant t154;
			if (g->GetMember(ctx,t153.cv(),KiHdrLineIndx.cv(),t154.cv())) goto _0;
			Bool t155;
			if (g->OperationOnAny(ctx,6,t154.cv(),Num(0).cv(),t155.cv())) goto _0;
			if (!(t155.get())) goto _38;
		}
		{
			Long t156;
			c.f.fLine=183;
			if (g->Call(ctx,(PCV[]){t156.cv(),Ref((optyp)3).cv(),KlbSystemLines.cv()},2,915)) goto _0;
			g->Check(ctx);
			if (1!=t156.get()) goto _39;
		}
		{
			Obj t158;
			c.f.fLine=184;
			if (g->Call(ctx,(PCV[]){t158.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t158.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		lbContinue=Bool(1).get();
		goto _40;
_39:
		c.f.fLine=187;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
_40:
		goto _41;
_38:
		lbContinue=Bool(1).get();
_41:
		if (!(lbContinue.get())) goto _42;
		{
			Obj t159;
			c.f.fLine=198;
			if (g->Call(ctx,(PCV[]){t159.cv()},0,1466)) goto _0;
			Variant t160;
			if (g->GetMember(ctx,t159.cv(),KcolQryLines.cv(),t160.cv())) goto _0;
			Variant t161;
			if (g->GetMember(ctx,t160.cv(),Klength.cv(),t161.cv())) goto _0;
			Long t162;
			if (!g->GetValue(ctx,(PCV[]){t162.cv(),t161.cv(),nullptr})) goto _0;
			liLines=t162.get();
		}
		{
			Long t163;
			t163=liLines.get()+1;
			Txt t164;
			c.f.fLine=199;
			if (g->Call(ctx,(PCV[]){t164.cv(),t163.cv()},1,10)) goto _0;
			ltLine=t164.get();
		}
		if (0>=liLines.get()) goto _43;
		{
			Txt t166;
			g->AddString(kkFRmeFTH3a4.get(),ltLine.get(),t166.get());
			g->AddString(t166.get(),k7aUcEud5d8s.get(),ltObjectString.get());
		}
		goto _44;
_43:
		ltObjectString=ku2OcsofPKtU.get();
_44:
		{
			Long t168;
			t168=38;
			Txt t169;
			t169=ltObjectString.get();
			Obj t170;
			c.f.fLine=207;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t169.cv(),t168.cv()},t170.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t171;
			if (g->GetMember(ctx,t170.cv(),KoObject.cv(),t171.cv())) goto _0;
			Variant t172;
			if (g->GetMember(ctx,t171.cv(),KqryLines.cv(),t172.cv())) goto _0;
			Variant t173;
			if (g->GetMember(ctx,t172.cv(),Long(0).cv(),t173.cv())) goto _0;
			Obj t174;
			if (!g->GetValue(ctx,(PCV[]){t174.cv(),t173.cv(),nullptr})) goto _0;
			loNewBlankQuery=t174.get();
		}
		{
			Obj t175;
			c.f.fLine=208;
			if (g->Call(ctx,(PCV[]){t175.cv()},0,1466)) goto _0;
			Variant t176;
			if (g->GetMember(ctx,t175.cv(),KcolQryLines.cv(),t176.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t176.cv(),Kpush.cv(),loNewBlankQuery.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t177;
			c.f.fLine=209;
			if (g->Call(ctx,(PCV[]){t177.cv()},0,1466)) goto _0;
			Variant t178;
			if (g->GetMember(ctx,t177.cv(),KcolQryLines.cv(),t178.cv())) goto _0;
			Variant t179;
			if (g->GetMember(ctx,t178.cv(),Klength.cv(),t179.cv())) goto _0;
			Long t180;
			if (!g->GetValue(ctx,(PCV[]){t180.cv(),t179.cv(),nullptr})) goto _0;
			liLines=t180.get();
		}
		if (1>=liLines.get()) goto _45;
		{
			Obj t182;
			c.f.fLine=211;
			if (g->Call(ctx,(PCV[]){t182.cv()},0,1466)) goto _0;
			Variant t183;
			if (g->GetMember(ctx,t182.cv(),KcolQryLines.cv(),t183.cv())) goto _0;
			Long t184;
			t184=liLines.get()-1;
			Variant t185;
			if (g->GetMember(ctx,t183.cv(),t184.cv(),t185.cv())) goto _0;
			if (g->SetMember(ctx,t185.cv(),KlogicOP.cv(),KAND.cv())) goto _0;
		}
		{
			Obj t186;
			c.f.fLine=212;
			if (g->Call(ctx,(PCV[]){t186.cv()},0,1466)) goto _0;
			Variant t187;
			if (g->GetMember(ctx,t186.cv(),KcolQryLines.cv(),t187.cv())) goto _0;
			Long t188;
			t188=liLines.get()-1;
			Variant t189;
			if (g->GetMember(ctx,t187.cv(),t188.cv(),t189.cv())) goto _0;
			if (g->SetMember(ctx,t189.cv(),KtLogic.cv(),KAND.cv())) goto _0;
		}
_45:
_42:
		goto _6;
_37:
		{
			Variant t190;
			c.f.fLine=216;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t190.cv())) goto _0;
			Bool t191;
			if (g->OperationOnAny(ctx,6,t190.cv(),KbttnSaveQueries.cv(),t191.cv())) goto _0;
			if (!(t191.get())) goto _46;
		}
		lbContinue=Bool(0).get();
		{
			Obj t192;
			c.f.fLine=220;
			if (g->Call(ctx,(PCV[]){t192.cv()},0,1466)) goto _0;
			Variant t193;
			if (g->GetMember(ctx,t192.cv(),KiHdrLineIndx.cv(),t193.cv())) goto _0;
			Bool t194;
			if (g->OperationOnAny(ctx,6,t193.cv(),Num(0).cv(),t194.cv())) goto _0;
			if (!(t194.get())) goto _47;
		}
		{
			Long t195;
			c.f.fLine=221;
			if (g->Call(ctx,(PCV[]){t195.cv(),Ref((optyp)3).cv(),KlbSystemLines.cv()},2,915)) goto _0;
			g->Check(ctx);
			if (1!=t195.get()) goto _48;
		}
		{
			Obj t197;
			c.f.fLine=222;
			if (g->Call(ctx,(PCV[]){t197.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t197.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		lbContinue=Bool(1).get();
		goto _49;
_48:
		c.f.fLine=225;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
_49:
		goto _50;
_47:
		lbContinue=Bool(1).get();
_50:
		if (!(lbContinue.get())) goto _51;
		{
			Obj t198;
			c.f.fLine=234;
			if (g->Call(ctx,(PCV[]){t198.cv()},0,1466)) goto _0;
			Variant t199;
			if (g->GetMember(ctx,t198.cv(),KcolQryLines.cv(),t199.cv())) goto _0;
			Variant t200;
			if (g->GetMember(ctx,t199.cv(),Klength.cv(),t200.cv())) goto _0;
			Bool t201;
			if (g->OperationOnAny(ctx,5,t200.cv(),Num(0).cv(),t201.cv())) goto _0;
			if (!(t201.get())) goto _52;
		}
		{
			Obj t202;
			c.f.fLine=235;
			if (g->Call(ctx,(PCV[]){t202.cv()},0,1466)) goto _0;
			Variant t203;
			if (g->GetMember(ctx,t202.cv(),KcolQryLines.cv(),t203.cv())) goto _0;
			Variant t204;
			if (g->GetMember(ctx,t203.cv(),Long(0).cv(),t204.cv())) goto _0;
			if (g->SetMember(ctx,t204.cv(),KlogicOP.cv(),K.cv())) goto _0;
		}
		{
			Obj t205;
			c.f.fLine=236;
			if (g->Call(ctx,(PCV[]){t205.cv()},0,1466)) goto _0;
			Variant t206;
			if (g->GetMember(ctx,t205.cv(),KcolQryLines.cv(),t206.cv())) goto _0;
			Variant t207;
			if (g->GetMember(ctx,t206.cv(),Long(0).cv(),t207.cv())) goto _0;
			if (g->SetMember(ctx,t207.cv(),KtLogic.cv(),K.cv())) goto _0;
		}
_52:
		{
			Obj t208;
			c.f.fLine=239;
			if (g->Call(ctx,(PCV[]){t208.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSysBook=t208.get();
		}
		{
			Obj t209;
			c.f.fLine=240;
			if (g->Call(ctx,(PCV[]){t209.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loQry=t209.get();
		}
		{
			Obj t210;
			c.f.fLine=242;
			if (g->Call(ctx,(PCV[]){t210.cv()},0,1466)) goto _0;
			Variant t211;
			if (g->GetMember(ctx,t210.cv(),KcolQryLines.cv(),t211.cv())) goto _0;
			Obj t212;
			if (g->Call(ctx,(PCV[]){t212.cv(),KqryLines.cv(),t211.cv()},2,1471)) goto _0;
			g->Check(ctx);
			Txt t213;
			if (g->Call(ctx,(PCV[]){t213.cv(),t212.cv()},1,1217)) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KQryLines.cv(),t213.cv())) goto _0;
		}
		{
			Obj t214;
			c.f.fLine=244;
			if (g->Call(ctx,(PCV[]){t214.cv()},0,1466)) goto _0;
			Variant t215;
			if (g->GetMember(ctx,t214.cv(),KcolQryLines.cv(),t215.cv())) goto _0;
			Col t216;
			if (!g->GetValue(ctx,(PCV[]){t216.cv(),t215.cv(),nullptr})) goto _0;
			Txt t217;
			proc_DQFW__GETQRYNAME(glob,ctx,1,1,(PCV[]){t216.cv()},t217.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KDisplayQryText.cv(),t217.cv())) goto _0;
		}
		{
			Obj t218;
			c.f.fLine=245;
			if (g->Call(ctx,(PCV[]){t218.cv()},0,1466)) goto _0;
			Variant t219;
			if (g->GetMember(ctx,t218.cv(),KcolQryLines.cv(),t219.cv())) goto _0;
			Obj t220;
			Obj t221;
			t221=loQry.get();
			Col t222;
			if (!g->GetValue(ctx,(PCV[]){t222.cv(),t219.cv(),nullptr})) goto _0;
			proc_DQFW__PARSEQUERY(glob,ctx,2,3,(PCV[]){t222.cv(),t221.cv(),t220.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Variant t223;
			c.f.fLine=246;
			if (g->GetMember(ctx,loQry.cv(),KqryText.cv(),t223.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KQryText.cv(),t223.cv())) goto _0;
		}
		{
			Txt t224;
			c.f.fLine=247;
			if (g->Call(ctx,(PCV[]){t224.cv(),loQry.cv()},1,1217)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loSysBook.cv(),KQryParams.cv(),t224.cv())) goto _0;
		}
		{
			Obj t225;
			c.f.fLine=251;
			if (g->Call(ctx,(PCV[]){t225.cv()},0,1482)) goto _0;
			Variant t226;
			if (g->Call(ctx,(PCV[]){t226.cv(),t225.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Obj t227;
			if (g->Call(ctx,(PCV[]){t227.cv()},0,1466)) goto _0;
			Variant t228;
			if (g->GetMember(ctx,t227.cv(),KesSystems.cv(),t228.cv())) goto _0;
			Obj t229;
			if (g->Call(ctx,(PCV[]){t229.cv()},0,1466)) goto _0;
			Variant t230;
			if (g->GetMember(ctx,t229.cv(),KiHdrLineIndx.cv(),t230.cv())) goto _0;
			Variant t231;
			if (g->OperationOnAny(ctx,1,t230.cv(),Num(1).cv(),t231.cv())) goto _0;
			Variant t232;
			if (g->GetMember(ctx,t228.cv(),t231.cv(),t232.cv())) goto _0;
			Variant t233;
			if (g->GetMember(ctx,t232.cv(),KID.cv(),t233.cv())) goto _0;
			Variant t234;
			if (g->Call(ctx,(PCV[]){t234.cv(),t226.cv(),Kget.cv(),t233.cv()},3,1498)) goto _0;
			Obj t235;
			if (!g->GetValue(ctx,(PCV[]){t235.cv(),t234.cv(),nullptr})) goto _0;
			lesDBQueries=t235.get();
		}
		{
			Bool t236;
			t236=!lesDBQueries.isNull();
			if (!(t236.get())) goto _53;
		}
		{
			Variant t237;
			c.f.fLine=253;
			if (g->GetMember(ctx,loSysBook.cv(),KQryLines.cv(),t237.cv())) goto _0;
			if (g->SetMember(ctx,lesDBQueries.cv(),KQryLines.cv(),t237.cv())) goto _0;
		}
		{
			Variant t238;
			c.f.fLine=254;
			if (g->GetMember(ctx,loSysBook.cv(),KDisplayQryText.cv(),t238.cv())) goto _0;
			if (g->SetMember(ctx,lesDBQueries.cv(),KDisplayQryText.cv(),t238.cv())) goto _0;
		}
		{
			Variant t239;
			c.f.fLine=255;
			if (g->GetMember(ctx,loSysBook.cv(),KQryText.cv(),t239.cv())) goto _0;
			if (g->SetMember(ctx,lesDBQueries.cv(),KQryText.cv(),t239.cv())) goto _0;
		}
		{
			Txt t240;
			c.f.fLine=256;
			if (g->Call(ctx,(PCV[]){t240.cv(),loQry.cv()},1,1217)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,lesDBQueries.cv(),KQryParams.cv(),t240.cv())) goto _0;
		}
		c.f.fLine=257;
		if (g->Call(ctx,(PCV[]){nullptr,lesDBQueries.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
		c.f.fLine=258;
		if (g->Call(ctx,(PCV[]){nullptr,kguJir0$ZYI8.cv()},1,41)) goto _0;
		g->Check(ctx);
		goto _54;
_53:
		c.f.fLine=260;
		if (g->Call(ctx,(PCV[]){nullptr,kg9WZ56E4v0o.cv()},1,41)) goto _0;
		g->Check(ctx);
_54:
		{
			Obj t241;
			c.f.fLine=263;
			if (g->Call(ctx,(PCV[]){t241.cv()},0,1466)) goto _0;
			Variant t242;
			if (g->GetMember(ctx,t241.cv(),KesSystems.cv(),t242.cv())) goto _0;
			Bool t243;
			if (g->OperationOnAny(ctx,7,t242.cv(),Value_null().cv(),t243.cv())) goto _0;
			if (!(t243.get())) goto _55;
		}
		{
			Obj t244;
			c.f.fLine=264;
			if (g->Call(ctx,(PCV[]){t244.cv()},0,1466)) goto _0;
			Obj t245;
			if (g->Call(ctx,(PCV[]){t245.cv()},0,1466)) goto _0;
			Variant t246;
			if (g->GetMember(ctx,t245.cv(),KesSystems.cv(),t246.cv())) goto _0;
			Obj t247;
			if (g->Call(ctx,(PCV[]){t247.cv()},0,1466)) goto _0;
			Variant t248;
			if (g->GetMember(ctx,t247.cv(),KiHdrLineIndx.cv(),t248.cv())) goto _0;
			Variant t249;
			if (g->OperationOnAny(ctx,1,t248.cv(),Num(1).cv(),t249.cv())) goto _0;
			Variant t250;
			if (g->GetMember(ctx,t246.cv(),t249.cv(),t250.cv())) goto _0;
			Variant t251;
			if (g->GetMember(ctx,t250.cv(),KQryLines.cv(),t251.cv())) goto _0;
			Long t252;
			t252=38;
			Txt t253;
			if (!g->GetValue(ctx,(PCV[]){t253.cv(),t251.cv(),nullptr})) goto _0;
			Obj t254;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t253.cv(),t252.cv()},t254.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t255;
			if (g->GetMember(ctx,t254.cv(),KoObject.cv(),t255.cv())) goto _0;
			Variant t256;
			if (g->GetMember(ctx,t255.cv(),KqryLines.cv(),t256.cv())) goto _0;
			if (g->SetMember(ctx,t244.cv(),KcolQryLines.cv(),t256.cv())) goto _0;
		}
		goto _56;
_55:
		{
			Obj t257;
			c.f.fLine=266;
			if (g->Call(ctx,(PCV[]){t257.cv()},0,1466)) goto _0;
			Variant t258;
			t258.setNull();
			if (g->SetMember(ctx,t257.cv(),KcolQryLines.cv(),t258.cv())) goto _0;
		}
_56:
_51:
		goto _6;
_46:
		{
			Variant t259;
			c.f.fLine=269;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t259.cv())) goto _0;
			Bool t260;
			if (g->OperationOnAny(ctx,6,t259.cv(),KBttnDelQuestion.cv(),t260.cv())) goto _0;
			if (!(t260.get())) goto _57;
		}
		{
			Obj t261;
			c.f.fLine=270;
			if (g->Call(ctx,(PCV[]){t261.cv()},0,1466)) goto _0;
			Variant t262;
			if (g->GetMember(ctx,t261.cv(),KiHdrLineIndx.cv(),t262.cv())) goto _0;
			Bool t263;
			if (g->OperationOnAny(ctx,6,t262.cv(),Num(0).cv(),t263.cv())) goto _0;
			if (!(t263.get())) goto _58;
		}
		c.f.fLine=271;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
		goto _59;
_58:
		{
			Obj t264;
			c.f.fLine=273;
			if (g->Call(ctx,(PCV[]){t264.cv()},0,1466)) goto _0;
			Variant t265;
			if (g->GetMember(ctx,t264.cv(),KiQryLineIndx.cv(),t265.cv())) goto _0;
			Bool t266;
			if (g->OperationOnAny(ctx,5,t265.cv(),Num(0).cv(),t266.cv())) goto _0;
			if (!(t266.get())) goto _60;
		}
		{
			Obj t267;
			c.f.fLine=274;
			if (g->Call(ctx,(PCV[]){t267.cv()},0,1466)) goto _0;
			Variant t268;
			if (g->GetMember(ctx,t267.cv(),KcolQryLines.cv(),t268.cv())) goto _0;
			Obj t269;
			if (g->Call(ctx,(PCV[]){t269.cv()},0,1466)) goto _0;
			Variant t270;
			if (g->GetMember(ctx,t269.cv(),KiQryLineIndx.cv(),t270.cv())) goto _0;
			Variant t271;
			if (g->OperationOnAny(ctx,1,t270.cv(),Num(1).cv(),t271.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t268.cv(),Kremove.cv(),t271.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t272;
			c.f.fLine=275;
			if (g->Call(ctx,(PCV[]){t272.cv()},0,1466)) goto _0;
			Variant t273;
			if (g->GetMember(ctx,t272.cv(),KcolQryLines.cv(),t273.cv())) goto _0;
			Variant t274;
			if (g->GetMember(ctx,t273.cv(),Klength.cv(),t274.cv())) goto _0;
			Bool t275;
			if (g->OperationOnAny(ctx,5,t274.cv(),Num(0).cv(),t275.cv())) goto _0;
			if (!(t275.get())) goto _61;
		}
		{
			Obj t276;
			c.f.fLine=277;
			if (g->Call(ctx,(PCV[]){t276.cv()},0,1466)) goto _0;
			Variant t277;
			if (g->GetMember(ctx,t276.cv(),KcolQryLines.cv(),t277.cv())) goto _0;
			Variant t278;
			if (g->GetMember(ctx,t277.cv(),Long(0).cv(),t278.cv())) goto _0;
			if (g->SetMember(ctx,t278.cv(),KlogicOP.cv(),K.cv())) goto _0;
		}
		{
			Obj t279;
			c.f.fLine=278;
			if (g->Call(ctx,(PCV[]){t279.cv()},0,1466)) goto _0;
			Variant t280;
			if (g->GetMember(ctx,t279.cv(),KcolQryLines.cv(),t280.cv())) goto _0;
			Variant t281;
			if (g->GetMember(ctx,t280.cv(),Long(0).cv(),t281.cv())) goto _0;
			if (g->SetMember(ctx,t281.cv(),KtLogic.cv(),K.cv())) goto _0;
		}
_61:
		{
			Obj t282;
			c.f.fLine=280;
			if (g->Call(ctx,(PCV[]){t282.cv()},0,1466)) goto _0;
			Obj t283;
			if (g->Call(ctx,(PCV[]){t283.cv()},0,1466)) goto _0;
			Variant t284;
			if (g->GetMember(ctx,t283.cv(),KcolQryLines.cv(),t284.cv())) goto _0;
			if (g->SetMember(ctx,t282.cv(),KcolQryLines.cv(),t284.cv())) goto _0;
		}
		goto _62;
_60:
		c.f.fLine=282;
		if (g->Call(ctx,(PCV[]){nullptr,knBbNEZaGk_I.cv()},1,41)) goto _0;
		g->Check(ctx);
_62:
_59:
		goto _6;
_57:
		{
			Variant t285;
			c.f.fLine=285;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t285.cv())) goto _0;
			Bool t286;
			if (g->OperationOnAny(ctx,6,t285.cv(),KBttnAddSystem.cv(),t286.cv())) goto _0;
			if (!(t286.get())) goto _63;
		}
		{
			Obj t287;
			c.f.fLine=287;
			if (g->Call(ctx,(PCV[]){t287.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSysBook=t287.get();
		}
		{
			Obj t288;
			c.f.fLine=288;
			if (g->Call(ctx,(PCV[]){t288.cv()},0,1466)) goto _0;
			Variant t289;
			if (g->GetMember(ctx,t288.cv(),KtQueryTable.cv(),t289.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KBaseEntity.cv(),t289.cv())) goto _0;
		}
		c.f.fLine=289;
		if (g->SetMember(ctx,loSysBook.cv(),KGroup.cv(),K.cv())) goto _0;
		c.f.fLine=290;
		if (g->SetMember(ctx,loSysBook.cv(),KCategory.cv(),K.cv())) goto _0;
		{
			Bool t290;
			t290=Bool(1).get();
			c.f.fLine=291;
			if (g->SetMember(ctx,loSysBook.cv(),KIsActive.cv(),t290.cv())) goto _0;
		}
		c.f.fLine=292;
		if (g->SetMember(ctx,loSysBook.cv(),KCreatedBy.cv(),KUSER.cv())) goto _0;
		{
			Variant t291;
			t291.setNull();
			c.f.fLine=293;
			if (g->SetMember(ctx,loSysBook.cv(),KID.cv(),t291.cv())) goto _0;
		}
		{
			Obj t292;
			t292=loSysBook.get();
			Obj t293;
			c.f.fLine=295;
			proc_SBK__ADDMODIFY(glob,ctx,1,1,(PCV[]){t292.cv()},t293.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loResults=t293.get();
		}
		{
			Variant t294;
			c.f.fLine=296;
			if (g->GetMember(ctx,loResults.cv(),Ksuccess.cv(),t294.cv())) goto _0;
			Bool t295;
			if (!g->GetValue(ctx,(PCV[]){t295.cv(),t294.cv(),nullptr})) goto _0;
			if (!(t295.get())) goto _64;
		}
		c.f.fLine=297;
		if (g->Call(ctx,(PCV[]){nullptr,kGpkCbRdAut0.cv()},1,41)) goto _0;
		g->Check(ctx);
_64:
		{
			Variant t296;
			c.f.fLine=303;
			if (g->GetMember(ctx,loResults.cv(),Ksuccess.cv(),t296.cv())) goto _0;
			Bool t297;
			if (!g->GetValue(ctx,(PCV[]){t297.cv(),t296.cv(),nullptr})) goto _0;
			if (!(t297.get())) goto _65;
		}
		{
			Variant t298;
			c.f.fLine=304;
			if (g->GetMember(ctx,loResults.cv(),KID.cv(),t298.cv())) goto _0;
			Long t299;
			if (!g->GetValue(ctx,(PCV[]){t299.cv(),t298.cv(),nullptr})) goto _0;
			lid=t299.get();
		}
		{
			Obj t300;
			c.f.fLine=305;
			if (g->Call(ctx,(PCV[]){t300.cv()},0,1466)) goto _0;
			Obj t301;
			if (g->Call(ctx,(PCV[]){t301.cv()},0,1482)) goto _0;
			Variant t302;
			if (g->Call(ctx,(PCV[]){t302.cv(),t301.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Obj t303;
			if (g->Call(ctx,(PCV[]){t303.cv()},0,1466)) goto _0;
			Variant t304;
			if (g->GetMember(ctx,t303.cv(),KtQueryTable.cv(),t304.cv())) goto _0;
			Variant t305;
			if (g->Call(ctx,(PCV[]){t305.cv(),t302.cv(),Kquery.cv(),kLceznZrfsTE.cv(),t304.cv(),lid.cv()},5,1498)) goto _0;
			if (g->SetMember(ctx,t300.cv(),KesSystems.cv(),t305.cv())) goto _0;
		}
		goto _66;
_65:
		{
			Obj t306;
			c.f.fLine=307;
			if (g->Call(ctx,(PCV[]){t306.cv()},0,1466)) goto _0;
			Obj t307;
			if (g->Call(ctx,(PCV[]){t307.cv()},0,1482)) goto _0;
			Variant t308;
			if (g->Call(ctx,(PCV[]){t308.cv(),t307.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t309;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_23_20_3A2.get(),t309.get());
			Obj t310;
			if (g->Call(ctx,(PCV[]){t310.cv()},0,1466)) goto _0;
			Variant t311;
			if (g->GetMember(ctx,t310.cv(),KtQueryTable.cv(),t311.cv())) goto _0;
			Variant t312;
			if (g->Call(ctx,(PCV[]){t312.cv(),t308.cv(),Kquery.cv(),t309.cv(),t311.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			if (g->SetMember(ctx,t306.cv(),KesSystems.cv(),t312.cv())) goto _0;
		}
_66:
		{
			Obj t313;
			c.f.fLine=310;
			if (g->Call(ctx,(PCV[]){t313.cv()},0,1466)) goto _0;
			Variant t314;
			if (g->GetMember(ctx,t313.cv(),KesSystems.cv(),t314.cv())) goto _0;
			Bool t315;
			if (g->OperationOnAny(ctx,7,t314.cv(),Value_null().cv(),t315.cv())) goto _0;
			if (!(t315.get())) goto _67;
		}
		{
			Obj t316;
			c.f.fLine=311;
			if (g->Call(ctx,(PCV[]){t316.cv()},0,1466)) goto _0;
			Variant t317;
			if (g->GetMember(ctx,t316.cv(),KesSystems.cv(),t317.cv())) goto _0;
			Variant t318;
			if (g->Call(ctx,(PCV[]){t318.cv(),t317.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t319;
			if (!g->GetValue(ctx,(PCV[]){t319.cv(),t318.cv(),nullptr})) goto _0;
			leSystemFirst=t319.get();
		}
		{
			Obj t320;
			c.f.fLine=312;
			if (g->Call(ctx,(PCV[]){t320.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t320.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		{
			Obj t321;
			c.f.fLine=313;
			if (g->Call(ctx,(PCV[]){t321.cv()},0,1466)) goto _0;
			Col t322;
			if (g->Call(ctx,(PCV[]){t322.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t321.cv(),KcolQryLines.cv(),t322.cv())) goto _0;
		}
		{
			Obj t323;
			c.f.fLine=315;
			if (g->Call(ctx,(PCV[]){t323.cv()},0,1466)) goto _0;
			Variant t324;
			if (g->GetMember(ctx,t323.cv(),KcolQryLines.cv(),t324.cv())) goto _0;
			Bool t325;
			if (g->OperationOnAny(ctx,6,t324.cv(),Value_null().cv(),t325.cv())) goto _0;
			if (!(t325.get())) goto _68;
		}
		liLines=0;
		ltObjectString=ku2OcsofPKtU.get();
		{
			Long t326;
			t326=38;
			Txt t327;
			t327=ltObjectString.get();
			Obj t328;
			c.f.fLine=323;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t327.cv(),t326.cv()},t328.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t329;
			if (g->GetMember(ctx,t328.cv(),KoObject.cv(),t329.cv())) goto _0;
			Variant t330;
			if (g->GetMember(ctx,t329.cv(),KqryLines.cv(),t330.cv())) goto _0;
			Variant t331;
			if (g->GetMember(ctx,t330.cv(),Long(0).cv(),t331.cv())) goto _0;
			Obj t332;
			if (!g->GetValue(ctx,(PCV[]){t332.cv(),t331.cv(),nullptr})) goto _0;
			loNewBlankQuery=t332.get();
		}
		{
			Obj t333;
			c.f.fLine=324;
			if (g->Call(ctx,(PCV[]){t333.cv()},0,1466)) goto _0;
			Col t334;
			if (g->Call(ctx,(PCV[]){t334.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t333.cv(),KcolQryLines.cv(),t334.cv())) goto _0;
		}
		{
			Obj t335;
			c.f.fLine=325;
			if (g->Call(ctx,(PCV[]){t335.cv()},0,1466)) goto _0;
			Variant t336;
			if (g->GetMember(ctx,t335.cv(),KcolQryLines.cv(),t336.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t336.cv(),Kpush.cv(),loNewBlankQuery.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_68:
		goto _69;
_67:
		{
			Obj t337;
			c.f.fLine=329;
			if (g->Call(ctx,(PCV[]){t337.cv()},0,1466)) goto _0;
			Variant t338;
			t338.setNull();
			if (g->SetMember(ctx,t337.cv(),KcolQryLines.cv(),t338.cv())) goto _0;
		}
_69:
		goto _6;
_63:
		{
			Variant t339;
			c.f.fLine=331;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t339.cv())) goto _0;
			Bool t340;
			if (g->OperationOnAny(ctx,6,t339.cv(),knB7uuVmo8Xo.cv(),t340.cv())) goto _0;
			if (!(t340.get())) goto _70;
		}
		{
			Obj t341;
			c.f.fLine=332;
			if (g->Call(ctx,(PCV[]){t341.cv()},0,1466)) goto _0;
			Variant t342;
			if (g->GetMember(ctx,t341.cv(),KiHdrLineIndx.cv(),t342.cv())) goto _0;
			Bool t343;
			if (g->OperationOnAny(ctx,6,t342.cv(),Num(0).cv(),t343.cv())) goto _0;
			if (!(t343.get())) goto _71;
		}
		c.f.fLine=333;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
		goto _72;
_71:
		{
			Obj t344;
			c.f.fLine=338;
			if (g->Call(ctx,(PCV[]){t344.cv()},0,1466)) goto _0;
			Variant t345;
			if (g->GetMember(ctx,t344.cv(),KesSystems.cv(),t345.cv())) goto _0;
			Obj t346;
			if (g->Call(ctx,(PCV[]){t346.cv()},0,1466)) goto _0;
			Variant t347;
			if (g->GetMember(ctx,t346.cv(),KiHdrLineIndx.cv(),t347.cv())) goto _0;
			Variant t348;
			if (g->OperationOnAny(ctx,1,t347.cv(),Num(1).cv(),t348.cv())) goto _0;
			Variant t349;
			if (g->GetMember(ctx,t345.cv(),t348.cv(),t349.cv())) goto _0;
			Variant t350;
			if (g->GetMember(ctx,t349.cv(),KID.cv(),t350.cv())) goto _0;
			Long t351;
			if (!g->GetValue(ctx,(PCV[]){t351.cv(),t350.cv(),nullptr})) goto _0;
			lid=t351.get();
		}
		{
			Obj t352;
			c.f.fLine=339;
			if (g->Call(ctx,(PCV[]){t352.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSysBook=t352.get();
		}
		{
			Obj t353;
			c.f.fLine=340;
			if (g->Call(ctx,(PCV[]){t353.cv()},0,1482)) goto _0;
			Variant t354;
			if (g->Call(ctx,(PCV[]){t354.cv(),t353.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t355;
			if (g->Call(ctx,(PCV[]){t355.cv(),t354.cv(),Kget.cv(),lid.cv()},3,1498)) goto _0;
			Obj t356;
			if (!g->GetValue(ctx,(PCV[]){t356.cv(),t355.cv(),nullptr})) goto _0;
			loSysBook=t356.get();
		}
		{
			Obj t357;
			t357=loSysBook.get();
			Obj t358;
			c.f.fLine=342;
			proc_SBK__ADDMODIFY(glob,ctx,1,1,(PCV[]){t357.cv()},t358.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loResults=t358.get();
		}
		{
			Variant t359;
			c.f.fLine=343;
			if (g->GetMember(ctx,loResults.cv(),Ksuccess.cv(),t359.cv())) goto _0;
			Bool t360;
			if (!g->GetValue(ctx,(PCV[]){t360.cv(),t359.cv(),nullptr})) goto _0;
			if (!(t360.get())) goto _73;
		}
		c.f.fLine=344;
		if (g->Call(ctx,(PCV[]){nullptr,kGpkCbRdAut0.cv()},1,41)) goto _0;
		g->Check(ctx);
_73:
		{
			Variant t361;
			c.f.fLine=349;
			if (g->GetMember(ctx,loResults.cv(),Ksuccess.cv(),t361.cv())) goto _0;
			Bool t362;
			if (!g->GetValue(ctx,(PCV[]){t362.cv(),t361.cv(),nullptr})) goto _0;
			if (!(t362.get())) goto _74;
		}
		{
			Variant t363;
			c.f.fLine=350;
			if (g->GetMember(ctx,loResults.cv(),KID.cv(),t363.cv())) goto _0;
			Long t364;
			if (!g->GetValue(ctx,(PCV[]){t364.cv(),t363.cv(),nullptr})) goto _0;
			lid=t364.get();
		}
		{
			Obj t365;
			c.f.fLine=351;
			if (g->Call(ctx,(PCV[]){t365.cv()},0,1466)) goto _0;
			Obj t366;
			if (g->Call(ctx,(PCV[]){t366.cv()},0,1482)) goto _0;
			Variant t367;
			if (g->Call(ctx,(PCV[]){t367.cv(),t366.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Obj t368;
			if (g->Call(ctx,(PCV[]){t368.cv()},0,1466)) goto _0;
			Variant t369;
			if (g->GetMember(ctx,t368.cv(),KtQueryTable.cv(),t369.cv())) goto _0;
			Variant t370;
			if (g->Call(ctx,(PCV[]){t370.cv(),t367.cv(),Kquery.cv(),kLceznZrfsTE.cv(),t369.cv(),lid.cv()},5,1498)) goto _0;
			if (g->SetMember(ctx,t365.cv(),KesSystems.cv(),t370.cv())) goto _0;
		}
		goto _75;
_74:
		{
			Obj t371;
			c.f.fLine=353;
			if (g->Call(ctx,(PCV[]){t371.cv()},0,1466)) goto _0;
			Obj t372;
			if (g->Call(ctx,(PCV[]){t372.cv()},0,1482)) goto _0;
			Variant t373;
			if (g->Call(ctx,(PCV[]){t373.cv(),t372.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t374;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_23_20_3A2.get(),t374.get());
			Obj t375;
			if (g->Call(ctx,(PCV[]){t375.cv()},0,1466)) goto _0;
			Variant t376;
			if (g->GetMember(ctx,t375.cv(),KtQueryTable.cv(),t376.cv())) goto _0;
			Variant t377;
			if (g->Call(ctx,(PCV[]){t377.cv(),t373.cv(),Kquery.cv(),t374.cv(),t376.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			if (g->SetMember(ctx,t371.cv(),KesSystems.cv(),t377.cv())) goto _0;
		}
_75:
		{
			Obj t378;
			c.f.fLine=356;
			if (g->Call(ctx,(PCV[]){t378.cv()},0,1466)) goto _0;
			Variant t379;
			if (g->GetMember(ctx,t378.cv(),KesSystems.cv(),t379.cv())) goto _0;
			Bool t380;
			if (g->OperationOnAny(ctx,7,t379.cv(),Value_null().cv(),t380.cv())) goto _0;
			if (!(t380.get())) goto _76;
		}
		{
			Obj t381;
			c.f.fLine=357;
			if (g->Call(ctx,(PCV[]){t381.cv()},0,1466)) goto _0;
			Variant t382;
			if (g->GetMember(ctx,t381.cv(),KesSystems.cv(),t382.cv())) goto _0;
			Variant t383;
			if (g->Call(ctx,(PCV[]){t383.cv(),t382.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t384;
			if (!g->GetValue(ctx,(PCV[]){t384.cv(),t383.cv(),nullptr})) goto _0;
			leSystemFirst=t384.get();
		}
		{
			Obj t385;
			c.f.fLine=358;
			if (g->Call(ctx,(PCV[]){t385.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t385.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		{
			Obj t386;
			c.f.fLine=359;
			if (g->Call(ctx,(PCV[]){t386.cv()},0,1466)) goto _0;
			Col t387;
			if (g->Call(ctx,(PCV[]){t387.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t386.cv(),KcolQryLines.cv(),t387.cv())) goto _0;
		}
		{
			Obj t388;
			c.f.fLine=360;
			if (g->Call(ctx,(PCV[]){t388.cv()},0,1466)) goto _0;
			Variant t389;
			if (g->GetMember(ctx,leSystemFirst.cv(),KQryLines.cv(),t389.cv())) goto _0;
			Long t390;
			t390=38;
			Txt t391;
			if (!g->GetValue(ctx,(PCV[]){t391.cv(),t389.cv(),nullptr})) goto _0;
			Obj t392;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t391.cv(),t390.cv()},t392.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t393;
			if (g->GetMember(ctx,t392.cv(),KoObject.cv(),t393.cv())) goto _0;
			Variant t394;
			if (g->GetMember(ctx,t393.cv(),KqryLines.cv(),t394.cv())) goto _0;
			if (g->SetMember(ctx,t388.cv(),KcolQryLines.cv(),t394.cv())) goto _0;
		}
		{
			Obj t395;
			c.f.fLine=362;
			if (g->Call(ctx,(PCV[]){t395.cv()},0,1466)) goto _0;
			Variant t396;
			if (g->GetMember(ctx,t395.cv(),KcolQryLines.cv(),t396.cv())) goto _0;
			Bool t397;
			if (g->OperationOnAny(ctx,6,t396.cv(),Value_null().cv(),t397.cv())) goto _0;
			if (!(t397.get())) goto _77;
		}
		liLines=0;
		ltObjectString=ku2OcsofPKtU.get();
		{
			Long t398;
			t398=38;
			Txt t399;
			t399=ltObjectString.get();
			Obj t400;
			c.f.fLine=370;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t399.cv(),t398.cv()},t400.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t401;
			if (g->GetMember(ctx,t400.cv(),KoObject.cv(),t401.cv())) goto _0;
			Variant t402;
			if (g->GetMember(ctx,t401.cv(),KqryLines.cv(),t402.cv())) goto _0;
			Variant t403;
			if (g->GetMember(ctx,t402.cv(),Long(0).cv(),t403.cv())) goto _0;
			Obj t404;
			if (!g->GetValue(ctx,(PCV[]){t404.cv(),t403.cv(),nullptr})) goto _0;
			loNewBlankQuery=t404.get();
		}
		{
			Obj t405;
			c.f.fLine=371;
			if (g->Call(ctx,(PCV[]){t405.cv()},0,1466)) goto _0;
			Col t406;
			if (g->Call(ctx,(PCV[]){t406.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t405.cv(),KcolQryLines.cv(),t406.cv())) goto _0;
		}
		{
			Obj t407;
			c.f.fLine=372;
			if (g->Call(ctx,(PCV[]){t407.cv()},0,1466)) goto _0;
			Variant t408;
			if (g->GetMember(ctx,t407.cv(),KcolQryLines.cv(),t408.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t408.cv(),Kpush.cv(),loNewBlankQuery.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_77:
		goto _78;
_76:
		{
			Obj t409;
			c.f.fLine=376;
			if (g->Call(ctx,(PCV[]){t409.cv()},0,1466)) goto _0;
			Variant t410;
			t410.setNull();
			if (g->SetMember(ctx,t409.cv(),KcolQryLines.cv(),t410.cv())) goto _0;
		}
_78:
_72:
		goto _6;
_70:
		{
			Variant t411;
			c.f.fLine=379;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t411.cv())) goto _0;
			Bool t412;
			if (g->OperationOnAny(ctx,6,t411.cv(),kBsrRGl7CXWk.cv(),t412.cv())) goto _0;
			if (!(t412.get())) goto _79;
		}
		{
			Obj t413;
			c.f.fLine=380;
			if (g->Call(ctx,(PCV[]){t413.cv()},0,1466)) goto _0;
			Variant t414;
			if (g->GetMember(ctx,t413.cv(),KiHdrLineIndx.cv(),t414.cv())) goto _0;
			Bool t415;
			if (g->OperationOnAny(ctx,6,t414.cv(),Num(0).cv(),t415.cv())) goto _0;
			if (!(t415.get())) goto _80;
		}
		c.f.fLine=381;
		if (g->Call(ctx,(PCV[]){nullptr,kRxZpk1vyTOQ.cv()},1,41)) goto _0;
		g->Check(ctx);
		goto _81;
_80:
		{
			Obj t416;
			c.f.fLine=385;
			if (g->Call(ctx,(PCV[]){t416.cv()},0,1482)) goto _0;
			Variant t417;
			if (g->Call(ctx,(PCV[]){t417.cv(),t416.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Obj t418;
			if (g->Call(ctx,(PCV[]){t418.cv()},0,1466)) goto _0;
			Variant t419;
			if (g->GetMember(ctx,t418.cv(),KesSystems.cv(),t419.cv())) goto _0;
			Obj t420;
			if (g->Call(ctx,(PCV[]){t420.cv()},0,1466)) goto _0;
			Variant t421;
			if (g->GetMember(ctx,t420.cv(),KiHdrLineIndx.cv(),t421.cv())) goto _0;
			Variant t422;
			if (g->OperationOnAny(ctx,1,t421.cv(),Num(1).cv(),t422.cv())) goto _0;
			Variant t423;
			if (g->GetMember(ctx,t419.cv(),t422.cv(),t423.cv())) goto _0;
			Variant t424;
			if (g->GetMember(ctx,t423.cv(),KID.cv(),t424.cv())) goto _0;
			Variant t425;
			if (g->Call(ctx,(PCV[]){t425.cv(),t417.cv(),Kget.cv(),t424.cv()},3,1498)) goto _0;
			Obj t426;
			if (!g->GetValue(ctx,(PCV[]){t426.cv(),t425.cv(),nullptr})) goto _0;
			lesDBQueries=t426.get();
		}
		{
			Bool t427;
			t427=!lesDBQueries.isNull();
			if (!(t427.get())) goto _82;
		}
		{
			Variant t428;
			c.f.fLine=387;
			if (g->GetMember(ctx,lesDBQueries.cv(),KQueryName.cv(),t428.cv())) goto _0;
			Variant t429;
			if (g->OperationOnAny(ctx,0,kjUh3rfCnjoI.cv(),t428.cv(),t429.cv())) goto _0;
			Variant t430;
			if (g->OperationOnAny(ctx,0,t429.cv(),K_20system_2E_2E_3F.cv(),t430.cv())) goto _0;
			Txt t431;
			if (!g->GetValue(ctx,(PCV[]){t431.cv(),t430.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t431.cv()},1,162)) goto _0;
			g->Check(ctx);
		}
		if (1!=Var<Long>(ctx,vOK).get()) goto _83;
		c.f.fLine=389;
		if (g->Call(ctx,(PCV[]){nullptr,lesDBQueries.cv(),Kdrop.cv()},2,1500)) goto _0;
		g->Check(ctx);
		c.f.fLine=390;
		if (g->Call(ctx,(PCV[]){nullptr,kYK1g15csO4w.cv()},1,41)) goto _0;
		g->Check(ctx);
_83:
		goto _84;
_82:
		c.f.fLine=393;
		if (g->Call(ctx,(PCV[]){nullptr,ksjVmVct_m1g.cv()},1,41)) goto _0;
		g->Check(ctx);
_84:
		{
			Obj t433;
			c.f.fLine=398;
			if (g->Call(ctx,(PCV[]){t433.cv()},0,1466)) goto _0;
			Obj t434;
			if (g->Call(ctx,(PCV[]){t434.cv()},0,1482)) goto _0;
			Variant t435;
			if (g->Call(ctx,(PCV[]){t435.cv(),t434.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t436;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_23_20_3A2.get(),t436.get());
			Obj t437;
			if (g->Call(ctx,(PCV[]){t437.cv()},0,1466)) goto _0;
			Variant t438;
			if (g->GetMember(ctx,t437.cv(),kkhHWtXAdhMw.cv(),t438.cv())) goto _0;
			Variant t439;
			if (g->Call(ctx,(PCV[]){t439.cv(),t435.cv(),Kquery.cv(),t436.cv(),t438.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			if (g->SetMember(ctx,t433.cv(),KesSystems.cv(),t439.cv())) goto _0;
		}
		{
			Obj t440;
			c.f.fLine=400;
			if (g->Call(ctx,(PCV[]){t440.cv()},0,1466)) goto _0;
			Variant t441;
			if (g->GetMember(ctx,t440.cv(),KesSystems.cv(),t441.cv())) goto _0;
			Bool t442;
			if (g->OperationOnAny(ctx,7,t441.cv(),Value_null().cv(),t442.cv())) goto _0;
			if (!(t442.get())) goto _85;
		}
		{
			Obj t443;
			c.f.fLine=401;
			if (g->Call(ctx,(PCV[]){t443.cv()},0,1466)) goto _0;
			Variant t444;
			if (g->GetMember(ctx,t443.cv(),KesSystems.cv(),t444.cv())) goto _0;
			Variant t445;
			if (g->Call(ctx,(PCV[]){t445.cv(),t444.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t446;
			if (!g->GetValue(ctx,(PCV[]){t446.cv(),t445.cv(),nullptr})) goto _0;
			leSystemFirst=t446.get();
		}
		{
			Obj t447;
			c.f.fLine=402;
			if (g->Call(ctx,(PCV[]){t447.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t447.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		{
			Obj t448;
			c.f.fLine=403;
			if (g->Call(ctx,(PCV[]){t448.cv()},0,1466)) goto _0;
			Variant t449;
			if (g->GetMember(ctx,leSystemFirst.cv(),KQryLines.cv(),t449.cv())) goto _0;
			Long t450;
			t450=38;
			Txt t451;
			if (!g->GetValue(ctx,(PCV[]){t451.cv(),t449.cv(),nullptr})) goto _0;
			Obj t452;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t451.cv(),t450.cv()},t452.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t453;
			if (g->GetMember(ctx,t452.cv(),KoObject.cv(),t453.cv())) goto _0;
			Variant t454;
			if (g->GetMember(ctx,t453.cv(),KqryLines.cv(),t454.cv())) goto _0;
			if (g->SetMember(ctx,t448.cv(),KcolQryLines.cv(),t454.cv())) goto _0;
		}
		goto _86;
_85:
		{
			Obj t455;
			c.f.fLine=405;
			if (g->Call(ctx,(PCV[]){t455.cv()},0,1466)) goto _0;
			Variant t456;
			t456.setNull();
			if (g->SetMember(ctx,t455.cv(),KcolQryLines.cv(),t456.cv())) goto _0;
		}
_86:
_81:
		goto _6;
_79:
		{
			Variant t457;
			c.f.fLine=409;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t457.cv())) goto _0;
			Bool t458;
			if (g->OperationOnAny(ctx,6,t457.cv(),kJpMovZgJmOE.cv(),t458.cv())) goto _0;
			if (!(t458.get())) goto _87;
		}
		{
			Obj t459;
			c.f.fLine=411;
			if (g->Call(ctx,(PCV[]){t459.cv()},0,1482)) goto _0;
			Variant t460;
			if (g->Call(ctx,(PCV[]){t460.cv(),t459.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t461;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_23_20_3A2.get(),t461.get());
			Obj t462;
			if (g->Call(ctx,(PCV[]){t462.cv()},0,1466)) goto _0;
			Variant t463;
			if (g->GetMember(ctx,t462.cv(),KtQueryTable.cv(),t463.cv())) goto _0;
			Variant t464;
			if (g->Call(ctx,(PCV[]){t464.cv(),t460.cv(),Kquery.cv(),t461.cv(),t463.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			Obj t465;
			if (!g->GetValue(ctx,(PCV[]){t465.cv(),t464.cv(),nullptr})) goto _0;
			lesSystems=t465.get();
		}
		{
			Bool t466;
			t466=!lesSystems.isNull();
			if (!(t466.get())) goto _88;
		}
		{
			Obj t467;
			c.f.fLine=413;
			if (g->Call(ctx,(PCV[]){t467.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t467.cv(),KesSystems.cv(),lesSystems.cv())) goto _0;
		}
		{
			Obj t468;
			c.f.fLine=415;
			if (g->Call(ctx,(PCV[]){t468.cv()},0,1466)) goto _0;
			Variant t469;
			if (g->GetMember(ctx,t468.cv(),KesSystems.cv(),t469.cv())) goto _0;
			Variant t470;
			if (g->Call(ctx,(PCV[]){t470.cv(),t469.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t471;
			if (!g->GetValue(ctx,(PCV[]){t471.cv(),t470.cv(),nullptr})) goto _0;
			leSystemFirst=t471.get();
		}
		{
			Obj t472;
			c.f.fLine=416;
			if (g->Call(ctx,(PCV[]){t472.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t472.cv(),KiHdrLineIndx.cv(),Long(1).cv())) goto _0;
		}
		{
			Obj t473;
			c.f.fLine=417;
			if (g->Call(ctx,(PCV[]){t473.cv()},0,1466)) goto _0;
			Col t474;
			if (g->Call(ctx,(PCV[]){t474.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t473.cv(),KcolQryLines.cv(),t474.cv())) goto _0;
		}
		{
			Obj t475;
			c.f.fLine=418;
			if (g->Call(ctx,(PCV[]){t475.cv()},0,1466)) goto _0;
			Variant t476;
			if (g->GetMember(ctx,leSystemFirst.cv(),KQryLines.cv(),t476.cv())) goto _0;
			Long t477;
			t477=38;
			Txt t478;
			if (!g->GetValue(ctx,(PCV[]){t478.cv(),t476.cv(),nullptr})) goto _0;
			Obj t479;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t478.cv(),t477.cv()},t479.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t480;
			if (g->GetMember(ctx,t479.cv(),KoObject.cv(),t480.cv())) goto _0;
			Variant t481;
			if (g->GetMember(ctx,t480.cv(),KqryLines.cv(),t481.cv())) goto _0;
			if (g->SetMember(ctx,t475.cv(),KcolQryLines.cv(),t481.cv())) goto _0;
		}
		{
			Obj t482;
			c.f.fLine=420;
			if (g->Call(ctx,(PCV[]){t482.cv()},0,1466)) goto _0;
			Variant t483;
			if (g->GetMember(ctx,t482.cv(),KcolQryLines.cv(),t483.cv())) goto _0;
			Bool t484;
			if (g->OperationOnAny(ctx,6,t483.cv(),Value_null().cv(),t484.cv())) goto _0;
			if (!(t484.get())) goto _89;
		}
		liLines=0;
		ltObjectString=ku2OcsofPKtU.get();
		{
			Long t485;
			t485=38;
			Txt t486;
			t486=ltObjectString.get();
			Obj t487;
			c.f.fLine=428;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t486.cv(),t485.cv()},t487.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t488;
			if (g->GetMember(ctx,t487.cv(),KoObject.cv(),t488.cv())) goto _0;
			Variant t489;
			if (g->GetMember(ctx,t488.cv(),KqryLines.cv(),t489.cv())) goto _0;
			Variant t490;
			if (g->GetMember(ctx,t489.cv(),Long(0).cv(),t490.cv())) goto _0;
			Obj t491;
			if (!g->GetValue(ctx,(PCV[]){t491.cv(),t490.cv(),nullptr})) goto _0;
			loNewBlankQuery=t491.get();
		}
		{
			Obj t492;
			c.f.fLine=429;
			if (g->Call(ctx,(PCV[]){t492.cv()},0,1466)) goto _0;
			Col t493;
			if (g->Call(ctx,(PCV[]){t493.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t492.cv(),KcolQryLines.cv(),t493.cv())) goto _0;
		}
		{
			Obj t494;
			c.f.fLine=430;
			if (g->Call(ctx,(PCV[]){t494.cv()},0,1466)) goto _0;
			Variant t495;
			if (g->GetMember(ctx,t494.cv(),KcolQryLines.cv(),t495.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t495.cv(),Kpush.cv(),loNewBlankQuery.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_89:
		goto _90;
_88:
		{
			Obj t496;
			c.f.fLine=434;
			if (g->Call(ctx,(PCV[]){t496.cv()},0,1466)) goto _0;
			Variant t497;
			t497.setNull();
			if (g->SetMember(ctx,t496.cv(),KcolQryLines.cv(),t497.cv())) goto _0;
		}
		c.f.fLine=435;
		if (g->Call(ctx,(PCV[]){nullptr,kkFuTiDDdsWI.cv()},1,41)) goto _0;
		g->Check(ctx);
_90:
		goto _6;
_87:
_6:
_5:
_0:
_1:
;
	}

}
