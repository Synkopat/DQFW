extern int32_t vDOCUMENT;
extern int32_t vOK;
extern int32_t vUSR__GetCurrent;
extern Txt K;
extern Txt K300_2C300;
extern Txt K300_2C300_2C300;
extern Txt KADVANCED;
extern Txt KAND;
extern Txt KAdv;
extern Txt KBASIC;
extern Txt KBASIC__SHORTCUTS;
extern Txt KBaseEntity;
extern Txt KBaseEntity_20_3D_20_3A1;
extern Txt KBasic;
extern Txt KBttnSaveSystem;
extern Txt KCategory;
extern Txt KCreatedBy;
extern Txt KDBQueries;
extern Txt KDisplayQryText;
extern Txt KGroup;
extern Txt KIsActive;
extern Txt KQryLines;
extern Txt KQryParams;
extern Txt KQryText;
extern Txt KRole_2CLines;
extern Txt KSelect_20a_20Role;
extern Txt KSingle;
extern Txt KUI__SEARCH;
extern Txt KUSER;
extern Txt K_20AND_20Group_20_23_20_3A2;
extern Txt K_20AND_20Group_20_3D_20_3A2;
extern Txt Kattributes;
extern Txt KbEnableGrouping;
extern Txt KbFullAccess;
extern Txt KbIsAdminUser;
extern Txt KbSuccess;
extern Txt KbUpdateCache;
extern Txt KbttnCancel;
extern Txt KbttnExport;
extern Txt KbttnHideAdv;
extern Txt KbttnImport;
extern Txt KbttnLoadSystem_40;
extern Txt KbttnRecent_40;
extern Txt KbttnRun_40;
extern Txt KbttnShortcut_40;
extern Txt KbttnShowAdv;
extern Txt Kcode;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt KcolQryLines;
extern Txt Kcopy;
extern Txt KgetText;
extern Txt KiQryLineIndx;
extern Txt KindexOf;
extern Txt Kinsert;
extern Txt Kjsn;
extern Txt KlbQryLines;
extern Txt KlbQryLines_40;
extern Txt Klength;
extern Txt KlogicOP;
extern Txt KoNewQryLine;
extern Txt KoObject;
extern Txt KobjectName;
extern Txt KplatformPath;
extern Txt Kpush;
extern Txt KqryLines;
extern Txt KqryText;
extern Txt Kquery;
extern Txt KrbAdd2Selection;
extern Txt KrbQrySelection;
extern Txt Kremove;
extern Txt KsetText;
extern Txt KtAlias;
extern Txt KtCurPage;
extern Txt KtFormHeader;
extern Txt KtLogic;
extern Txt KtQueryTable;
extern Txt KtSelectionMode;
extern Txt KtShorcutsType;
extern Txt KtoCollection;
extern Txt k0hyJBtb3YKs;
extern Txt k5eF30BpGehY;
extern Txt k5hs0QWHiwao;
extern Txt k7nPzzMJ4l8k;
extern Txt k9HkhWTimNqc;
extern Txt kFEAgzPXQQ1U;
extern Txt kGpkCbRdAut0;
extern Txt kHWbpQfb3ej0;
extern Txt kI9o4oFrPi2g;
extern Txt kIbq0A3jgcHQ;
extern Txt kM44XBFxGaXg;
extern Txt kSw3pZ8WhbHE;
extern Txt kVfh0oqO1WwE;
extern Txt kVn4UTeilKOI;
extern Txt kW4zrIKzg05Q;
extern Txt kYhLxOkZaZqg;
extern Txt kdhneN13oy0I;
extern Txt kmLbBRNjeatk;
extern Txt kpBUF4YZPrek;
extern Txt ksqpcsLWR6go;
extern Txt ksv03rMKIa68;
Asm4d_Proc proc_CACHE__UPDATE;
Asm4d_Proc proc_DQFW__GETQRYNAME;
Asm4d_Proc proc_DQFW__PARSEQUERY;
Asm4d_Proc proc_DQFW__QUERYFORMLBXHNDL;
Asm4d_Proc proc_DQFW__QUERYFORMSELECTRECENT;
Asm4d_Proc proc_DQFW__STRINGIFY;
Asm4d_Proc proc_SBK__EDIT;
Asm4d_Proc proc_UTIL__PARSEJSONSTR;
Asm4d_Proc proc_WDGT__CONFIGCOLUMNS;
Asm4d_Proc proc_WDGT__SELECT;
extern unsigned char D_proc_DQFW__QUERYFORMOBJECTHNDL[];
void proc_DQFW__QUERYFORMOBJECTHNDL( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__QUERYFORMOBJECTHNDL);
	if (!ctx->doingAbort) {
		Bool lbSuccess;
		Txt ltCategory;
		Obj loQry;
		Obj lesSystems;
		Obj loExportFile;
		Obj loItem;
		Txt ltHeaders;
		Obj lesTableSelection;
		Long liLines;
		Txt ltGroup;
		Obj leSystem;
		Obj ltoFormEvent;
		Obj loFormEvent;
		Obj loImportFile;
		Time lhDoc;
		Col lcolUserSelection;
		Obj loSystem;
		Obj loSysBook;
		Bool lJCPEREZ__20241102;
		Txt ltHiddenCols;
		Obj loSysRegKey;
		Obj loListItems;
		Txt ltScreenType;
		Txt ltQueryLines;
		Txt ltHdrMap;
		Txt ltRecentQry;
		Obj loResult;
		Txt ltWidths;
		c.f.fLine=12;
		loFormEvent=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=14;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t0.cv())) goto _0;
			Bool t1;
			if (g->OperationOnAny(ctx,6,t0.cv(),Value_null().cv(),t1.cv())) goto _0;
			if (!(t1.get())) goto _2;
		}
		{
			Variant t2;
			c.f.fLine=18;
			if (g->GetMember(ctx,loFormEvent.cv(),Kcode.cv(),t2.cv())) goto _0;
			Bool t3;
			if (g->OperationOnAny(ctx,6,t2.cv(),Long(1).cv(),t3.cv())) goto _0;
			if (!(t3.get())) goto _4;
		}
		{
			Obj t4;
			c.f.fLine=19;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1466)) goto _0;
			Variant t5;
			if (g->GetMember(ctx,t4.cv(),kpBUF4YZPrek.cv(),t5.cv())) goto _0;
			Bool t6;
			if (!g->GetValue(ctx,(PCV[]){t6.cv(),t5.cv(),nullptr})) goto _0;
			if (!(t6.get())) goto _5;
		}
		{
			Bool t7;
			t7=Bool(1).get();
			c.f.fLine=20;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KrbAdd2Selection.cv(),t7.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		{
			Bool t8;
			t8=Bool(1).get();
			c.f.fLine=21;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KrbQrySelection.cv(),t8.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		goto _6;
_5:
		{
			Bool t9;
			t9=Bool(0).get();
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KrbAdd2Selection.cv(),t9.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
		{
			Bool t10;
			t10=Bool(0).get();
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),KrbQrySelection.cv(),t10.cv()},3,1123)) goto _0;
			g->Check(ctx);
		}
_6:
		{
			Obj t11;
			c.f.fLine=28;
			if (g->Call(ctx,(PCV[]){t11.cv()},0,1466)) goto _0;
			Variant t12;
			if (g->GetMember(ctx,t11.cv(),kVfh0oqO1WwE.cv(),t12.cv())) goto _0;
			Bool t13;
			if (g->OperationOnAny(ctx,6,t12.cv(),KADVANCED.cv(),t13.cv())) goto _0;
			if (!(t13.get())) goto _7;
		}
		{
			Obj t14;
			c.f.fLine=29;
			if (g->Call(ctx,(PCV[]){t14.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t14.cv(),KtCurPage.cv(),KAdv.cv())) goto _0;
		}
		{
			Obj t15;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t15.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t15.cv(),KtShorcutsType.cv(),k5eF30BpGehY.cv())) goto _0;
		}
		c.f.fLine=31;
		if (g->Call(ctx,(PCV[]){nullptr,Long(1).cv()},1,247)) goto _0;
		g->Check(ctx);
		goto _8;
_7:
		{
			Obj t16;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t16.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t16.cv(),KtCurPage.cv(),KBasic.cv())) goto _0;
		}
		{
			Obj t17;
			c.f.fLine=35;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t17.cv(),KtShorcutsType.cv(),KBASIC__SHORTCUTS.cv())) goto _0;
		}
		c.f.fLine=36;
		if (g->Call(ctx,(PCV[]){nullptr,Long(2).cv()},1,247)) goto _0;
		g->Check(ctx);
_8:
		goto _3;
_4:
_3:
		goto _9;
_2:
		{
			Variant t18;
			c.f.fLine=44;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t18.cv())) goto _0;
			Bool t19;
			if (g->OperationOnAny(ctx,6,t18.cv(),KbttnHideAdv.cv(),t19.cv())) goto _0;
			if (!(t19.get())) goto _11;
		}
		{
			Obj t20;
			c.f.fLine=45;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t20.cv(),KtCurPage.cv(),KBasic.cv())) goto _0;
		}
		{
			Obj t21;
			c.f.fLine=46;
			if (g->Call(ctx,(PCV[]){t21.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t21.cv(),KtShorcutsType.cv(),KBASIC__SHORTCUTS.cv())) goto _0;
		}
		c.f.fLine=47;
		if (g->Call(ctx,(PCV[]){nullptr,Long(2).cv()},1,247)) goto _0;
		g->Check(ctx);
		goto _10;
_11:
		{
			Variant t22;
			c.f.fLine=49;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t22.cv())) goto _0;
			Bool t23;
			if (g->OperationOnAny(ctx,6,t22.cv(),KbttnShowAdv.cv(),t23.cv())) goto _0;
			if (!(t23.get())) goto _12;
		}
		{
			Obj t24;
			c.f.fLine=50;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t24.cv(),KtCurPage.cv(),KAdv.cv())) goto _0;
		}
		{
			Obj t25;
			c.f.fLine=51;
			if (g->Call(ctx,(PCV[]){t25.cv()},0,1466)) goto _0;
			if (g->SetMember(ctx,t25.cv(),KtShorcutsType.cv(),k5eF30BpGehY.cv())) goto _0;
		}
		c.f.fLine=52;
		if (g->Call(ctx,(PCV[]){nullptr,Long(1).cv()},1,247)) goto _0;
		g->Check(ctx);
		goto _10;
_12:
		{
			Variant t26;
			c.f.fLine=54;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t26.cv())) goto _0;
			Bool t27;
			if (g->OperationOnAny(ctx,6,t26.cv(),KlbQryLines_40.cv(),t27.cv())) goto _0;
			if (!(t27.get())) goto _13;
		}
		{
			Obj t28;
			t28=loFormEvent.get();
			c.f.fLine=55;
			proc_DQFW__QUERYFORMLBXHNDL(glob,ctx,1,1,(PCV[]){t28.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		goto _10;
_13:
		{
			Variant t29;
			c.f.fLine=57;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t29.cv())) goto _0;
			Bool t30;
			if (g->OperationOnAny(ctx,6,t29.cv(),KbttnShortcut_40.cv(),t30.cv())) goto _0;
			if (!(t30.get())) goto _14;
		}
		ltGroup=KUI__SEARCH.get();
		{
			Obj t31;
			c.f.fLine=63;
			if (g->Call(ctx,(PCV[]){t31.cv()},0,1466)) goto _0;
			Variant t32;
			if (g->GetMember(ctx,t31.cv(),KtShorcutsType.cv(),t32.cv())) goto _0;
			Txt t33;
			if (!g->GetValue(ctx,(PCV[]){t33.cv(),t32.cv(),nullptr})) goto _0;
			ltCategory=t33.get();
		}
		ltHdrMap=kW4zrIKzg05Q.get();
		ltHeaders=KRole_2CLines.get();
		ltWidths=K300_2C300.get();
		ltHiddenCols=KQryLines.get();
		{
			Obj t34;
			c.f.fLine=69;
			if (g->Call(ctx,(PCV[]){t34.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t34.get();
		}
		{
			Txt t35;
			t35=ltHiddenCols.get();
			Txt t36;
			t36=ltWidths.get();
			Txt t37;
			t37=ltHdrMap.get();
			Txt t38;
			t38=ltHeaders.get();
			Col t39;
			c.f.fLine=70;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t38.cv(),t37.cv(),t36.cv(),t35.cv()},t39.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t39.cv())) goto _0;
		}
		c.f.fLine=71;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),KSelect_20a_20Role.cv())) goto _0;
		c.f.fLine=72;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t40;
			c.f.fLine=73;
			if (g->Call(ctx,(PCV[]){t40.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t40.cv())) goto _0;
		}
		{
			Obj t41;
			c.f.fLine=75;
			if (g->Call(ctx,(PCV[]){t41.cv()},0,1482)) goto _0;
			Variant t42;
			if (g->Call(ctx,(PCV[]){t42.cv(),t41.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t43;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_3D_20_3A2.get(),t43.get());
			Txt t44;
			g->AddString(t43.get(),kmLbBRNjeatk.get(),t44.get());
			Obj t45;
			if (g->Call(ctx,(PCV[]){t45.cv()},0,1466)) goto _0;
			Variant t46;
			if (g->GetMember(ctx,t45.cv(),KtQueryTable.cv(),t46.cv())) goto _0;
			Variant t47;
			if (g->Call(ctx,(PCV[]){t47.cv(),t42.cv(),Kquery.cv(),t44.cv(),t46.cv(),ltGroup.cv(),ltCategory.cv()},6,1498)) goto _0;
			Obj t48;
			if (!g->GetValue(ctx,(PCV[]){t48.cv(),t47.cv(),nullptr})) goto _0;
			lesSystems=t48.get();
		}
		{
			Bool t49;
			t49=!lesSystems.isNull();
			if (!(t49.get())) goto _15;
		}
		{
			Variant t50;
			c.f.fLine=78;
			if (g->Call(ctx,(PCV[]){t50.cv(),lesSystems.cv(),KtoCollection.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t50.cv())) goto _0;
		}
_15:
		{
			Obj t51;
			t51=loListItems.get();
			Col t52;
			c.f.fLine=81;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t51.cv()},t52.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t52.get();
		}
		{
			Variant t53;
			c.f.fLine=83;
			if (g->Call(ctx,(PCV[]){t53.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t54;
			if (g->OperationOnAny(ctx,6,t53.cv(),Num(1).cv(),t54.cv())) goto _0;
			if (!(t54.get())) goto _16;
		}
		{
			Variant t55;
			c.f.fLine=84;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t55.cv())) goto _0;
			Variant t56;
			if (g->GetMember(ctx,t55.cv(),KQryLines.cv(),t56.cv())) goto _0;
			Long t57;
			t57=38;
			Txt t58;
			if (!g->GetValue(ctx,(PCV[]){t58.cv(),t56.cv(),nullptr})) goto _0;
			Obj t59;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t58.cv(),t57.cv()},t59.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t60;
			if (g->GetMember(ctx,t59.cv(),KoObject.cv(),t60.cv())) goto _0;
			Obj t61;
			if (!g->GetValue(ctx,(PCV[]){t61.cv(),t60.cv(),nullptr})) goto _0;
			loQry=t61.get();
		}
		{
			Bool t62;
			t62=!loQry.isNull();
			if (!(t62.get())) goto _17;
		}
		{
			Obj t63;
			c.f.fLine=87;
			if (g->Call(ctx,(PCV[]){t63.cv()},0,1466)) goto _0;
			Variant t64;
			if (g->GetMember(ctx,t63.cv(),KcolQryLines.cv(),t64.cv())) goto _0;
			Variant t65;
			if (g->GetMember(ctx,t64.cv(),Klength.cv(),t65.cv())) goto _0;
			Bool t66;
			if (g->OperationOnAny(ctx,5,t65.cv(),Num(0).cv(),t66.cv())) goto _0;
			if (!(t66.get())) goto _18;
		}
		{
			Variant t67;
			c.f.fLine=88;
			if (g->GetMember(ctx,loQry.cv(),KqryLines.cv(),t67.cv())) goto _0;
			Variant t68;
			if (g->GetMember(ctx,t67.cv(),Long(0).cv(),t68.cv())) goto _0;
			if (g->SetMember(ctx,t68.cv(),KlogicOP.cv(),KAND.cv())) goto _0;
		}
		{
			Variant t69;
			c.f.fLine=89;
			if (g->GetMember(ctx,loQry.cv(),KqryLines.cv(),t69.cv())) goto _0;
			Variant t70;
			if (g->GetMember(ctx,t69.cv(),Long(0).cv(),t70.cv())) goto _0;
			if (g->SetMember(ctx,t70.cv(),KtLogic.cv(),KAND.cv())) goto _0;
		}
_18:
		{
			Obj t71;
			c.f.fLine=92;
			if (g->Call(ctx,(PCV[]){t71.cv()},0,1466)) goto _0;
			Variant t72;
			if (g->GetMember(ctx,loQry.cv(),KqryLines.cv(),t72.cv())) goto _0;
			Variant t73;
			if (g->Call(ctx,(PCV[]){t73.cv(),t72.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t71.cv(),KcolQryLines.cv(),t73.cv())) goto _0;
		}
		{
			Obj t74;
			c.f.fLine=93;
			if (g->Call(ctx,(PCV[]){t74.cv()},0,1466)) goto _0;
			Variant t75;
			if (g->GetMember(ctx,t74.cv(),KtCurPage.cv(),t75.cv())) goto _0;
			Variant t76;
			if (g->OperationOnAny(ctx,0,KlbQryLines.cv(),t75.cv(),t76.cv())) goto _0;
			Txt t77;
			if (!g->GetValue(ctx,(PCV[]){t77.cv(),t76.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t77.cv()},2,206)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t78;
			c.f.fLine=94;
			if (g->Call(ctx,(PCV[]){t78.cv()},0,1466)) goto _0;
			Variant t79;
			if (g->GetMember(ctx,t78.cv(),KtCurPage.cv(),t79.cv())) goto _0;
			Variant t80;
			if (g->OperationOnAny(ctx,0,KtAlias.cv(),t79.cv(),t80.cv())) goto _0;
			Obj t81;
			if (g->Call(ctx,(PCV[]){t81.cv()},0,1466)) goto _0;
			Variant t82;
			if (g->GetMember(ctx,t81.cv(),KcolQryLines.cv(),t82.cv())) goto _0;
			Variant t83;
			if (g->GetMember(ctx,t82.cv(),Klength.cv(),t83.cv())) goto _0;
			Txt t84;
			if (!g->GetValue(ctx,(PCV[]){t84.cv(),t80.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t84.cv(),t83.cv()},3,870)) goto _0;
			g->Check(ctx);
		}
		goto _19;
_17:
		c.f.fLine=97;
		if (g->Call(ctx,(PCV[]){nullptr,kYhLxOkZaZqg.cv()},1,41)) goto _0;
		g->Check(ctx);
_19:
_16:
		goto _10;
_14:
		{
			Variant t85;
			c.f.fLine=103;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t85.cv())) goto _0;
			Bool t86;
			if (g->OperationOnAny(ctx,6,t85.cv(),kM44XBFxGaXg.cv(),t86.cv())) goto _0;
			if (!(t86.get())) goto _20;
		}
		{
			Obj t87;
			c.f.fLine=106;
			if (g->Call(ctx,(PCV[]){t87.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSysBook=t87.get();
		}
		{
			Obj t88;
			c.f.fLine=107;
			if (g->Call(ctx,(PCV[]){t88.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loQry=t88.get();
		}
		{
			Obj t89;
			c.f.fLine=108;
			if (g->Call(ctx,(PCV[]){t89.cv()},0,1466)) goto _0;
			Variant t90;
			if (g->GetMember(ctx,t89.cv(),KtQueryTable.cv(),t90.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KBaseEntity.cv(),t90.cv())) goto _0;
		}
		c.f.fLine=109;
		if (g->SetMember(ctx,loSysBook.cv(),KGroup.cv(),KUI__SEARCH.cv())) goto _0;
		{
			Obj t91;
			c.f.fLine=110;
			if (g->Call(ctx,(PCV[]){t91.cv()},0,1466)) goto _0;
			Variant t92;
			if (g->GetMember(ctx,t91.cv(),KtShorcutsType.cv(),t92.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KCategory.cv(),t92.cv())) goto _0;
		}
		{
			Obj t93;
			c.f.fLine=111;
			if (g->Call(ctx,(PCV[]){t93.cv()},0,1466)) goto _0;
			Variant t94;
			if (g->GetMember(ctx,t93.cv(),KbIsAdminUser.cv(),t94.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KbEnableGrouping.cv(),t94.cv())) goto _0;
		}
		{
			Obj t95;
			c.f.fLine=112;
			if (g->Call(ctx,(PCV[]){t95.cv()},0,1466)) goto _0;
			Variant t96;
			if (g->GetMember(ctx,t95.cv(),KbIsAdminUser.cv(),t96.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KbFullAccess.cv(),t96.cv())) goto _0;
		}
		{
			Obj t97;
			c.f.fLine=113;
			if (g->Call(ctx,(PCV[]){t97.cv()},0,1466)) goto _0;
			Variant t98;
			if (g->GetMember(ctx,t97.cv(),KcolQryLines.cv(),t98.cv())) goto _0;
			Obj t99;
			if (g->Call(ctx,(PCV[]){t99.cv(),KqryLines.cv(),t98.cv()},2,1471)) goto _0;
			g->Check(ctx);
			Txt t100;
			if (g->Call(ctx,(PCV[]){t100.cv(),t99.cv()},1,1217)) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KQryLines.cv(),t100.cv())) goto _0;
		}
		{
			Obj t101;
			c.f.fLine=114;
			if (g->Call(ctx,(PCV[]){t101.cv()},0,1466)) goto _0;
			Variant t102;
			if (g->GetMember(ctx,t101.cv(),KcolQryLines.cv(),t102.cv())) goto _0;
			Col t103;
			if (!g->GetValue(ctx,(PCV[]){t103.cv(),t102.cv(),nullptr})) goto _0;
			Txt t104;
			proc_DQFW__GETQRYNAME(glob,ctx,1,1,(PCV[]){t103.cv()},t104.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KDisplayQryText.cv(),t104.cv())) goto _0;
		}
		{
			Obj t105;
			c.f.fLine=115;
			if (g->Call(ctx,(PCV[]){t105.cv()},0,1466)) goto _0;
			Variant t106;
			if (g->GetMember(ctx,t105.cv(),KcolQryLines.cv(),t106.cv())) goto _0;
			Obj t107;
			Obj t108;
			t108=loQry.get();
			Col t109;
			if (!g->GetValue(ctx,(PCV[]){t109.cv(),t106.cv(),nullptr})) goto _0;
			proc_DQFW__PARSEQUERY(glob,ctx,2,3,(PCV[]){t109.cv(),t108.cv(),t107.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Variant t110;
			c.f.fLine=116;
			if (g->GetMember(ctx,loQry.cv(),KqryText.cv(),t110.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KQryText.cv(),t110.cv())) goto _0;
		}
		{
			Txt t111;
			c.f.fLine=117;
			if (g->Call(ctx,(PCV[]){t111.cv(),loQry.cv()},1,1217)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loSysBook.cv(),KQryParams.cv(),t111.cv())) goto _0;
		}
		{
			Bool t112;
			t112=Bool(1).get();
			c.f.fLine=118;
			if (g->SetMember(ctx,loSysBook.cv(),KIsActive.cv(),t112.cv())) goto _0;
		}
		{
			Variant t113;
			c.f.fLine=119;
			if (!g->GetValue(ctx,(PCV[]){t113.cv(),Var<Variant>(ctx,vUSR__GetCurrent).cv(),nullptr})) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KCreatedBy.cv(),t113.cv())) goto _0;
		}
		{
			Obj t114;
			t114=loSysBook.get();
			Bool t115;
			c.f.fLine=121;
			proc_SBK__EDIT(glob,ctx,1,1,(PCV[]){t114.cv()},t115.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lbSuccess=t115.get();
		}
		if (!(lbSuccess.get())) goto _21;
		c.f.fLine=123;
		if (g->Call(ctx,(PCV[]){nullptr,kGpkCbRdAut0.cv()},1,41)) goto _0;
		g->Check(ctx);
_21:
		goto _10;
_20:
		{
			Variant t116;
			c.f.fLine=126;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t116.cv())) goto _0;
			Bool t117;
			if (g->OperationOnAny(ctx,6,t116.cv(),kVn4UTeilKOI.cv(),t117.cv())) goto _0;
			if (!(t117.get())) goto _22;
		}
		{
			Obj t118;
			c.f.fLine=128;
			if (g->Call(ctx,(PCV[]){t118.cv()},0,1466)) goto _0;
			Variant t119;
			if (g->GetMember(ctx,t118.cv(),KcolQryLines.cv(),t119.cv())) goto _0;
			Variant t120;
			if (g->GetMember(ctx,t119.cv(),Klength.cv(),t120.cv())) goto _0;
			Long t121;
			if (!g->GetValue(ctx,(PCV[]){t121.cv(),t120.cv(),nullptr})) goto _0;
			liLines=t121.get();
		}
		{
			Obj t122;
			c.f.fLine=129;
			if (g->Call(ctx,(PCV[]){t122.cv()},0,1466)) goto _0;
			Variant t123;
			if (g->GetMember(ctx,t122.cv(),KcolQryLines.cv(),t123.cv())) goto _0;
			Obj t124;
			if (g->Call(ctx,(PCV[]){t124.cv()},0,1466)) goto _0;
			Variant t125;
			if (g->GetMember(ctx,t124.cv(),KoNewQryLine.cv(),t125.cv())) goto _0;
			Obj t126;
			if (!g->GetValue(ctx,(PCV[]){t126.cv(),t125.cv(),nullptr})) goto _0;
			Obj t127;
			if (g->Call(ctx,(PCV[]){t127.cv(),t126.cv()},1,1225)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,t123.cv(),Kpush.cv(),t127.cv()},3,1500)) goto _0;
		}
		if (0>=liLines.get()) goto _23;
		{
			Obj t129;
			c.f.fLine=131;
			if (g->Call(ctx,(PCV[]){t129.cv()},0,1466)) goto _0;
			Variant t130;
			if (g->GetMember(ctx,t129.cv(),KcolQryLines.cv(),t130.cv())) goto _0;
			Variant t131;
			if (g->GetMember(ctx,t130.cv(),liLines.cv(),t131.cv())) goto _0;
			if (g->SetMember(ctx,t131.cv(),KlogicOP.cv(),KAND.cv())) goto _0;
		}
		{
			Obj t132;
			c.f.fLine=132;
			if (g->Call(ctx,(PCV[]){t132.cv()},0,1466)) goto _0;
			Variant t133;
			if (g->GetMember(ctx,t132.cv(),KcolQryLines.cv(),t133.cv())) goto _0;
			Variant t134;
			if (g->GetMember(ctx,t133.cv(),liLines.cv(),t134.cv())) goto _0;
			if (g->SetMember(ctx,t134.cv(),KtLogic.cv(),KAND.cv())) goto _0;
		}
_23:
		goto _10;
_22:
		{
			Variant t135;
			c.f.fLine=135;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t135.cv())) goto _0;
			Bool t136;
			if (g->OperationOnAny(ctx,6,t135.cv(),kIbq0A3jgcHQ.cv(),t136.cv())) goto _0;
			if (!(t136.get())) goto _24;
		}
		{
			Obj t137;
			c.f.fLine=136;
			if (g->Call(ctx,(PCV[]){t137.cv()},0,1466)) goto _0;
			Variant t138;
			if (g->GetMember(ctx,t137.cv(),KiQryLineIndx.cv(),t138.cv())) goto _0;
			Bool t139;
			if (g->OperationOnAny(ctx,5,t138.cv(),Num(0).cv(),t139.cv())) goto _0;
			if (!(t139.get())) goto _25;
		}
		{
			Obj t140;
			c.f.fLine=137;
			if (g->Call(ctx,(PCV[]){t140.cv()},0,1466)) goto _0;
			Variant t141;
			if (g->GetMember(ctx,t140.cv(),KcolQryLines.cv(),t141.cv())) goto _0;
			Obj t142;
			if (g->Call(ctx,(PCV[]){t142.cv()},0,1466)) goto _0;
			Variant t143;
			if (g->GetMember(ctx,t142.cv(),KiQryLineIndx.cv(),t143.cv())) goto _0;
			Variant t144;
			if (g->OperationOnAny(ctx,1,t143.cv(),Num(1).cv(),t144.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t141.cv(),Kremove.cv(),t144.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t145;
			c.f.fLine=138;
			if (g->Call(ctx,(PCV[]){t145.cv()},0,1466)) goto _0;
			Variant t146;
			if (g->GetMember(ctx,t145.cv(),KcolQryLines.cv(),t146.cv())) goto _0;
			Variant t147;
			if (g->GetMember(ctx,t146.cv(),Klength.cv(),t147.cv())) goto _0;
			Bool t148;
			if (g->OperationOnAny(ctx,5,t147.cv(),Num(0).cv(),t148.cv())) goto _0;
			if (!(t148.get())) goto _26;
		}
		{
			Obj t149;
			c.f.fLine=140;
			if (g->Call(ctx,(PCV[]){t149.cv()},0,1466)) goto _0;
			Variant t150;
			if (g->GetMember(ctx,t149.cv(),KcolQryLines.cv(),t150.cv())) goto _0;
			Variant t151;
			if (g->GetMember(ctx,t150.cv(),Long(0).cv(),t151.cv())) goto _0;
			if (g->SetMember(ctx,t151.cv(),KlogicOP.cv(),K.cv())) goto _0;
		}
		{
			Obj t152;
			c.f.fLine=141;
			if (g->Call(ctx,(PCV[]){t152.cv()},0,1466)) goto _0;
			Variant t153;
			if (g->GetMember(ctx,t152.cv(),KcolQryLines.cv(),t153.cv())) goto _0;
			Variant t154;
			if (g->GetMember(ctx,t153.cv(),Long(0).cv(),t154.cv())) goto _0;
			if (g->SetMember(ctx,t154.cv(),KtLogic.cv(),K.cv())) goto _0;
		}
_26:
		{
			Obj t155;
			c.f.fLine=144;
			if (g->Call(ctx,(PCV[]){t155.cv()},0,1466)) goto _0;
			Obj t156;
			if (g->Call(ctx,(PCV[]){t156.cv()},0,1466)) goto _0;
			Variant t157;
			if (g->GetMember(ctx,t156.cv(),KcolQryLines.cv(),t157.cv())) goto _0;
			if (g->SetMember(ctx,t155.cv(),KcolQryLines.cv(),t157.cv())) goto _0;
		}
_25:
		goto _10;
_24:
		{
			Variant t158;
			c.f.fLine=147;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t158.cv())) goto _0;
			Bool t159;
			if (g->OperationOnAny(ctx,6,t158.cv(),KbttnRecent_40.cv(),t159.cv())) goto _0;
			if (!(t159.get())) goto _27;
		}
		{
			Obj t160;
			c.f.fLine=150;
			if (g->Call(ctx,(PCV[]){t160.cv()},0,1466)) goto _0;
			Variant t161;
			if (g->GetMember(ctx,t160.cv(),kI9o4oFrPi2g.cv(),t161.cv())) goto _0;
			Col t162;
			if (!g->GetValue(ctx,(PCV[]){t162.cv(),t161.cv(),nullptr})) goto _0;
			Obj t163;
			proc_DQFW__QUERYFORMSELECTRECENT(glob,ctx,1,1,(PCV[]){t162.cv()},t163.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loSystem=t163.get();
		}
		{
			Bool t164;
			c.f.fLine=152;
			if (g->Call(ctx,(PCV[]){t164.cv(),loSystem.cv()},1,1297)) goto _0;
			g->Check(ctx);
			Bool t165;
			t165=t164.get();
			Bool t166;
			t166=!(t165.get());
			if (!(t166.get())) goto _28;
		}
		{
			Obj t167;
			c.f.fLine=153;
			if (g->Call(ctx,(PCV[]){t167.cv()},0,1466)) goto _0;
			Variant t168;
			if (g->GetMember(ctx,loSystem.cv(),KcolQryLines.cv(),t168.cv())) goto _0;
			Variant t169;
			if (g->Call(ctx,(PCV[]){t169.cv(),t168.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t167.cv(),KcolQryLines.cv(),t169.cv())) goto _0;
		}
_28:
		goto _10;
_27:
		{
			Variant t170;
			c.f.fLine=156;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t170.cv())) goto _0;
			Bool t171;
			if (g->OperationOnAny(ctx,6,t170.cv(),KBttnSaveSystem.cv(),t171.cv())) goto _0;
			if (!(t171.get())) goto _29;
		}
		{
			Obj t172;
			c.f.fLine=158;
			if (g->Call(ctx,(PCV[]){t172.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSysBook=t172.get();
		}
		{
			Obj t173;
			c.f.fLine=159;
			if (g->Call(ctx,(PCV[]){t173.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loQry=t173.get();
		}
		{
			Obj t174;
			c.f.fLine=160;
			if (g->Call(ctx,(PCV[]){t174.cv()},0,1466)) goto _0;
			Variant t175;
			if (g->GetMember(ctx,t174.cv(),KtQueryTable.cv(),t175.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KBaseEntity.cv(),t175.cv())) goto _0;
		}
		c.f.fLine=161;
		if (g->SetMember(ctx,loSysBook.cv(),KGroup.cv(),K.cv())) goto _0;
		c.f.fLine=162;
		if (g->SetMember(ctx,loSysBook.cv(),KCategory.cv(),K.cv())) goto _0;
		{
			Obj t176;
			c.f.fLine=163;
			if (g->Call(ctx,(PCV[]){t176.cv()},0,1466)) goto _0;
			Variant t177;
			if (g->GetMember(ctx,t176.cv(),KcolQryLines.cv(),t177.cv())) goto _0;
			Obj t178;
			if (g->Call(ctx,(PCV[]){t178.cv(),KqryLines.cv(),t177.cv()},2,1471)) goto _0;
			g->Check(ctx);
			Txt t179;
			if (g->Call(ctx,(PCV[]){t179.cv(),t178.cv()},1,1217)) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KQryLines.cv(),t179.cv())) goto _0;
		}
		{
			Obj t180;
			c.f.fLine=164;
			if (g->Call(ctx,(PCV[]){t180.cv()},0,1466)) goto _0;
			Variant t181;
			if (g->GetMember(ctx,t180.cv(),KcolQryLines.cv(),t181.cv())) goto _0;
			Col t182;
			if (!g->GetValue(ctx,(PCV[]){t182.cv(),t181.cv(),nullptr})) goto _0;
			Txt t183;
			proc_DQFW__GETQRYNAME(glob,ctx,1,1,(PCV[]){t182.cv()},t183.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KDisplayQryText.cv(),t183.cv())) goto _0;
		}
		{
			Obj t184;
			c.f.fLine=165;
			if (g->Call(ctx,(PCV[]){t184.cv()},0,1466)) goto _0;
			Variant t185;
			if (g->GetMember(ctx,t184.cv(),KcolQryLines.cv(),t185.cv())) goto _0;
			Obj t186;
			Obj t187;
			t187=loQry.get();
			Col t188;
			if (!g->GetValue(ctx,(PCV[]){t188.cv(),t185.cv(),nullptr})) goto _0;
			proc_DQFW__PARSEQUERY(glob,ctx,2,3,(PCV[]){t188.cv(),t187.cv(),t186.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Variant t189;
			c.f.fLine=166;
			if (g->GetMember(ctx,loQry.cv(),KqryText.cv(),t189.cv())) goto _0;
			if (g->SetMember(ctx,loSysBook.cv(),KQryText.cv(),t189.cv())) goto _0;
		}
		{
			Txt t190;
			c.f.fLine=167;
			if (g->Call(ctx,(PCV[]){t190.cv(),loQry.cv()},1,1217)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loSysBook.cv(),KQryParams.cv(),t190.cv())) goto _0;
		}
		{
			Bool t191;
			t191=Bool(1).get();
			c.f.fLine=168;
			if (g->SetMember(ctx,loSysBook.cv(),KIsActive.cv(),t191.cv())) goto _0;
		}
		c.f.fLine=169;
		if (g->SetMember(ctx,loSysBook.cv(),KCreatedBy.cv(),KUSER.cv())) goto _0;
		{
			Obj t192;
			t192=loSysBook.get();
			Bool t193;
			c.f.fLine=171;
			proc_SBK__EDIT(glob,ctx,1,1,(PCV[]){t192.cv()},t193.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lbSuccess=t193.get();
		}
		if (!(lbSuccess.get())) goto _30;
		c.f.fLine=173;
		if (g->Call(ctx,(PCV[]){nullptr,kGpkCbRdAut0.cv()},1,41)) goto _0;
		g->Check(ctx);
_30:
		goto _10;
_29:
		{
			Variant t194;
			c.f.fLine=176;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t194.cv())) goto _0;
			Bool t195;
			if (g->OperationOnAny(ctx,6,t194.cv(),KbttnLoadSystem_40.cv(),t195.cv())) goto _0;
			if (!(t195.get())) goto _31;
		}
		ltHdrMap=k5hs0QWHiwao.get();
		ltHeaders=ksqpcsLWR6go.get();
		ltWidths=K300_2C300_2C300.get();
		ltHiddenCols=KQryLines.get();
		{
			Obj t196;
			c.f.fLine=186;
			if (g->Call(ctx,(PCV[]){t196.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loListItems=t196.get();
		}
		{
			Txt t197;
			t197=ltHiddenCols.get();
			Txt t198;
			t198=ltWidths.get();
			Txt t199;
			t199=ltHdrMap.get();
			Txt t200;
			t200=ltHeaders.get();
			Col t201;
			c.f.fLine=187;
			proc_WDGT__CONFIGCOLUMNS(glob,ctx,4,4,(PCV[]){t200.cv(),t199.cv(),t198.cv(),t197.cv()},t201.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loListItems.cv(),KcolLBSetup.cv(),t201.cv())) goto _0;
		}
		c.f.fLine=188;
		if (g->SetMember(ctx,loListItems.cv(),KtFormHeader.cv(),KSelect_20a_20Role.cv())) goto _0;
		c.f.fLine=189;
		if (g->SetMember(ctx,loListItems.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t202;
			c.f.fLine=190;
			if (g->Call(ctx,(PCV[]){t202.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t202.cv())) goto _0;
		}
		{
			Obj t203;
			c.f.fLine=192;
			if (g->Call(ctx,(PCV[]){t203.cv()},0,1482)) goto _0;
			Variant t204;
			if (g->Call(ctx,(PCV[]){t204.cv(),t203.cv(),KDBQueries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Txt t205;
			g->AddString(KBaseEntity_20_3D_20_3A1.get(),K_20AND_20Group_20_23_20_3A2.get(),t205.get());
			Obj t206;
			if (g->Call(ctx,(PCV[]){t206.cv()},0,1466)) goto _0;
			Variant t207;
			if (g->GetMember(ctx,t206.cv(),KtQueryTable.cv(),t207.cv())) goto _0;
			Variant t208;
			if (g->Call(ctx,(PCV[]){t208.cv(),t204.cv(),Kquery.cv(),t205.cv(),t207.cv(),KUI__SEARCH.cv()},5,1498)) goto _0;
			Obj t209;
			if (!g->GetValue(ctx,(PCV[]){t209.cv(),t208.cv(),nullptr})) goto _0;
			lesSystems=t209.get();
		}
		{
			Bool t210;
			t210=!lesSystems.isNull();
			if (!(t210.get())) goto _32;
		}
		{
			Variant t211;
			c.f.fLine=195;
			if (g->Call(ctx,(PCV[]){t211.cv(),lesSystems.cv(),KtoCollection.cv(),ltHdrMap.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loListItems.cv(),KcolListItems.cv(),t211.cv())) goto _0;
		}
_32:
		{
			Obj t212;
			t212=loListItems.get();
			Col t213;
			c.f.fLine=198;
			proc_WDGT__SELECT(glob,ctx,1,1,(PCV[]){t212.cv()},t213.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			lcolUserSelection=t213.get();
		}
		{
			Variant t214;
			c.f.fLine=200;
			if (g->Call(ctx,(PCV[]){t214.cv(),lcolUserSelection.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t215;
			if (g->OperationOnAny(ctx,6,t214.cv(),Num(1).cv(),t215.cv())) goto _0;
			if (!(t215.get())) goto _33;
		}
		{
			Variant t216;
			c.f.fLine=201;
			if (g->GetMember(ctx,lcolUserSelection.cv(),Long(0).cv(),t216.cv())) goto _0;
			Variant t217;
			if (g->GetMember(ctx,t216.cv(),KQryLines.cv(),t217.cv())) goto _0;
			Long t218;
			t218=38;
			Txt t219;
			if (!g->GetValue(ctx,(PCV[]){t219.cv(),t217.cv(),nullptr})) goto _0;
			Obj t220;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t219.cv(),t218.cv()},t220.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t221;
			if (g->GetMember(ctx,t220.cv(),KoObject.cv(),t221.cv())) goto _0;
			Obj t222;
			if (!g->GetValue(ctx,(PCV[]){t222.cv(),t221.cv(),nullptr})) goto _0;
			loQry=t222.get();
		}
		{
			Bool t223;
			t223=!loQry.isNull();
			if (!(t223.get())) goto _34;
		}
		{
			Obj t224;
			c.f.fLine=204;
			if (g->Call(ctx,(PCV[]){t224.cv()},0,1466)) goto _0;
			Variant t225;
			if (g->GetMember(ctx,t224.cv(),KcolQryLines.cv(),t225.cv())) goto _0;
			Variant t226;
			if (g->GetMember(ctx,t225.cv(),Klength.cv(),t226.cv())) goto _0;
			Bool t227;
			if (g->OperationOnAny(ctx,5,t226.cv(),Num(0).cv(),t227.cv())) goto _0;
			if (!(t227.get())) goto _35;
		}
		{
			Variant t228;
			c.f.fLine=205;
			if (g->GetMember(ctx,loQry.cv(),KqryLines.cv(),t228.cv())) goto _0;
			Variant t229;
			if (g->GetMember(ctx,t228.cv(),Long(0).cv(),t229.cv())) goto _0;
			if (g->SetMember(ctx,t229.cv(),KlogicOP.cv(),KAND.cv())) goto _0;
		}
		{
			Variant t230;
			c.f.fLine=206;
			if (g->GetMember(ctx,loQry.cv(),KqryLines.cv(),t230.cv())) goto _0;
			Variant t231;
			if (g->GetMember(ctx,t230.cv(),Long(0).cv(),t231.cv())) goto _0;
			if (g->SetMember(ctx,t231.cv(),KtLogic.cv(),KAND.cv())) goto _0;
		}
_35:
		{
			Obj t232;
			c.f.fLine=209;
			if (g->Call(ctx,(PCV[]){t232.cv()},0,1466)) goto _0;
			Variant t233;
			if (g->GetMember(ctx,loQry.cv(),KqryLines.cv(),t233.cv())) goto _0;
			Variant t234;
			if (g->Call(ctx,(PCV[]){t234.cv(),t233.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t232.cv(),KcolQryLines.cv(),t234.cv())) goto _0;
		}
		{
			Obj t235;
			c.f.fLine=210;
			if (g->Call(ctx,(PCV[]){t235.cv()},0,1466)) goto _0;
			Variant t236;
			if (g->GetMember(ctx,t235.cv(),KtCurPage.cv(),t236.cv())) goto _0;
			Variant t237;
			if (g->OperationOnAny(ctx,0,KlbQryLines.cv(),t236.cv(),t237.cv())) goto _0;
			Txt t238;
			if (!g->GetValue(ctx,(PCV[]){t238.cv(),t237.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t238.cv()},2,206)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t239;
			c.f.fLine=211;
			if (g->Call(ctx,(PCV[]){t239.cv()},0,1466)) goto _0;
			Variant t240;
			if (g->GetMember(ctx,t239.cv(),KtCurPage.cv(),t240.cv())) goto _0;
			Variant t241;
			if (g->OperationOnAny(ctx,0,KtAlias.cv(),t240.cv(),t241.cv())) goto _0;
			Obj t242;
			if (g->Call(ctx,(PCV[]){t242.cv()},0,1466)) goto _0;
			Variant t243;
			if (g->GetMember(ctx,t242.cv(),KcolQryLines.cv(),t243.cv())) goto _0;
			Variant t244;
			if (g->GetMember(ctx,t243.cv(),Klength.cv(),t244.cv())) goto _0;
			Txt t245;
			if (!g->GetValue(ctx,(PCV[]){t245.cv(),t241.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t245.cv(),t244.cv()},3,870)) goto _0;
			g->Check(ctx);
		}
		goto _36;
_34:
		c.f.fLine=214;
		if (g->Call(ctx,(PCV[]){nullptr,kYhLxOkZaZqg.cv()},1,41)) goto _0;
		g->Check(ctx);
_36:
_33:
		goto _10;
_31:
		{
			Variant t246;
			c.f.fLine=220;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t246.cv())) goto _0;
			Bool t247;
			if (g->OperationOnAny(ctx,6,t246.cv(),KbttnImport.cv(),t247.cv())) goto _0;
			if (!(t247.get())) goto _37;
		}
		{
			Time t248;
			c.f.fLine=226;
			if (g->Call(ctx,(PCV[]){t248.cv(),K.cv(),Kjsn.cv()},2,264)) goto _0;
			g->Check(ctx);
			lhDoc=t248.get();
		}
		if (1!=Var<Long>(ctx,vOK).get()) goto _38;
		{
			Time t250;
			t250=lhDoc.get();
			c.f.fLine=229;
			if (g->Call(ctx,(PCV[]){nullptr,t250.cv()},1,267)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t251;
			c.f.fLine=230;
			if (g->Call(ctx,(PCV[]){t251.cv(),Var<Txt>(ctx,vDOCUMENT).cv(),Long(1).cv()},2,1566)) goto _0;
			g->Check(ctx);
			loImportFile=t251.get();
		}
		{
			Variant t252;
			c.f.fLine=231;
			if (g->Call(ctx,(PCV[]){t252.cv(),loImportFile.cv(),KgetText.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Txt t253;
			if (!g->GetValue(ctx,(PCV[]){t253.cv(),t252.cv(),nullptr})) goto _0;
			ltQueryLines=t253.get();
		}
		{
			Long t254;
			t254=0;
			Txt t255;
			t255=ltQueryLines.get();
			Obj t256;
			c.f.fLine=232;
			proc_UTIL__PARSEJSONSTR(glob,ctx,1,2,(PCV[]){t255.cv(),t254.cv()},t256.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loResult=t256.get();
		}
		{
			Variant t257;
			c.f.fLine=234;
			if (g->GetMember(ctx,loResult.cv(),KbSuccess.cv(),t257.cv())) goto _0;
			Bool t258;
			if (!g->GetValue(ctx,(PCV[]){t258.cv(),t257.cv(),nullptr})) goto _0;
			if (!(t258.get())) goto _39;
		}
		{
			Variant t259;
			c.f.fLine=235;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t259.cv())) goto _0;
			Variant t260;
			if (g->GetMember(ctx,t259.cv(),KcolQryLines.cv(),t260.cv())) goto _0;
			Bool t261;
			if (g->OperationOnAny(ctx,7,t260.cv(),Value_null().cv(),t261.cv())) goto _0;
			if (!(t261.get())) goto _40;
		}
		{
			Variant t262;
			c.f.fLine=236;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t262.cv())) goto _0;
			Obj t263;
			if (!g->GetValue(ctx,(PCV[]){t263.cv(),t262.cv(),nullptr})) goto _0;
			Long t264;
			if (g->Call(ctx,(PCV[]){t264.cv(),t263.cv(),KcolQryLines.cv()},2,1230)) goto _0;
			g->Check(ctx);
			Bool t265;
			t265=42==t264.get();
			if (!(t265.get())) goto _41;
		}
		{
			Obj t266;
			c.f.fLine=237;
			if (g->Call(ctx,(PCV[]){t266.cv()},0,1466)) goto _0;
			Variant t267;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t267.cv())) goto _0;
			Variant t268;
			if (g->GetMember(ctx,t267.cv(),KcolQryLines.cv(),t268.cv())) goto _0;
			Variant t269;
			if (g->Call(ctx,(PCV[]){t269.cv(),t268.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t266.cv(),KcolQryLines.cv(),t269.cv())) goto _0;
		}
		goto _42;
_41:
		c.f.fLine=240;
		if (g->Call(ctx,(PCV[]){nullptr,kSw3pZ8WhbHE.cv()},1,41)) goto _0;
		g->Check(ctx);
_42:
		goto _43;
_40:
		c.f.fLine=244;
		if (g->Call(ctx,(PCV[]){nullptr,kHWbpQfb3ej0.cv()},1,41)) goto _0;
		g->Check(ctx);
_43:
		goto _44;
_39:
		c.f.fLine=249;
		if (g->Call(ctx,(PCV[]){nullptr,kFEAgzPXQQ1U.cv()},1,41)) goto _0;
		g->Check(ctx);
_44:
_38:
		goto _10;
_37:
		{
			Variant t270;
			c.f.fLine=255;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t270.cv())) goto _0;
			Bool t271;
			if (g->OperationOnAny(ctx,6,t270.cv(),KbttnExport.cv(),t271.cv())) goto _0;
			if (!(t271.get())) goto _45;
		}
		{
			Obj t272;
			c.f.fLine=261;
			if (g->Call(ctx,(PCV[]){t272.cv()},0,1466)) goto _0;
			Variant t273;
			if (g->GetMember(ctx,t272.cv(),KcolQryLines.cv(),t273.cv())) goto _0;
			Variant t274;
			if (g->GetMember(ctx,t273.cv(),Klength.cv(),t274.cv())) goto _0;
			Bool t275;
			if (g->OperationOnAny(ctx,5,t274.cv(),Num(0).cv(),t275.cv())) goto _0;
			if (!(t275.get())) goto _46;
		}
		{
			Time t276;
			c.f.fLine=262;
			if (g->Call(ctx,(PCV[]){t276.cv(),K.cv(),Kjsn.cv()},2,266)) goto _0;
			g->Check(ctx);
			lhDoc=t276.get();
		}
		if (1!=Var<Long>(ctx,vOK).get()) goto _47;
		{
			Time t278;
			t278=lhDoc.get();
			c.f.fLine=265;
			if (g->Call(ctx,(PCV[]){nullptr,t278.cv()},1,267)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t279;
			c.f.fLine=266;
			if (g->Call(ctx,(PCV[]){t279.cv(),Var<Txt>(ctx,vDOCUMENT).cv(),Long(1).cv()},2,1566)) goto _0;
			g->Check(ctx);
			loExportFile=t279.get();
		}
		{
			Obj t280;
			c.f.fLine=267;
			if (g->Call(ctx,(PCV[]){t280.cv()},0,1466)) goto _0;
			Variant t281;
			if (g->GetMember(ctx,t280.cv(),KcolQryLines.cv(),t281.cv())) goto _0;
			Obj t282;
			if (g->Call(ctx,(PCV[]){t282.cv(),KcolQryLines.cv(),t281.cv()},2,1471)) goto _0;
			g->Check(ctx);
			Txt t283;
			if (g->Call(ctx,(PCV[]){t283.cv(),t282.cv()},1,1217)) goto _0;
			ltQueryLines=t283.get();
		}
		c.f.fLine=269;
		if (g->Call(ctx,(PCV[]){nullptr,loExportFile.cv(),KsetText.cv(),ltQueryLines.cv()},3,1500)) goto _0;
		g->Check(ctx);
		{
			Variant t284;
			c.f.fLine=270;
			if (g->GetMember(ctx,loExportFile.cv(),KplatformPath.cv(),t284.cv())) goto _0;
			Variant t285;
			if (g->OperationOnAny(ctx,0,kdhneN13oy0I.cv(),t284.cv(),t285.cv())) goto _0;
			Txt t286;
			if (!g->GetValue(ctx,(PCV[]){t286.cv(),t285.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t286.cv()},1,41)) goto _0;
			g->Check(ctx);
		}
_47:
_46:
		goto _10;
_45:
		{
			Variant t287;
			c.f.fLine=276;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t287.cv())) goto _0;
			Bool t288;
			if (g->OperationOnAny(ctx,6,t287.cv(),KbttnRun_40.cv(),t288.cv())) goto _0;
			if (!(t288.get())) goto _48;
		}
		{
			Obj t289;
			c.f.fLine=281;
			if (g->Call(ctx,(PCV[]){t289.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loQry=t289.get();
		}
		{
			Obj t290;
			c.f.fLine=282;
			if (g->Call(ctx,(PCV[]){t290.cv()},0,1466)) goto _0;
			Variant t291;
			if (g->GetMember(ctx,t290.cv(),KcolQryLines.cv(),t291.cv())) goto _0;
			Obj t292;
			Obj t293;
			t293=loQry.get();
			Col t294;
			if (!g->GetValue(ctx,(PCV[]){t294.cv(),t291.cv(),nullptr})) goto _0;
			proc_DQFW__PARSEQUERY(glob,ctx,2,3,(PCV[]){t294.cv(),t293.cv(),t292.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Variant t295;
			c.f.fLine=283;
			if (g->GetMember(ctx,loQry.cv(),Kattributes.cv(),t295.cv())) goto _0;
			Variant t296;
			if (g->Call(ctx,(PCV[]){t296.cv(),t295.cv(),KindexOf.cv(),K.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Bool t297;
			if (g->OperationOnAny(ctx,4,t296.cv(),Num(0).cv(),t297.cv())) goto _0;
			if (!(t297.get())) goto _49;
		}
		{
			Obj t298;
			c.f.fLine=284;
			if (g->Call(ctx,(PCV[]){t298.cv()},0,1466)) goto _0;
			Obj t299;
			if (g->Call(ctx,(PCV[]){t299.cv()},0,1482)) goto _0;
			Obj t300;
			if (g->Call(ctx,(PCV[]){t300.cv()},0,1466)) goto _0;
			Variant t301;
			if (g->GetMember(ctx,t300.cv(),KtQueryTable.cv(),t301.cv())) goto _0;
			Variant t302;
			if (g->GetMember(ctx,t299.cv(),t301.cv(),t302.cv())) goto _0;
			Variant t303;
			if (g->GetMember(ctx,loQry.cv(),KqryText.cv(),t303.cv())) goto _0;
			Variant t304;
			if (g->Call(ctx,(PCV[]){t304.cv(),t302.cv(),Kquery.cv(),t303.cv(),loQry.cv()},4,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t298.cv(),k7nPzzMJ4l8k.cv(),t304.cv())) goto _0;
		}
		{
			Obj t305;
			c.f.fLine=286;
			if (g->Call(ctx,(PCV[]){t305.cv()},0,1466)) goto _0;
			Variant t306;
			if (g->GetMember(ctx,t305.cv(),KcolQryLines.cv(),t306.cv())) goto _0;
			Txt t307;
			Col t308;
			if (!g->GetValue(ctx,(PCV[]){t308.cv(),t306.cv(),nullptr})) goto _0;
			Txt t309;
			proc_DQFW__STRINGIFY(glob,ctx,1,2,(PCV[]){t308.cv(),t307.cv()},t309.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			ltRecentQry=t309.get();
		}
		{
			Obj t310;
			c.f.fLine=289;
			if (g->Call(ctx,(PCV[]){t310.cv()},0,1466)) goto _0;
			Variant t311;
			if (g->GetMember(ctx,t310.cv(),k0hyJBtb3YKs.cv(),t311.cv())) goto _0;
			Variant t312;
			if (g->Call(ctx,(PCV[]){t312.cv(),t311.cv(),KindexOf.cv(),ltRecentQry.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Bool t313;
			if (g->OperationOnAny(ctx,4,t312.cv(),Num(0).cv(),t313.cv())) goto _0;
			if (!(t313.get())) goto _50;
		}
		{
			Obj t314;
			c.f.fLine=290;
			if (g->Call(ctx,(PCV[]){t314.cv()},0,1466)) goto _0;
			Obj t315;
			if (g->Call(ctx,(PCV[]){t315.cv()},0,1466)) goto _0;
			Variant t316;
			if (g->GetMember(ctx,t315.cv(),k0hyJBtb3YKs.cv(),t316.cv())) goto _0;
			Variant t317;
			if (g->Call(ctx,(PCV[]){t317.cv(),t316.cv(),Kinsert.cv(),Long(0).cv(),ltRecentQry.cv()},4,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,t314.cv(),k0hyJBtb3YKs.cv(),t317.cv())) goto _0;
		}
_50:
		{
			Obj t318;
			c.f.fLine=293;
			if (g->Call(ctx,(PCV[]){t318.cv()},0,1466)) goto _0;
			Variant t319;
			if (g->GetMember(ctx,t318.cv(),KbUpdateCache.cv(),t319.cv())) goto _0;
			Bool t320;
			if (!g->GetValue(ctx,(PCV[]){t320.cv(),t319.cv(),nullptr})) goto _0;
			if (!(t320.get())) goto _51;
		}
		{
			Obj t321;
			c.f.fLine=294;
			if (g->Call(ctx,(PCV[]){t321.cv()},0,1466)) goto _0;
			Variant t322;
			if (g->GetMember(ctx,t321.cv(),ksv03rMKIa68.cv(),t322.cv())) goto _0;
			Obj t323;
			if (g->Call(ctx,(PCV[]){t323.cv()},0,1466)) goto _0;
			Variant t324;
			if (g->GetMember(ctx,t323.cv(),k0hyJBtb3YKs.cv(),t324.cv())) goto _0;
			Long t325;
			t325=42;
			Txt t326;
			if (!g->GetValue(ctx,(PCV[]){t326.cv(),t322.cv(),nullptr})) goto _0;
			proc_CACHE__UPDATE(glob,ctx,3,3,(PCV[]){t326.cv(),t324.cv(),t325.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
_51:
		{
			Long t327;
			c.f.fLine=298;
			if (g->Call(ctx,(PCV[]){t327.cv()},0,276)) goto _0;
			g->Check(ctx);
			if (1!=t327.get()) goto _52;
		}
		ltScreenType=KADVANCED.get();
		goto _53;
_52:
		ltScreenType=KBASIC.get();
_53:
		c.f.fLine=316;
		if (g->Call(ctx,(PCV[]){nullptr},0,269)) goto _0;
		g->Check(ctx);
		goto _54;
_49:
		c.f.fLine=318;
		if (g->Call(ctx,(PCV[]){nullptr,k9HkhWTimNqc.cv()},1,41)) goto _0;
		g->Check(ctx);
_54:
		goto _10;
_48:
		{
			Variant t329;
			c.f.fLine=323;
			if (g->GetMember(ctx,loFormEvent.cv(),KobjectName.cv(),t329.cv())) goto _0;
			Bool t330;
			if (g->OperationOnAny(ctx,6,t329.cv(),KbttnCancel.cv(),t330.cv())) goto _0;
			if (!(t330.get())) goto _55;
		}
		{
			Obj t331;
			c.f.fLine=324;
			if (g->Call(ctx,(PCV[]){t331.cv()},0,1466)) goto _0;
			Variant t332;
			t332.setNull();
			if (g->SetMember(ctx,t331.cv(),k7nPzzMJ4l8k.cv(),t332.cv())) goto _0;
		}
		goto _10;
_55:
_10:
_9:
_0:
_1:
;
	}

}
