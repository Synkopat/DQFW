extern Txt KDone;
extern unsigned char D_proc_PURGEDATA[];
void proc_PURGEDATA( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_PURGEDATA);
	if (!ctx->doingAbort) {
		c.f.fLine=1;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(1,0).cv()},1,47)) goto _0;
		g->Check(ctx);
		c.f.fLine=2;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(1,0).cv()},1,66)) goto _0;
		g->Check(ctx);
		c.f.fLine=4;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(5,0).cv()},1,47)) goto _0;
		g->Check(ctx);
		c.f.fLine=5;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(5,0).cv()},1,66)) goto _0;
		g->Check(ctx);
		c.f.fLine=7;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(6,0).cv()},1,47)) goto _0;
		g->Check(ctx);
		c.f.fLine=8;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(6,0).cv()},1,66)) goto _0;
		g->Check(ctx);
		c.f.fLine=10;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(2,0).cv()},1,47)) goto _0;
		g->Check(ctx);
		c.f.fLine=11;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(2,0).cv()},1,66)) goto _0;
		g->Check(ctx);
		c.f.fLine=13;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(7,0).cv()},1,47)) goto _0;
		g->Check(ctx);
		c.f.fLine=14;
		if (g->Call(ctx,(PCV[]){nullptr,Ref(7,0).cv()},1,66)) goto _0;
		g->Check(ctx);
		c.f.fLine=19;
		if (g->Call(ctx,(PCV[]){nullptr,KDone.cv()},1,41)) goto _0;
		g->Check(ctx);
_0:
_1:
;
	}

}
