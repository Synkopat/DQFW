extern Txt K;
extern Txt KBaseEntity;
extern Txt KCategory;
extern Txt KDisplayRole;
extern Txt KGroup;
extern Txt KQueryName;
extern Txt KSBK__Search;
extern Txt KeDBQuery;
extern Txt KiWinRef;
extern Txt KtFormHeader;
extern Txt kFC3mrBPpIRQ;
extern Txt kY$vPzVyalUU;
extern Txt kumdMK_s5sbI;
Asm4d_Proc proc_WIND__OPENWINDOW;
extern unsigned char D_proc_SBK__SEARCH[];
void proc_SBK__SEARCH( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__SEARCH);
	if (!ctx->doingAbort) {
		Obj lesSystems;
		Txt ltForm;
		Long liFormHeight;
		Long liFormWidth;
		Obj loSysBook;
		Bool lJCPEREZ__20241102;
		Obj loDBQuery;
		new ( outResult) Obj();
		c.f.fLine=10;
		loSysBook=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		ltForm=KSBK__Search.get();
		{
			Ref t0;
			t0.setLocalRef(ctx,liFormHeight.cv());
			Ref t1;
			t1.setLocalRef(ctx,liFormWidth.cv());
			c.f.fLine=13;
			if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),t1.cv(),t0.cv()},3,674)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t2;
			c.f.fLine=18;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loDBQuery=t2.get();
		}
		c.f.fLine=19;
		if (g->SetMember(ctx,loDBQuery.cv(),KtFormHeader.cv(),kumdMK_s5sbI.cv())) goto _0;
		{
			Variant t3;
			c.f.fLine=20;
			if (g->GetMember(ctx,loSysBook.cv(),KBaseEntity.cv(),t3.cv())) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KBaseEntity.cv(),t3.cv())) goto _0;
		}
		{
			Variant t4;
			t4.setNull();
			c.f.fLine=21;
			if (g->SetMember(ctx,loDBQuery.cv(),kFC3mrBPpIRQ.cv(),t4.cv())) goto _0;
		}
		{
			Obj t5;
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){t5.cv()},0,1471)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t5.cv())) goto _0;
		}
		{
			Variant t6;
			c.f.fLine=23;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t6.cv())) goto _0;
			Variant t7;
			t7.setNull();
			if (g->SetMember(ctx,t6.cv(),KGroup.cv(),t7.cv())) goto _0;
		}
		{
			Variant t8;
			c.f.fLine=24;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t8.cv())) goto _0;
			Variant t9;
			t9.setNull();
			if (g->SetMember(ctx,t8.cv(),KCategory.cv(),t9.cv())) goto _0;
		}
		{
			Variant t10;
			c.f.fLine=25;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t10.cv())) goto _0;
			if (g->SetMember(ctx,t10.cv(),KQueryName.cv(),K.cv())) goto _0;
		}
		{
			Variant t11;
			c.f.fLine=26;
			if (g->GetMember(ctx,loDBQuery.cv(),KeDBQuery.cv(),t11.cv())) goto _0;
			if (g->SetMember(ctx,t11.cv(),KDisplayRole.cv(),K.cv())) goto _0;
		}
		{
			Ptr t12;
			Txt t13;
			t13=ltForm.get();
			Txt t14;
			t14=kY$vPzVyalUU.get();
			Long t15;
			t15=33;
			Long t16;
			t16=6;
			Long t17;
			t17=liFormHeight.get();
			Long t18;
			t18=liFormWidth.get();
			Long t19;
			c.f.fLine=29;
			proc_WIND__OPENWINDOW(glob,ctx,6,7,(PCV[]){t18.cv(),t17.cv(),t16.cv(),t15.cv(),t14.cv(),t13.cv(),t12.cv()},t19.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loDBQuery.cv(),KiWinRef.cv(),t19.cv())) goto _0;
		}
		c.f.fLine=31;
		if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),loDBQuery.cv()},2,40)) goto _0;
		g->Check(ctx);
		{
			Variant t20;
			c.f.fLine=33;
			if (g->GetMember(ctx,loDBQuery.cv(),kFC3mrBPpIRQ.cv(),t20.cv())) goto _0;
			Bool t21;
			if (g->OperationOnAny(ctx,7,t20.cv(),Value_null().cv(),t21.cv())) goto _0;
			if (!(t21.get())) goto _2;
		}
		{
			Variant t22;
			c.f.fLine=34;
			if (g->GetMember(ctx,loDBQuery.cv(),kFC3mrBPpIRQ.cv(),t22.cv())) goto _0;
			Obj t23;
			if (!g->GetValue(ctx,(PCV[]){t23.cv(),t22.cv(),nullptr})) goto _0;
			Res<Obj>(outResult)=t23.get();
		}
		goto _3;
_2:
		{
			Obj t24;
			c.f.fLine=36;
			Res<Obj>(outResult)=t24.get();
		}
_3:
_0:
_1:
;
	}

}
