extern Txt KThis_2E;
extern Txt KbHidden;
extern Txt Kcol;
extern Txt KiPos;
extern Txt KiWidth;
extern Txt KtHeader;
extern Txt KtName;
extern Txt KtVariable;
Asm4d_Proc proc_UTIL__SETOBJVALUES;
extern unsigned char D_proc_LBX__SETUP[];
void proc_LBX__SETUP( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_LBX__SETUP);
	if (!ctx->doingAbort) {
		Bool lbSuccess;
		Txt ltLBName;
		Ptr lpNil;
		Col lcolLBColumns;
		Obj l__4D__auto__iter__0;
		Obj loColSetup;
		Bool lJCPEREZ__20241102;
		Obj loCol;
		new ( outResult) Bool();
		c.f.fLine=17;
		ltLBName=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=18;
		lcolLBColumns=Parm<Col>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		lbSuccess=Bool(1).get();
		{
			Obj t0;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loCol=t0.get();
		}
		{
			Long t1;
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){t1.cv(),Ref((optyp)3).cv(),ltLBName.cv()},2,831)) goto _0;
			g->Check(ctx);
			if (0!=t1.get()) goto _2;
		}
		{
			Ref t3;
			t3.setLocalRef(ctx,loColSetup.cv());
			Obj t4;
			c.f.fLine=28;
			if (g->Call(ctx,(PCV[]){t4.cv(),t3.cv(),lcolLBColumns.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t4.get();
		}
_3:
		{
			Bool t5;
			if (g->Call(ctx,(PCV[]){t5.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t5.get())) goto _4;
		}
		{
			Long t6;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t6.cv(),Ref((optyp)3).cv(),ltLBName.cv()},2,831)) goto _0;
			g->Check(ctx);
			Long t7;
			t7=t6.get()+1;
			if (g->SetMember(ctx,loCol.cv(),KiPos.cv(),t7.cv())) goto _0;
		}
		{
			Variant t8;
			c.f.fLine=31;
			if (g->GetMember(ctx,loCol.cv(),KiPos.cv(),t8.cv())) goto _0;
			Txt t9;
			if (g->Call(ctx,(PCV[]){t9.cv(),t8.cv()},1,10)) goto _0;
			Txt t10;
			g->AddString(Kcol.get(),t9.get(),t10.get());
			if (g->SetMember(ctx,loCol.cv(),KtName.cv(),t10.cv())) goto _0;
		}
		{
			Variant t11;
			c.f.fLine=32;
			if (g->GetMember(ctx,loCol.cv(),KtName.cv(),t11.cv())) goto _0;
			Variant t12;
			if (g->OperationOnAny(ctx,0,KThis_2E.cv(),t11.cv(),t12.cv())) goto _0;
			if (g->SetMember(ctx,loCol.cv(),KtVariable.cv(),t12.cv())) goto _0;
		}
		{
			Variant t13;
			c.f.fLine=33;
			if (g->GetMember(ctx,loCol.cv(),KtName.cv(),t13.cv())) goto _0;
			if (g->SetMember(ctx,loCol.cv(),KtHeader.cv(),t13.cv())) goto _0;
		}
		{
			Bool t14;
			t14=Bool(0).get();
			c.f.fLine=34;
			if (g->SetMember(ctx,loCol.cv(),KbHidden.cv(),t14.cv())) goto _0;
		}
		{
			Obj t15;
			t15=loColSetup.get();
			Obj t16;
			t16=loCol.get();
			c.f.fLine=36;
			proc_UTIL__SETOBJVALUES(glob,ctx,2,2,(PCV[]){t16.cv(),t15.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Variant t17;
			c.f.fLine=37;
			if (g->GetMember(ctx,loCol.cv(),KiPos.cv(),t17.cv())) goto _0;
			Variant t18;
			if (g->GetMember(ctx,loCol.cv(),KtName.cv(),t18.cv())) goto _0;
			Variant t19;
			if (g->GetMember(ctx,loCol.cv(),KtVariable.cv(),t19.cv())) goto _0;
			Variant t20;
			if (g->GetMember(ctx,loCol.cv(),KtHeader.cv(),t20.cv())) goto _0;
			Ref t21;
			t21.setLocalRef(ctx,lpNil.cv());
			Txt t22;
			if (!g->GetValue(ctx,(PCV[]){t22.cv(),t20.cv(),nullptr})) goto _0;
			Txt t23;
			if (!g->GetValue(ctx,(PCV[]){t23.cv(),t19.cv(),nullptr})) goto _0;
			Txt t24;
			if (!g->GetValue(ctx,(PCV[]){t24.cv(),t18.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),ltLBName.cv(),t17.cv(),t24.cv(),t23.cv(),Long(2).cv(),t22.cv(),t21.cv()},8,970)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t25;
			c.f.fLine=38;
			if (g->GetMember(ctx,loCol.cv(),KtName.cv(),t25.cv())) goto _0;
			Variant t26;
			if (g->GetMember(ctx,loColSetup.cv(),KiWidth.cv(),t26.cv())) goto _0;
			Variant t27;
			if (g->GetMember(ctx,loColSetup.cv(),KiWidth.cv(),t27.cv())) goto _0;
			Variant t28;
			if (g->OperationOnAny(ctx,2,t27.cv(),Num(2).cv(),t28.cv())) goto _0;
			Num t29;
			if (!g->GetValue(ctx,(PCV[]){t29.cv(),t28.cv(),nullptr})) goto _0;
			Num t30;
			if (g->Call(ctx,(PCV[]){t30.cv(),t29.cv(),Long(0).cv()},2,94)) goto _0;
			Variant t31;
			if (g->GetMember(ctx,loColSetup.cv(),KiWidth.cv(),t31.cv())) goto _0;
			Txt t32;
			if (!g->GetValue(ctx,(PCV[]){t32.cv(),t25.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t32.cv(),t26.cv(),t30.cv(),t31.cv()},5,833)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t33;
			c.f.fLine=40;
			if (g->GetMember(ctx,loCol.cv(),KbHidden.cv(),t33.cv())) goto _0;
			Bool t34;
			if (!g->GetValue(ctx,(PCV[]){t34.cv(),t33.cv(),nullptr})) goto _0;
			if (!(t34.get())) goto _5;
		}
		{
			Variant t35;
			c.f.fLine=41;
			if (g->GetMember(ctx,loCol.cv(),KtName.cv(),t35.cv())) goto _0;
			Bool t36;
			t36=Bool(0).get();
			Txt t37;
			if (!g->GetValue(ctx,(PCV[]){t37.cv(),t35.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Ref((optyp)3).cv(),t37.cv(),t36.cv()},3,603)) goto _0;
			g->Check(ctx);
		}
_5:
		goto _3;
_4:
		{
			Obj t38;
			l__4D__auto__iter__0=t38.get();
		}
_2:
		c.f.fLine=48;
		Res<Bool>(outResult)=lbSuccess.get();
_0:
_1:
;
	}

}
