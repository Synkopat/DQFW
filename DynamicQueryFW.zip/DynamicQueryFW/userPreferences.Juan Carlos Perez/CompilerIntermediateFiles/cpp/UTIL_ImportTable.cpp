extern Txt K;
extern Txt KOK;
extern Txt KTRUE;
extern Txt KcharSet;
extern Txt KcolsDelim;
extern Txt KcolumnsMap;
extern Txt Kfile2Import;
extern Txt KfilePath;
extern Txt KheaderRow;
extern Txt KindexOf;
extern Txt Kindx;
extern Txt Klength;
extern Txt Kmax;
extern Txt Kname;
extern Txt Kpush;
extern Txt Kresult;
extern Txt KrowsDelim;
extern Txt KtotalRows;
extern Txt Ktype;
extern Txt k99ZvUtw5fTk;
extern Txt kOJqFOvTiTzk;
extern Txt kY6jJBKNw4xE;
extern unsigned char D_proc_UTIL__IMPORTTABLE[];
void proc_UTIL__IMPORTTABLE( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_UTIL__IMPORTTABLE);
	if (!ctx->doingAbort) {
		Txt ltImportSetting;
		Obj loColumn;
		Col lcolImportedRows;
		Long liRow;
		Col lcolFileRows;
		Txt ltFile;
		Obj loRow;
		Value_array_text latAttributes;
		Time lhStart;
		Col lcolImportSettings;
		Obj l__4D__auto__iter__0;
		Obj l__4D__auto__iter__1;
		Obj l__4D__auto__iter__2;
		Obj l__4D__auto__iter__3;
		Txt lcolRow;
		Bool lJCPEREZ__20230501a;
		Col lcolRowValues;
		Obj loTable;
		Long liBreakmode;
		Bool lbContinue;
		c.f.fLine=14;
		loTable=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=15;
		lcolImportedRows=Parm<Col>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		{
			Ref t0;
			t0.setLocalRef(ctx,latAttributes.cv());
			c.f.fLine=17;
			if (g->Call(ctx,(PCV[]){nullptr,t0.cv(),Long(0).cv()},2,222)) goto _0;
		}
		liBreakmode=0;
		lbContinue=Bool(1).get();
		{
			Col t1;
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){t1.cv(),Kfile2Import.cv(),KcolsDelim.cv(),KrowsDelim.cv(),KcharSet.cv(),KcolumnsMap.cv(),KheaderRow.cv()},6,1472)) goto _0;
			g->Check(ctx);
			lcolImportSettings=t1.get();
		}
		{
			Col t2;
			c.f.fLine=27;
			if (g->Call(ctx,(PCV[]){t2.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolFileRows=t2.get();
		}
		{
			Col t3;
			c.f.fLine=28;
			if (g->Call(ctx,(PCV[]){t3.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolRowValues=t3.get();
		}
		{
			Ref t4;
			t4.setLocalRef(ctx,latAttributes.cv());
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){nullptr,loTable.cv(),t4.cv()},2,1232)) goto _0;
			g->Check(ctx);
		}
		{
			Ref t5;
			t5.setLocalRef(ctx,ltImportSetting.cv());
			Obj t6;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t6.cv(),t5.cv(),lcolImportSettings.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t6.get();
		}
_2:
		{
			Bool t7;
			if (g->Call(ctx,(PCV[]){t7.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t7.get())) goto _3;
		}
		{
			Ref t8;
			t8.setLocalRef(ctx,latAttributes.cv());
			Long t9;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t9.cv(),t8.cv(),ltImportSetting.cv()},2,230)) goto _0;
			if (0<=t9.get()) goto _4;
		}
		{
			Bool t11;
			t11=g->CompareString(ctx,ltImportSetting.get(),Kfile2Import.get())==0;
			if (!(t11.get())) goto _6;
		}
		c.f.fLine=37;
		if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),K.cv())) goto _0;
		goto _5;
_6:
		{
			Bool t12;
			t12=g->CompareString(ctx,ltImportSetting.get(),KcolsDelim.get())==0;
			if (!(t12.get())) goto _7;
		}
		{
			Txt t13;
			c.f.fLine=40;
			if (g->Call(ctx,(PCV[]){t13.cv(),Long(9).cv()},1,90)) goto _0;
			if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),t13.cv())) goto _0;
		}
		goto _5;
_7:
		{
			Bool t14;
			t14=g->CompareString(ctx,ltImportSetting.get(),KrowsDelim.get())==0;
			if (!(t14.get())) goto _8;
		}
		{
			Bool t15;
			c.f.fLine=44;
			if (g->Call(ctx,(PCV[]){t15.cv()},0,1572)) goto _0;
			if (!(t15.get())) goto _10;
		}
		{
			Txt t16;
			c.f.fLine=45;
			if (g->Call(ctx,(PCV[]){t16.cv(),Long(13).cv()},1,90)) goto _0;
			if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),t16.cv())) goto _0;
		}
		liBreakmode=3;
		goto _9;
_10:
		{
			Bool t17;
			c.f.fLine=48;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1573)) goto _0;
			if (!(t17.get())) goto _11;
		}
		{
			Txt t18;
			c.f.fLine=49;
			if (g->Call(ctx,(PCV[]){t18.cv(),Long(13).cv()},1,90)) goto _0;
			Txt t19;
			if (g->Call(ctx,(PCV[]){t19.cv(),Long(10).cv()},1,90)) goto _0;
			Txt t20;
			g->AddString(t18.get(),t19.get(),t20.get());
			if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),t20.cv())) goto _0;
		}
		liBreakmode=2;
		goto _9;
_11:
		{
			Txt t21;
			c.f.fLine=54;
			if (g->Call(ctx,(PCV[]){t21.cv(),Long(10).cv()},1,90)) goto _0;
			if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),t21.cv())) goto _0;
		}
		liBreakmode=4;
_9:
		goto _5;
_8:
		{
			Bool t22;
			t22=g->CompareString(ctx,ltImportSetting.get(),KcharSet.get())==0;
			if (!(t22.get())) goto _12;
		}
		c.f.fLine=60;
		if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),Long(6).cv())) goto _0;
		goto _5;
_12:
		{
			Bool t23;
			t23=g->CompareString(ctx,ltImportSetting.get(),KcolumnsMap.get())==0;
			if (!(t23.get())) goto _13;
		}
		{
			Col t24;
			c.f.fLine=62;
			if (g->Call(ctx,(PCV[]){t24.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),t24.cv())) goto _0;
		}
		goto _5;
_13:
		{
			Bool t25;
			t25=g->CompareString(ctx,ltImportSetting.get(),KheaderRow.get())==0;
			if (!(t25.get())) goto _14;
		}
		c.f.fLine=65;
		if (g->SetMember(ctx,loTable.cv(),ltImportSetting.cv(),Long(1).cv())) goto _0;
		goto _5;
_14:
_5:
_4:
		goto _2;
_3:
		{
			Obj t26;
			l__4D__auto__iter__0=t26.get();
		}
		{
			Variant t27;
			c.f.fLine=72;
			if (g->GetMember(ctx,loTable.cv(),Kfile2Import.cv(),t27.cv())) goto _0;
			Variant t28;
			if (g->GetMember(ctx,loTable.cv(),KcharSet.cv(),t28.cv())) goto _0;
			Txt t29;
			if (!g->GetValue(ctx,(PCV[]){t29.cv(),t27.cv(),nullptr})) goto _0;
			Txt t30;
			if (g->Call(ctx,(PCV[]){t30.cv(),t29.cv(),t28.cv(),liBreakmode.cv()},3,1236)) goto _0;
			g->Check(ctx);
			ltFile=t30.get();
		}
		{
			Bool t31;
			t31=g->CompareString(ctx,ltFile.get(),K.get())!=0;
			if (!(t31.get())) goto _15;
		}
		{
			Variant t32;
			c.f.fLine=75;
			if (g->GetMember(ctx,loTable.cv(),KcolumnsMap.cv(),t32.cv())) goto _0;
			Variant t33;
			if (g->GetMember(ctx,t32.cv(),Klength.cv(),t33.cv())) goto _0;
			Bool t34;
			if (g->OperationOnAny(ctx,5,t33.cv(),Num(0).cv(),t34.cv())) goto _0;
			if (!(t34.get())) goto _16;
		}
		{
			Variant t35;
			c.f.fLine=76;
			if (g->GetMember(ctx,loTable.cv(),KrowsDelim.cv(),t35.cv())) goto _0;
			Txt t36;
			if (!g->GetValue(ctx,(PCV[]){t36.cv(),t35.cv(),nullptr})) goto _0;
			Col t37;
			if (g->Call(ctx,(PCV[]){t37.cv(),ltFile.cv(),t36.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolFileRows=t37.get();
		}
		{
			Variant t38;
			c.f.fLine=77;
			if (g->Call(ctx,(PCV[]){t38.cv(),lcolFileRows.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t39;
			if (g->OperationOnAny(ctx,5,t38.cv(),Num(0).cv(),t39.cv())) goto _0;
			if (!(t39.get())) goto _17;
		}
		{
			Variant t40;
			c.f.fLine=80;
			if (g->GetMember(ctx,loTable.cv(),KheaderRow.cv(),t40.cv())) goto _0;
			Bool t41;
			if (g->OperationOnAny(ctx,5,t40.cv(),Num(0).cv(),t41.cv())) goto _0;
			if (!(t41.get())) goto _18;
		}
		{
			Variant t42;
			c.f.fLine=81;
			if (g->GetMember(ctx,loTable.cv(),KheaderRow.cv(),t42.cv())) goto _0;
			Variant t43;
			if (g->OperationOnAny(ctx,1,t42.cv(),Num(1).cv(),t43.cv())) goto _0;
			Variant t44;
			if (g->GetMember(ctx,lcolFileRows.cv(),t43.cv(),t44.cv())) goto _0;
			Variant t45;
			if (g->GetMember(ctx,loTable.cv(),KcolsDelim.cv(),t45.cv())) goto _0;
			Txt t46;
			if (!g->GetValue(ctx,(PCV[]){t46.cv(),t45.cv(),nullptr})) goto _0;
			Txt t47;
			if (!g->GetValue(ctx,(PCV[]){t47.cv(),t44.cv(),nullptr})) goto _0;
			Col t48;
			if (g->Call(ctx,(PCV[]){t48.cv(),t47.cv(),t46.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolRowValues=t48.get();
		}
		{
			Variant t49;
			c.f.fLine=82;
			if (g->GetMember(ctx,loTable.cv(),KcolumnsMap.cv(),t49.cv())) goto _0;
			Ref t50;
			t50.setLocalRef(ctx,loColumn.cv());
			Obj t51;
			if (g->Call(ctx,(PCV[]){t51.cv(),t50.cv(),t49.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t51.get();
		}
_19:
		{
			Bool t52;
			if (g->Call(ctx,(PCV[]){t52.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t52.get())) goto _20;
		}
		{
			Variant t53;
			c.f.fLine=83;
			if (g->GetMember(ctx,loColumn.cv(),Kname.cv(),t53.cv())) goto _0;
			Variant t54;
			if (g->Call(ctx,(PCV[]){t54.cv(),lcolRowValues.cv(),KindexOf.cv(),t53.cv()},3,1498)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loColumn.cv(),Kindx.cv(),t54.cv())) goto _0;
		}
		goto _19;
_20:
		{
			Obj t55;
			l__4D__auto__iter__1=t55.get();
		}
_18:
		{
			Time t56;
			c.f.fLine=89;
			if (g->Call(ctx,(PCV[]){t56.cv(),Ref((optyp)3).cv()},1,178)) goto _0;
			lhStart=t56.get();
		}
		liRow=0;
		{
			Variant t57;
			c.f.fLine=91;
			if (g->GetMember(ctx,loTable.cv(),KheaderRow.cv(),t57.cv())) goto _0;
			Ref t58;
			t58.setLocalRef(ctx,lcolRow.cv());
			Obj t59;
			if (g->Call(ctx,(PCV[]){t59.cv(),t58.cv(),lcolFileRows.cv(),t57.cv()},3,1795)) goto _0;
			l__4D__auto__iter__3=t59.get();
		}
_21:
		{
			Bool t60;
			if (g->Call(ctx,(PCV[]){t60.cv(),l__4D__auto__iter__3.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t60.get())) goto _22;
		}
		liRow=liRow.get()+1;
		{
			Obj t62;
			c.f.fLine=95;
			if (g->Call(ctx,(PCV[]){t62.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loRow=t62.get();
		}
		{
			Variant t63;
			c.f.fLine=96;
			if (g->GetMember(ctx,loTable.cv(),KcolsDelim.cv(),t63.cv())) goto _0;
			Txt t64;
			if (!g->GetValue(ctx,(PCV[]){t64.cv(),t63.cv(),nullptr})) goto _0;
			Col t65;
			if (g->Call(ctx,(PCV[]){t65.cv(),lcolRow.cv(),t64.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolRowValues=t65.get();
		}
		{
			Variant t66;
			c.f.fLine=97;
			if (g->Call(ctx,(PCV[]){t66.cv(),lcolRowValues.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t67;
			if (g->GetMember(ctx,loTable.cv(),KcolumnsMap.cv(),t67.cv())) goto _0;
			Variant t68;
			if (g->Call(ctx,(PCV[]){t68.cv(),t67.cv(),Kmax.cv(),Kindx.cv()},3,1498)) goto _0;
			Bool t69;
			if (g->OperationOnAny(ctx,5,t66.cv(),t68.cv(),t69.cv())) goto _0;
			if (!(t69.get())) goto _23;
		}
		{
			Variant t70;
			c.f.fLine=98;
			if (g->GetMember(ctx,loTable.cv(),KcolumnsMap.cv(),t70.cv())) goto _0;
			Ref t71;
			t71.setLocalRef(ctx,loColumn.cv());
			Obj t72;
			if (g->Call(ctx,(PCV[]){t72.cv(),t71.cv(),t70.cv()},2,1795)) goto _0;
			l__4D__auto__iter__2=t72.get();
		}
_24:
		{
			Bool t73;
			if (g->Call(ctx,(PCV[]){t73.cv(),l__4D__auto__iter__2.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t73.get())) goto _25;
		}
		{
			Variant t74;
			c.f.fLine=99;
			if (g->GetMember(ctx,loColumn.cv(),Kindx.cv(),t74.cv())) goto _0;
			Bool t75;
			if (g->OperationOnAny(ctx,12,t74.cv(),Num(0).cv(),t75.cv())) goto _0;
			if (!(t75.get())) goto _26;
		}
		{
			Variant t76;
			c.f.fLine=101;
			if (g->GetMember(ctx,loColumn.cv(),Ktype.cv(),t76.cv())) goto _0;
			Bool t77;
			if (g->OperationOnAny(ctx,6,t76.cv(),Long(4).cv(),t77.cv())) goto _0;
			if (!(t77.get())) goto _28;
		}
		{
			Variant t78;
			c.f.fLine=102;
			if (g->GetMember(ctx,loColumn.cv(),Kname.cv(),t78.cv())) goto _0;
			Variant t79;
			if (g->GetMember(ctx,loColumn.cv(),Kindx.cv(),t79.cv())) goto _0;
			Variant t80;
			if (g->GetMember(ctx,lcolRowValues.cv(),t79.cv(),t80.cv())) goto _0;
			Date t81;
			if (g->Call(ctx,(PCV[]){t81.cv(),t80.cv()},1,102)) goto _0;
			Date t82;
			t82=t81.get();
			if (g->SetMember(ctx,loRow.cv(),t78.cv(),t82.cv())) goto _0;
		}
		goto _27;
_28:
		{
			Variant t83;
			c.f.fLine=104;
			if (g->GetMember(ctx,loColumn.cv(),Ktype.cv(),t83.cv())) goto _0;
			Bool t84;
			if (g->OperationOnAny(ctx,6,t83.cv(),Long(6).cv(),t84.cv())) goto _0;
			if (!(t84.get())) goto _29;
		}
		{
			Variant t85;
			c.f.fLine=105;
			if (g->GetMember(ctx,loColumn.cv(),Kname.cv(),t85.cv())) goto _0;
			Variant t86;
			if (g->GetMember(ctx,loColumn.cv(),Kindx.cv(),t86.cv())) goto _0;
			Variant t87;
			if (g->GetMember(ctx,lcolRowValues.cv(),t86.cv(),t87.cv())) goto _0;
			Bool t88;
			if (g->OperationOnAny(ctx,6,t87.cv(),KTRUE.cv(),t88.cv())) goto _0;
			Bool t89;
			t89=Bool(0).get();
			Bool t90;
			t90=Bool(1).get();
			Bool t91;
			t91=t88.get();
			Variant t92;
			if (g->Call(ctx,(PCV[]){t92.cv(),t91.cv(),t90.cv(),t89.cv()},3,955)) goto _0;
			if (g->SetMember(ctx,loRow.cv(),t85.cv(),t92.cv())) goto _0;
		}
		goto _27;
_29:
		{
			Variant t93;
			c.f.fLine=107;
			if (g->GetMember(ctx,loColumn.cv(),Ktype.cv(),t93.cv())) goto _0;
			Bool t94;
			if (g->OperationOnAny(ctx,6,t93.cv(),Long(9).cv(),t94.cv())) goto _0;
			Variant t95;
			if (g->GetMember(ctx,loColumn.cv(),Ktype.cv(),t95.cv())) goto _0;
			Bool t96;
			if (g->OperationOnAny(ctx,6,t95.cv(),Long(1).cv(),t96.cv())) goto _0;
			Bool t97;
			t97=t94.get()||t96.get();
			if (!(t97.get())) goto _30;
		}
		{
			Variant t98;
			c.f.fLine=108;
			if (g->GetMember(ctx,loColumn.cv(),Kname.cv(),t98.cv())) goto _0;
			Variant t99;
			if (g->GetMember(ctx,loColumn.cv(),Kindx.cv(),t99.cv())) goto _0;
			Variant t100;
			if (g->GetMember(ctx,lcolRowValues.cv(),t99.cv(),t100.cv())) goto _0;
			Num t101;
			if (g->Call(ctx,(PCV[]){t101.cv(),t100.cv()},1,11)) goto _0;
			if (g->SetMember(ctx,loRow.cv(),t98.cv(),t101.cv())) goto _0;
		}
		goto _27;
_30:
		{
			Variant t102;
			c.f.fLine=111;
			if (g->GetMember(ctx,loColumn.cv(),Kname.cv(),t102.cv())) goto _0;
			Variant t103;
			if (g->GetMember(ctx,loColumn.cv(),Kindx.cv(),t103.cv())) goto _0;
			Variant t104;
			if (g->GetMember(ctx,lcolRowValues.cv(),t103.cv(),t104.cv())) goto _0;
			if (g->SetMember(ctx,loRow.cv(),t102.cv(),t104.cv())) goto _0;
		}
_27:
_26:
		goto _24;
_25:
		{
			Obj t105;
			l__4D__auto__iter__2=t105.get();
		}
		c.f.fLine=117;
		if (g->Call(ctx,(PCV[]){nullptr,lcolImportedRows.cv(),Kpush.cv(),loRow.cv()},3,1500)) goto _0;
		g->Check(ctx);
_23:
		goto _21;
_22:
		{
			Obj t106;
			l__4D__auto__iter__3=t106.get();
		}
		c.f.fLine=124;
		if (g->SetMember(ctx,loTable.cv(),Kresult.cv(),KOK.cv())) goto _0;
		{
			Variant t107;
			c.f.fLine=125;
			if (g->Call(ctx,(PCV[]){t107.cv(),lcolImportedRows.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loTable.cv(),KtotalRows.cv(),t107.cv())) goto _0;
		}
		goto _31;
_17:
		c.f.fLine=128;
		if (g->SetMember(ctx,loTable.cv(),Kresult.cv(),kOJqFOvTiTzk.cv())) goto _0;
_31:
		goto _32;
_16:
		c.f.fLine=131;
		if (g->SetMember(ctx,loTable.cv(),Kresult.cv(),kY6jJBKNw4xE.cv())) goto _0;
_32:
		goto _33;
_15:
		{
			Variant t108;
			c.f.fLine=134;
			if (g->GetMember(ctx,loTable.cv(),KfilePath.cv(),t108.cv())) goto _0;
			Variant t109;
			if (g->OperationOnAny(ctx,0,k99ZvUtw5fTk.cv(),t108.cv(),t109.cv())) goto _0;
			if (g->SetMember(ctx,loTable.cv(),Kresult.cv(),t109.cv())) goto _0;
		}
_33:
_0:
_1:
;
	}

}
