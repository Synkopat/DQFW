extern Txt KMovies;
Asm4d_Proc proc_DQFW__QUERYTABLE;
extern unsigned char D_proc_TEST__QUERYFORM[];
void proc_TEST__QUERYFORM( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_TEST__QUERYFORM);
	if (!ctx->doingAbort) {
		{
			Obj t0;
			c.f.fLine=1;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1482)) goto _0;
			Variant t1;
			if (g->Call(ctx,(PCV[]){t1.cv(),t0.cv(),KMovies.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Col t2;
			Obj t3;
			if (!g->GetValue(ctx,(PCV[]){t3.cv(),t1.cv(),nullptr})) goto _0;
			Obj t4;
			proc_DQFW__QUERYTABLE(glob,ctx,1,2,(PCV[]){t3.cv(),t2.cv()},t4.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
_0:
_1:
;
	}

}
