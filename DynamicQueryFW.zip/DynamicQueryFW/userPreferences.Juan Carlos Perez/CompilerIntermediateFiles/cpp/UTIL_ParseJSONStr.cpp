extern int32_t vERROR__tErrorMessage;
extern Txt K;
extern Txt KERROR__Handler;
extern Txt KbSuccess;
extern Txt KcolCollection;
extern Txt KoObject;
extern Txt KtError;
extern Txt Kundefined;
extern Txt keYpYHsodZMQ;
extern unsigned char D_proc_UTIL__PARSEJSONSTR[];
void proc_UTIL__PARSEJSONSTR( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_UTIL__PARSEJSONSTR);
	if (!ctx->doingAbort) {
		Txt ltJSONString;
		Txt ltResult;
		Long liType;
		Bool lJCPEREZ__20241102;
		Obj loResult;
		new ( outResult) Obj();
		c.f.fLine=15;
		ltJSONString=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		liType=38;
		{
			Obj t0;
			loResult=t0.get();
		}
		{
			Long t1;
			t1=inNbExplicitParam;
			if (2>t1.get()) goto _2;
		}
		c.f.fLine=20;
		liType=Parm<Long>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
_2:
		{
			Obj t3;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t3.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loResult=t3.get();
		}
		c.f.fLine=26;
		if (g->Call(ctx,(PCV[]){nullptr,KERROR__Handler.cv()},1,155)) goto _0;
		g->Check(ctx);
		{
			Variant t4;
			c.f.fLine=28;
			if (g->Call(ctx,(PCV[]){t4.cv(),ltJSONString.cv(),liType.cv()},2,1218)) goto _0;
			g->Check(ctx);
			Txt t5;
			if (g->Call(ctx,(PCV[]){t5.cv(),t4.cv()},1,1217)) goto _0;
			ltResult=t5.get();
		}
		{
			Bool t6;
			t6=g->CompareString(ctx,ltResult.get(),K.get())==0;
			Bool t7;
			t7=g->CompareString(ctx,ltResult.get(),Kundefined.get())==0;
			if (!( t6.get()||t7.get())) goto _3;
		}
		{
			Bool t9;
			t9=Bool(0).get();
			c.f.fLine=31;
			if (g->SetMember(ctx,loResult.cv(),KbSuccess.cv(),t9.cv())) goto _0;
		}
		{
			Txt t10;
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){t10.cv()},0,684)) goto _0;
			g->Check(ctx);
			Txt t11;
			g->AddString(t10.get(),keYpYHsodZMQ.get(),t11.get());
			Txt t12;
			g->AddString(t11.get(),Var<Txt>(ctx,vERROR__tErrorMessage).get(),t12.get());
			if (g->SetMember(ctx,loResult.cv(),KtError.cv(),t12.cv())) goto _0;
		}
		goto _4;
_3:
		{
			Bool t13;
			t13=Bool(1).get();
			c.f.fLine=35;
			if (g->SetMember(ctx,loResult.cv(),KbSuccess.cv(),t13.cv())) goto _0;
		}
		if (38!=liType.get()) goto _6;
		{
			Variant t15;
			c.f.fLine=39;
			if (g->Call(ctx,(PCV[]){t15.cv(),ltJSONString.cv(),liType.cv()},2,1218)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loResult.cv(),KoObject.cv(),t15.cv())) goto _0;
		}
		goto _5;
_6:
		if (42!=liType.get()) goto _7;
		{
			Variant t17;
			c.f.fLine=42;
			if (g->Call(ctx,(PCV[]){t17.cv(),ltJSONString.cv(),liType.cv()},2,1218)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loResult.cv(),KcolCollection.cv(),t17.cv())) goto _0;
		}
		goto _5;
_7:
		{
			Variant t18;
			t18.setNull();
			c.f.fLine=45;
			if (g->SetMember(ctx,loResult.cv(),KcolCollection.cv(),t18.cv())) goto _0;
		}
		{
			Variant t19;
			t19.setNull();
			c.f.fLine=46;
			if (g->SetMember(ctx,loResult.cv(),KoObject.cv(),t19.cv())) goto _0;
		}
_5:
_4:
		c.f.fLine=52;
		Res<Obj>(outResult)=loResult.get();
		c.f.fLine=54;
		if (g->Call(ctx,(PCV[]){nullptr,K.cv()},1,155)) goto _0;
		g->Check(ctx);
_0:
_1:
;
	}

}
