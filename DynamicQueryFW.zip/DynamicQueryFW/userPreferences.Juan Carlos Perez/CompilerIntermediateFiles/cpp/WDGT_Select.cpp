extern int32_t vOK;
extern Txt KSelect_20an_20Item;
extern Txt KSelection_20List;
extern Txt KSingle;
extern Txt KbAutoComplete;
extern Txt KbHidden_20_3D_20_3A1;
extern Txt KcolLBSetup;
extern Txt KcolListItems;
extern Txt Kcopy;
extern Txt KiItemIndx;
extern Txt KiWidth;
extern Txt KiWinRef;
extern Txt Klength;
extern Txt KoItem;
extern Txt Kpush;
extern Txt Kquery;
extern Txt Ksum;
extern Txt KtFormHeader;
extern Txt KtSelectionMode;
extern Txt kMzsyXlqrMYY;
extern Txt klQSV4ZoYWzw;
Asm4d_Proc proc_UTIL__SETOBJVALUES;
Asm4d_Proc proc_WIND__OPENWINDOW;
extern unsigned char D_proc_WDGT__SELECT[];
void proc_WDGT__SELECT( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_WDGT__SELECT);
	if (!ctx->doingAbort) {
		Obj loListSetup;
		Col lcolSelected;
		Txt ltForm;
		Long liFormHeight;
		Long liFormWidth;
		Obj loWDGTSelectForm;
		Bool lJCPEREZ__20241102;
		new ( outResult) Col();
		c.f.fLine=14;
		loListSetup=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Col t0;
			c.f.fLine=15;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolSelected=t0.get();
		}
		ltForm=kMzsyXlqrMYY.get();
		{
			Ref t1;
			t1.setLocalRef(ctx,liFormHeight.cv());
			Ref t2;
			t2.setLocalRef(ctx,liFormWidth.cv());
			c.f.fLine=20;
			if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),t2.cv(),t1.cv()},3,674)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t3;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t3.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loWDGTSelectForm=t3.get();
		}
		{
			Col t4;
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){t4.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),KcolLBSetup.cv(),t4.cv())) goto _0;
		}
		c.f.fLine=27;
		if (g->SetMember(ctx,loWDGTSelectForm.cv(),KtFormHeader.cv(),KSelect_20an_20Item.cv())) goto _0;
		c.f.fLine=28;
		if (g->SetMember(ctx,loWDGTSelectForm.cv(),KtSelectionMode.cv(),KSingle.cv())) goto _0;
		{
			Col t5;
			c.f.fLine=29;
			if (g->Call(ctx,(PCV[]){t5.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),KcolListItems.cv(),t5.cv())) goto _0;
		}
		{
			Col t6;
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){t6.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),KcolListItems.cv(),t6.cv())) goto _0;
		}
		{
			Bool t7;
			t7=Bool(0).get();
			c.f.fLine=31;
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),KbAutoComplete.cv(),t7.cv())) goto _0;
		}
		{
			Obj t8;
			t8=loListSetup.get();
			Obj t9;
			t9=loWDGTSelectForm.get();
			c.f.fLine=33;
			proc_UTIL__SETOBJVALUES(glob,ctx,2,2,(PCV[]){t9.cv(),t8.cv()},nullptr);
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
		}
		{
			Variant t10;
			c.f.fLine=35;
			if (g->GetMember(ctx,loWDGTSelectForm.cv(),KcolListItems.cv(),t10.cv())) goto _0;
			Variant t11;
			if (g->GetMember(ctx,t10.cv(),Klength.cv(),t11.cv())) goto _0;
			Bool t12;
			if (g->OperationOnAny(ctx,5,t11.cv(),Num(0).cv(),t12.cv())) goto _0;
			if (!(t12.get())) goto _2;
		}
		{
			Obj t13;
			c.f.fLine=36;
			if (g->Call(ctx,(PCV[]){t13.cv()},0,1471)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),KoItem.cv(),t13.cv())) goto _0;
		}
		{
			Variant t14;
			c.f.fLine=37;
			if (g->GetMember(ctx,loWDGTSelectForm.cv(),KcolListItems.cv(),t14.cv())) goto _0;
			Variant t15;
			if (g->GetMember(ctx,t14.cv(),Long(0).cv(),t15.cv())) goto _0;
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),KoItem.cv(),t15.cv())) goto _0;
		}
		c.f.fLine=38;
		if (g->SetMember(ctx,loWDGTSelectForm.cv(),KiItemIndx.cv(),Long(1).cv())) goto _0;
		{
			Col t16;
			c.f.fLine=39;
			if (g->Call(ctx,(PCV[]){t16.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),klQSV4ZoYWzw.cv(),t16.cv())) goto _0;
		}
		{
			Variant t17;
			c.f.fLine=40;
			if (g->GetMember(ctx,loWDGTSelectForm.cv(),klQSV4ZoYWzw.cv(),t17.cv())) goto _0;
			Variant t18;
			if (g->GetMember(ctx,loWDGTSelectForm.cv(),KoItem.cv(),t18.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t17.cv(),Kpush.cv(),t18.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
		{
			Variant t19;
			c.f.fLine=42;
			if (g->GetMember(ctx,loWDGTSelectForm.cv(),KcolLBSetup.cv(),t19.cv())) goto _0;
			Bool t20;
			t20=Bool(0).get();
			Variant t21;
			if (g->Call(ctx,(PCV[]){t21.cv(),t19.cv(),Kquery.cv(),KbHidden_20_3D_20_3A1.cv(),t20.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Variant t22;
			if (g->Call(ctx,(PCV[]){t22.cv(),t21.cv(),Ksum.cv(),KiWidth.cv()},3,1498)) goto _0;
			Long t23;
			if (!g->GetValue(ctx,(PCV[]){t23.cv(),t22.cv(),nullptr})) goto _0;
			liFormWidth=t23.get();
		}
_2:
		{
			Ptr t24;
			Txt t25;
			t25=ltForm.get();
			Txt t26;
			t26=KSelection_20List.get();
			Long t27;
			t27=33;
			Long t28;
			t28=11;
			Long t29;
			t29=liFormHeight.get();
			Long t30;
			t30=liFormWidth.get();
			Long t31;
			c.f.fLine=47;
			proc_WIND__OPENWINDOW(glob,ctx,6,7,(PCV[]){t30.cv(),t29.cv(),t28.cv(),t27.cv(),t26.cv(),t25.cv(),t24.cv()},t31.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loWDGTSelectForm.cv(),KiWinRef.cv(),t31.cv())) goto _0;
		}
		c.f.fLine=48;
		if (g->Call(ctx,(PCV[]){nullptr,ltForm.cv(),loWDGTSelectForm.cv()},2,40)) goto _0;
		g->Check(ctx);
		if (1!=Var<Long>(ctx,vOK).get()) goto _3;
		{
			Variant t33;
			c.f.fLine=51;
			if (g->GetMember(ctx,loWDGTSelectForm.cv(),klQSV4ZoYWzw.cv(),t33.cv())) goto _0;
			Variant t34;
			if (g->Call(ctx,(PCV[]){t34.cv(),t33.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Col t35;
			if (!g->GetValue(ctx,(PCV[]){t35.cv(),t34.cv(),nullptr})) goto _0;
			lcolSelected=t35.get();
		}
_3:
		c.f.fLine=54;
		Res<Col>(outResult)=lcolSelected.get();
_0:
_1:
;
	}

}
