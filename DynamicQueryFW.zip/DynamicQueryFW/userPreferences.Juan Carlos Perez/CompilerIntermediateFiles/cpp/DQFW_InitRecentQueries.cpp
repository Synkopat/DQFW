extern Txt KDBAliases;
extern Txt KDataClass;
extern Txt KObjectName;
extern Txt KcolRQ;
extern Txt Kquery;
extern Txt kohe2eiRGiCQ;
extern unsigned char D_proc_DQFW__INITRECENTQUERIES[];
void proc_DQFW__INITRECENTQUERIES( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__INITRECENTQUERIES);
	if (!ctx->doingAbort) {
		Obj lesQueryTables;
		Obj l__4D__auto__iter__0;
		Obj leQueryTable;
		Obj l__4D__auto__mutex__0;
		Bool lJCPEREZ__20241102;
		Col lcolGamesRecentQueries;
		{
			Col t0;
			c.f.fLine=18;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolGamesRecentQueries=t0.get();
		}
		{
			Obj t1;
			c.f.fLine=19;
			if (g->Call(ctx,(PCV[]){t1.cv()},0,1482)) goto _0;
			Variant t2;
			if (g->Call(ctx,(PCV[]){t2.cv(),t1.cv(),KDBAliases.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t3;
			t3=Bool(1).get();
			Variant t4;
			if (g->Call(ctx,(PCV[]){t4.cv(),t2.cv(),Kquery.cv(),kohe2eiRGiCQ.cv(),KDataClass.cv(),t3.cv()},5,1498)) goto _0;
			Obj t5;
			if (!g->GetValue(ctx,(PCV[]){t5.cv(),t4.cv(),nullptr})) goto _0;
			lesQueryTables=t5.get();
		}
		{
			Ref t6;
			t6.setLocalRef(ctx,leQueryTable.cv());
			Obj t7;
			c.f.fLine=21;
			if (g->Call(ctx,(PCV[]){t7.cv(),t6.cv(),lesQueryTables.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t7.get();
		}
_2:
		{
			Bool t8;
			if (g->Call(ctx,(PCV[]){t8.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t8.get())) goto _3;
		}
		{
			Obj t9;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t9.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t10;
			if (g->GetMember(ctx,leQueryTable.cv(),KObjectName.cv(),t10.cv())) goto _0;
			Variant t11;
			if (g->OperationOnAny(ctx,0,KcolRQ.cv(),t10.cv(),t11.cv())) goto _0;
			Txt t12;
			if (!g->GetValue(ctx,(PCV[]){t12.cv(),t11.cv(),nullptr})) goto _0;
			Variant t13;
			if (g->GetMember(ctx,t9.cv(),t12.cv(),t13.cv())) goto _0;
			Bool t14;
			if (g->OperationOnAny(ctx,6,t13.cv(),Value_null().cv(),t14.cv())) goto _0;
			if (!(t14.get())) goto _4;
		}
		{
			Obj t15;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t15.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Obj t16;
			if (g->Call(ctx,(PCV[]){t16.cv(),t15.cv()},1,1529)) goto _0;
			l__4D__auto__mutex__0=t16.get();
		}
		{
			Obj t17;
			c.f.fLine=25;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t18;
			if (g->GetMember(ctx,leQueryTable.cv(),KObjectName.cv(),t18.cv())) goto _0;
			Variant t19;
			if (g->OperationOnAny(ctx,0,KcolRQ.cv(),t18.cv(),t19.cv())) goto _0;
			Col t20;
			if (g->Call(ctx,(PCV[]){t20.cv()},0,1527)) goto _0;
			Txt t21;
			if (!g->GetValue(ctx,(PCV[]){t21.cv(),t19.cv(),nullptr})) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,t17.cv(),t21.cv(),t20.cv()},3,1497)) goto _0;
		}
		{
			Obj t22;
			l__4D__auto__mutex__0=t22.get();
		}
_4:
		goto _2;
_3:
		{
			Obj t23;
			l__4D__auto__iter__0=t23.get();
		}
_0:
_1:
;
	}

}
