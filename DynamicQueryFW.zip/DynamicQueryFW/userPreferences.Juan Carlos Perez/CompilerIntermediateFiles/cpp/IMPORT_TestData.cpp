extern Txt KAccept;
extern Txt KCOMPANY__ID;
extern Txt KCompanies;
extern Txt KCountries;
extern Txt KCountryOfOrigin;
extern Txt KCountry__ISO2;
extern Txt KDONE;
extern Txt KEngName;
extern Txt KEngOverview;
extern Txt KGenres;
extern Txt KMovieID;
extern Txt KMovies;
extern Txt KName;
extern Txt KOriginalTitle;
extern Txt KProducers;
extern Txt KRating;
extern Txt KReleaseDate;
extern Txt KRuntime;
extern Txt KTMDB__ID;
extern Txt KTMDB__ID_20_3D_20_3A1;
extern Txt KTitle;
extern Txt K_7C;
extern Txt Kdistinct;
extern Txt Kfirst;
extern Txt Kgenres;
extern Txt Kid;
extern Txt Kiso__3166__1;
extern Txt Kjoin;
extern Txt Klength;
extern Txt Kname;
extern Txt Knew;
extern Txt KoObject;
extern Txt Koriginal__title;
extern Txt Koverview;
extern Txt Kquery;
extern Txt Krelease__date;
extern Txt Kruntime;
extern Txt Ksave;
extern Txt Ksuccess;
extern Txt Ktitle;
extern Txt Kvote__average;
extern Txt k0Y5ZI0AruYM;
extern Txt kA3$zPm7Wdtc;
extern Txt kFft24fqABwU;
extern Txt kTPKCwQqjmqo;
extern Txt knT_OmB8KgS4;
extern Txt kqDYe8_Lb36A;
extern Txt kyB6TMG4mH1Q;
Asm4d_Proc proc_UTIL__PARSEJSONSTR;
extern unsigned char D_proc_IMPORT__TESTDATA[];
void proc_IMPORT__TESTDATA( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_IMPORT__TESTDATA);
	if (!ctx->doingAbort) {
		Long v0;
		Variant loCountry;
		Long v1;
		Obj leCountry;
		Long li;
		Obj leCompany;
		Obj lesCompanies;
		Variant loProducer;
		Obj l__4D__auto__iter__0;
		Obj l__4D__auto__iter__1;
		Value_array_text laHeaderName;
		Long lHTTPStatusCode;
		Txt lresponse;
		Obj lesMovies;
		Obj leCOO;
		Txt ltURL;
		Obj leMovie;
		Txt ltAuthURL;
		Blb loResponse;
		Variant loTestData;
		Obj lesCOOs;
		Bool lJCPEREZ__20241109;
		Obj lesProducers;
		Value_array_text laHeaderValue;
		Obj lesCountries;
		Obj leProducer;
		Variant loResult;
		lHTTPStatusCode=0;
		{
			Ref t0;
			t0.setLocalRef(ctx,laHeaderName.cv());
			c.f.fLine=26;
			if (g->Call(ctx,(PCV[]){nullptr,t0.cv(),Long(0).cv()},2,222)) goto _0;
		}
		{
			Ref t1;
			t1.setLocalRef(ctx,laHeaderValue.cv());
			c.f.fLine=27;
			if (g->Call(ctx,(PCV[]){nullptr,t1.cv(),Long(0).cv()},2,222)) goto _0;
		}
		ltAuthURL=kTPKCwQqjmqo.get();
		{
			Ref t2;
			t2.setLocalRef(ctx,laHeaderName.cv());
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){nullptr,t2.cv(),KAccept.cv()},2,911)) goto _0;
			g->Check(ctx);
		}
		{
			Ref t3;
			t3.setLocalRef(ctx,laHeaderValue.cv());
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){nullptr,t3.cv(),kA3$zPm7Wdtc.cv()},2,911)) goto _0;
			g->Check(ctx);
		}
		{
			Ref t4;
			t4.setLocalRef(ctx,laHeaderValue.cv());
			Ref t5;
			t5.setLocalRef(ctx,laHeaderName.cv());
			Ref t6;
			t6.setLocalRef(ctx,lresponse.cv());
			Long t7;
			c.f.fLine=36;
			if (g->Call(ctx,(PCV[]){t7.cv(),ltAuthURL.cv(),t6.cv(),t5.cv(),t4.cv()},4,1157)) goto _0;
			g->Check(ctx);
			lHTTPStatusCode=t7.get();
		}
		if (200!=lHTTPStatusCode.get()) goto _2;
		li=1;
		v0=1000;
		goto _3;
_5:
		{
			Txt t9;
			c.f.fLine=41;
			if (g->Call(ctx,(PCV[]){t9.cv(),li.cv()},1,10)) goto _0;
			Txt t10;
			g->AddString(k0Y5ZI0AruYM.get(),t9.get(),t10.get());
			g->AddString(t10.get(),kqDYe8_Lb36A.get(),ltURL.get());
		}
		{
			Ref t12;
			t12.setLocalRef(ctx,laHeaderValue.cv());
			Ref t13;
			t13.setLocalRef(ctx,laHeaderName.cv());
			Ref t14;
			t14.setLocalRef(ctx,lresponse.cv());
			Long t15;
			c.f.fLine=42;
			if (g->Call(ctx,(PCV[]){t15.cv(),ltURL.cv(),t14.cv(),t13.cv(),t12.cv()},4,1157)) goto _0;
			g->Check(ctx);
			lHTTPStatusCode=t15.get();
		}
		if (200!=lHTTPStatusCode.get()) goto _7;
		{
			Long t17;
			t17=0;
			Txt t18;
			t18=lresponse.get();
			Obj t19;
			c.f.fLine=45;
			proc_UTIL__PARSEJSONSTR(glob,ctx,1,2,(PCV[]){t18.cv(),t17.cv()},t19.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t20;
			if (g->GetMember(ctx,t19.cv(),KoObject.cv(),t20.cv())) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t20.cv(),loTestData.cv(),nullptr})) goto _0;
		}
		{
			Obj t21;
			c.f.fLine=46;
			if (g->Call(ctx,(PCV[]){t21.cv()},0,1482)) goto _0;
			Variant t22;
			if (g->Call(ctx,(PCV[]){t22.cv(),t21.cv(),KMovies.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t23;
			if (g->Call(ctx,(PCV[]){t23.cv(),t22.cv(),Kquery.cv(),KTMDB__ID_20_3D_20_3A1.cv(),li.cv()},4,1498)) goto _0;
			Obj t24;
			if (!g->GetValue(ctx,(PCV[]){t24.cv(),t23.cv(),nullptr})) goto _0;
			lesMovies=t24.get();
		}
		{
			Variant t25;
			c.f.fLine=48;
			if (g->GetMember(ctx,lesMovies.cv(),Klength.cv(),t25.cv())) goto _0;
			Bool t26;
			if (g->OperationOnAny(ctx,6,t25.cv(),Num(0).cv(),t26.cv())) goto _0;
			if (!(t26.get())) goto _8;
		}
		{
			Obj t27;
			c.f.fLine=50;
			if (g->Call(ctx,(PCV[]){t27.cv()},0,1482)) goto _0;
			Variant t28;
			if (g->Call(ctx,(PCV[]){t28.cv(),t27.cv(),KMovies.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t29;
			if (g->Call(ctx,(PCV[]){t29.cv(),t28.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t30;
			if (!g->GetValue(ctx,(PCV[]){t30.cv(),t29.cv(),nullptr})) goto _0;
			leMovie=t30.get();
		}
		{
			Variant t31;
			c.f.fLine=51;
			if (!g->GetValue(ctx,(PCV[]){t31.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t32;
			if (g->Call(ctx,(PCV[]){t32.cv(),t31.cv(),Koverview.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leMovie.cv(),KEngOverview.cv(),t32.cv())) goto _0;
		}
		{
			Variant t33;
			c.f.fLine=53;
			if (!g->GetValue(ctx,(PCV[]){t33.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t34;
			if (g->Call(ctx,(PCV[]){t34.cv(),t33.cv(),Kgenres.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Variant t35;
			if (g->GetMember(ctx,t34.cv(),Klength.cv(),t35.cv())) goto _0;
			Bool t36;
			if (g->OperationOnAny(ctx,5,t35.cv(),Num(0).cv(),t36.cv())) goto _0;
			if (!(t36.get())) goto _9;
		}
		{
			Variant t37;
			c.f.fLine=54;
			if (!g->GetValue(ctx,(PCV[]){t37.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t38;
			if (g->Call(ctx,(PCV[]){t38.cv(),t37.cv(),Kgenres.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Variant t39;
			if (g->Call(ctx,(PCV[]){t39.cv(),t38.cv(),Kdistinct.cv(),Kname.cv()},3,1498)) goto _0;
			Variant t40;
			if (g->Call(ctx,(PCV[]){t40.cv(),t39.cv(),Kjoin.cv(),K_7C.cv()},3,1498)) goto _0;
			if (g->SetMember(ctx,leMovie.cv(),KGenres.cv(),t40.cv())) goto _0;
		}
_9:
		{
			Variant t41;
			c.f.fLine=57;
			if (!g->GetValue(ctx,(PCV[]){t41.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t42;
			if (g->Call(ctx,(PCV[]){t42.cv(),t41.cv(),Koriginal__title.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leMovie.cv(),KOriginalTitle.cv(),t42.cv())) goto _0;
		}
		{
			Variant t43;
			c.f.fLine=58;
			if (!g->GetValue(ctx,(PCV[]){t43.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t44;
			if (g->Call(ctx,(PCV[]){t44.cv(),t43.cv(),Kvote__average.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leMovie.cv(),KRating.cv(),t44.cv())) goto _0;
		}
		{
			Variant t45;
			c.f.fLine=59;
			if (!g->GetValue(ctx,(PCV[]){t45.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t46;
			if (g->Call(ctx,(PCV[]){t46.cv(),t45.cv(),Krelease__date.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leMovie.cv(),KReleaseDate.cv(),t46.cv())) goto _0;
		}
		{
			Variant t47;
			c.f.fLine=60;
			if (!g->GetValue(ctx,(PCV[]){t47.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t48;
			if (g->Call(ctx,(PCV[]){t48.cv(),t47.cv(),Kruntime.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leMovie.cv(),KRuntime.cv(),t48.cv())) goto _0;
		}
		{
			Variant t49;
			c.f.fLine=61;
			if (!g->GetValue(ctx,(PCV[]){t49.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t50;
			if (g->Call(ctx,(PCV[]){t50.cv(),t49.cv(),Ktitle.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leMovie.cv(),KTitle.cv(),t50.cv())) goto _0;
		}
		{
			Variant t51;
			c.f.fLine=62;
			if (!g->GetValue(ctx,(PCV[]){t51.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t52;
			if (g->Call(ctx,(PCV[]){t52.cv(),t51.cv(),Kid.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leMovie.cv(),KTMDB__ID.cv(),t52.cv())) goto _0;
		}
		{
			Variant t53;
			c.f.fLine=64;
			if (g->Call(ctx,(PCV[]){t53.cv(),leMovie.cv(),Ksave.cv()},2,1498)) goto _0;
			g->Check(ctx);
			if (!g->SetValue(ctx,(PCV[]){t53.cv(),loResult.cv(),nullptr})) goto _0;
		}
		{
			Variant t54;
			c.f.fLine=66;
			if (!g->GetValue(ctx,(PCV[]){t54.cv(),loResult.cv(),nullptr})) goto _0;
			Variant t55;
			if (g->Call(ctx,(PCV[]){t55.cv(),t54.cv(),Ksuccess.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Bool t56;
			if (!g->GetValue(ctx,(PCV[]){t56.cv(),t55.cv(),nullptr})) goto _0;
			if (!(t56.get())) goto _10;
		}
		{
			Variant t57;
			c.f.fLine=68;
			if (!g->GetValue(ctx,(PCV[]){t57.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t58;
			if (g->Call(ctx,(PCV[]){t58.cv(),t57.cv(),knT_OmB8KgS4.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Variant t59;
			if (g->GetMember(ctx,t58.cv(),Klength.cv(),t59.cv())) goto _0;
			Bool t60;
			if (g->OperationOnAny(ctx,5,t59.cv(),Num(0).cv(),t60.cv())) goto _0;
			if (!(t60.get())) goto _11;
		}
		{
			Variant t61;
			c.f.fLine=69;
			if (!g->GetValue(ctx,(PCV[]){t61.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t62;
			if (g->Call(ctx,(PCV[]){t62.cv(),t61.cv(),knT_OmB8KgS4.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Ref t63;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t63.cv(),loProducer.cv(),nullptr})) goto _0;
			Obj t64;
			if (g->Call(ctx,(PCV[]){t64.cv(),t63.cv(),t62.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t64.get();
		}
_12:
		{
			Bool t65;
			if (g->Call(ctx,(PCV[]){t65.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			if (!(t65.get())) goto _13;
		}
		{
			Obj t66;
			c.f.fLine=70;
			if (g->Call(ctx,(PCV[]){t66.cv()},0,1482)) goto _0;
			Variant t67;
			if (g->Call(ctx,(PCV[]){t67.cv(),t66.cv(),KCompanies.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t68;
			if (!g->GetValue(ctx,(PCV[]){t68.cv(),loProducer.cv(),nullptr})) goto _0;
			Variant t69;
			if (g->Call(ctx,(PCV[]){t69.cv(),t68.cv(),Kid.cv()},2,1496)) goto _0;
			Variant t70;
			if (g->Call(ctx,(PCV[]){t70.cv(),t67.cv(),Kquery.cv(),KTMDB__ID_20_3D_20_3A1.cv(),t69.cv()},4,1498)) goto _0;
			Obj t71;
			if (!g->GetValue(ctx,(PCV[]){t71.cv(),t70.cv(),nullptr})) goto _0;
			lesCompanies=t71.get();
		}
		{
			Variant t72;
			c.f.fLine=71;
			if (g->GetMember(ctx,lesCompanies.cv(),Klength.cv(),t72.cv())) goto _0;
			Bool t73;
			if (g->OperationOnAny(ctx,6,t72.cv(),Num(0).cv(),t73.cv())) goto _0;
			if (!(t73.get())) goto _14;
		}
		{
			Obj t74;
			c.f.fLine=72;
			if (g->Call(ctx,(PCV[]){t74.cv()},0,1482)) goto _0;
			Variant t75;
			if (g->Call(ctx,(PCV[]){t75.cv(),t74.cv(),KCompanies.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t76;
			if (g->Call(ctx,(PCV[]){t76.cv(),t75.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t77;
			if (!g->GetValue(ctx,(PCV[]){t77.cv(),t76.cv(),nullptr})) goto _0;
			leCompany=t77.get();
		}
		{
			Variant t78;
			c.f.fLine=73;
			if (!g->GetValue(ctx,(PCV[]){t78.cv(),loProducer.cv(),nullptr})) goto _0;
			Variant t79;
			if (g->Call(ctx,(PCV[]){t79.cv(),t78.cv(),Kid.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leCompany.cv(),KTMDB__ID.cv(),t79.cv())) goto _0;
		}
		{
			Variant t80;
			c.f.fLine=74;
			if (!g->GetValue(ctx,(PCV[]){t80.cv(),loProducer.cv(),nullptr})) goto _0;
			Variant t81;
			if (g->Call(ctx,(PCV[]){t81.cv(),t80.cv(),Kname.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leCompany.cv(),KName.cv(),t81.cv())) goto _0;
		}
		c.f.fLine=75;
		if (g->Call(ctx,(PCV[]){nullptr,leCompany.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
		goto _15;
_14:
		{
			Variant t82;
			c.f.fLine=77;
			if (g->Call(ctx,(PCV[]){t82.cv(),lesCompanies.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t83;
			if (!g->GetValue(ctx,(PCV[]){t83.cv(),t82.cv(),nullptr})) goto _0;
			leCompany=t83.get();
		}
_15:
		{
			Obj t84;
			c.f.fLine=79;
			if (g->Call(ctx,(PCV[]){t84.cv()},0,1482)) goto _0;
			Variant t85;
			if (g->Call(ctx,(PCV[]){t85.cv(),t84.cv(),KProducers.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t86;
			if (g->Call(ctx,(PCV[]){t86.cv(),t85.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t87;
			if (!g->GetValue(ctx,(PCV[]){t87.cv(),t86.cv(),nullptr})) goto _0;
			leProducer=t87.get();
		}
		{
			Variant t88;
			c.f.fLine=80;
			if (g->GetMember(ctx,leCompany.cv(),KCOMPANY__ID.cv(),t88.cv())) goto _0;
			if (g->SetMember(ctx,leProducer.cv(),KCOMPANY__ID.cv(),t88.cv())) goto _0;
		}
		{
			Variant t89;
			c.f.fLine=81;
			if (g->GetMember(ctx,leMovie.cv(),KMovieID.cv(),t89.cv())) goto _0;
			if (g->SetMember(ctx,leProducer.cv(),KMovieID.cv(),t89.cv())) goto _0;
		}
		c.f.fLine=82;
		if (g->Call(ctx,(PCV[]){nullptr,leProducer.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
		goto _12;
_13:
		{
			Obj t90;
			l__4D__auto__iter__0=t90.get();
		}
_11:
		{
			Variant t91;
			c.f.fLine=89;
			if (!g->GetValue(ctx,(PCV[]){t91.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t92;
			if (g->Call(ctx,(PCV[]){t92.cv(),t91.cv(),kyB6TMG4mH1Q.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Variant t93;
			if (g->GetMember(ctx,t92.cv(),Klength.cv(),t93.cv())) goto _0;
			Bool t94;
			if (g->OperationOnAny(ctx,5,t93.cv(),Num(0).cv(),t94.cv())) goto _0;
			if (!(t94.get())) goto _16;
		}
		{
			Variant t95;
			c.f.fLine=90;
			if (!g->GetValue(ctx,(PCV[]){t95.cv(),loTestData.cv(),nullptr})) goto _0;
			Variant t96;
			if (g->Call(ctx,(PCV[]){t96.cv(),t95.cv(),kyB6TMG4mH1Q.cv()},2,1496)) goto _0;
			g->Check(ctx);
			Ref t97;
			if (!g->CastPointerToRef(ctx,7,(PCV[]){t97.cv(),loCountry.cv(),nullptr})) goto _0;
			Obj t98;
			if (g->Call(ctx,(PCV[]){t98.cv(),t97.cv(),t96.cv()},2,1795)) goto _0;
			l__4D__auto__iter__1=t98.get();
		}
_17:
		{
			Bool t99;
			if (g->Call(ctx,(PCV[]){t99.cv(),l__4D__auto__iter__1.cv()},1,1796)) goto _0;
			if (!(t99.get())) goto _18;
		}
		{
			Obj t100;
			c.f.fLine=91;
			if (g->Call(ctx,(PCV[]){t100.cv()},0,1482)) goto _0;
			Variant t101;
			if (g->Call(ctx,(PCV[]){t101.cv(),t100.cv(),KCountries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t102;
			if (!g->GetValue(ctx,(PCV[]){t102.cv(),loCountry.cv(),nullptr})) goto _0;
			Variant t103;
			if (g->Call(ctx,(PCV[]){t103.cv(),t102.cv(),Kiso__3166__1.cv()},2,1496)) goto _0;
			Variant t104;
			if (g->Call(ctx,(PCV[]){t104.cv(),t101.cv(),Kquery.cv(),kFft24fqABwU.cv(),t103.cv()},4,1498)) goto _0;
			Obj t105;
			if (!g->GetValue(ctx,(PCV[]){t105.cv(),t104.cv(),nullptr})) goto _0;
			lesCountries=t105.get();
		}
		{
			Variant t106;
			c.f.fLine=92;
			if (g->GetMember(ctx,lesCountries.cv(),Klength.cv(),t106.cv())) goto _0;
			Bool t107;
			if (g->OperationOnAny(ctx,6,t106.cv(),Num(0).cv(),t107.cv())) goto _0;
			if (!(t107.get())) goto _19;
		}
		{
			Obj t108;
			c.f.fLine=93;
			if (g->Call(ctx,(PCV[]){t108.cv()},0,1482)) goto _0;
			Variant t109;
			if (g->Call(ctx,(PCV[]){t109.cv(),t108.cv(),KCountries.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t110;
			if (g->Call(ctx,(PCV[]){t110.cv(),t109.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t111;
			if (!g->GetValue(ctx,(PCV[]){t111.cv(),t110.cv(),nullptr})) goto _0;
			leCountry=t111.get();
		}
		{
			Variant t112;
			c.f.fLine=94;
			if (!g->GetValue(ctx,(PCV[]){t112.cv(),loCountry.cv(),nullptr})) goto _0;
			Variant t113;
			if (g->Call(ctx,(PCV[]){t113.cv(),t112.cv(),Kiso__3166__1.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leCountry.cv(),KCountry__ISO2.cv(),t113.cv())) goto _0;
		}
		{
			Variant t114;
			c.f.fLine=95;
			if (!g->GetValue(ctx,(PCV[]){t114.cv(),loCountry.cv(),nullptr})) goto _0;
			Variant t115;
			if (g->Call(ctx,(PCV[]){t115.cv(),t114.cv(),Kname.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leCountry.cv(),KEngName.cv(),t115.cv())) goto _0;
		}
		c.f.fLine=96;
		if (g->Call(ctx,(PCV[]){nullptr,leCountry.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
		goto _20;
_19:
		{
			Variant t116;
			c.f.fLine=98;
			if (g->Call(ctx,(PCV[]){t116.cv(),lesCountries.cv(),Kfirst.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t117;
			if (!g->GetValue(ctx,(PCV[]){t117.cv(),t116.cv(),nullptr})) goto _0;
			leCountry=t117.get();
		}
_20:
		{
			Obj t118;
			c.f.fLine=101;
			if (g->Call(ctx,(PCV[]){t118.cv()},0,1482)) goto _0;
			Variant t119;
			if (g->Call(ctx,(PCV[]){t119.cv(),t118.cv(),KCountryOfOrigin.cv(),Long(56).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t120;
			if (g->Call(ctx,(PCV[]){t120.cv(),t119.cv(),Knew.cv()},2,1498)) goto _0;
			Obj t121;
			if (!g->GetValue(ctx,(PCV[]){t121.cv(),t120.cv(),nullptr})) goto _0;
			leCOO=t121.get();
		}
		{
			Variant t122;
			c.f.fLine=102;
			if (!g->GetValue(ctx,(PCV[]){t122.cv(),loCountry.cv(),nullptr})) goto _0;
			Variant t123;
			if (g->Call(ctx,(PCV[]){t123.cv(),t122.cv(),Kiso__3166__1.cv()},2,1496)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,leCOO.cv(),KCountry__ISO2.cv(),t123.cv())) goto _0;
		}
		{
			Variant t124;
			c.f.fLine=103;
			if (g->GetMember(ctx,leMovie.cv(),KMovieID.cv(),t124.cv())) goto _0;
			if (g->SetMember(ctx,leCOO.cv(),KMovieID.cv(),t124.cv())) goto _0;
		}
		c.f.fLine=104;
		if (g->Call(ctx,(PCV[]){nullptr,leCOO.cv(),Ksave.cv()},2,1500)) goto _0;
		g->Check(ctx);
		goto _17;
_18:
		{
			Obj t125;
			l__4D__auto__iter__1=t125.get();
		}
_16:
_10:
_8:
_7:
_4:
		li=li.get()+1;
_3:
		if (li.get()<=v0.get()) goto _5;
_6:
_2:
		c.f.fLine=120;
		if (g->Call(ctx,(PCV[]){nullptr,KDONE.cv()},1,41)) goto _0;
		g->Check(ctx);
_0:
_1:
;
	}

}
