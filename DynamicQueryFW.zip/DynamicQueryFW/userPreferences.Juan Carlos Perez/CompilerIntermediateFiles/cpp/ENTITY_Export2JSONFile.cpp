extern int32_t vDOCUMENT;
extern int32_t vOK;
extern Txt K;
extern Txt Kjsn;
extern Txt Klength;
extern Txt KsetText;
extern Txt KtoCollection;
extern unsigned char D_proc_ENTITY__EXPORT2JSONFILE[];
void proc_ENTITY__EXPORT2JSONFILE( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_ENTITY__EXPORT2JSONFILE);
	if (!ctx->doingAbort) {
		Obj loExportFile;
		Time lhExportDoc;
		Obj lesEntities;
		Txt ltEntitiesExport;
		Bool lJCPEREZ__20241102;
		Variant lvProperties;
		c.f.fLine=11;
		lesEntities=Parm<Obj>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		{
			Variant t0;
			c.f.fLine=12;
			if (!g->GetValue(ctx,(PCV[]){t0.cv(),Parm<Variant>(ctx,inParams,inNbParam,2).cv(),nullptr})) goto _0;
			if (!g->SetValue(ctx,(PCV[]){t0.cv(),lvProperties.cv(),nullptr})) goto _0;
		}
		if (ctx->doingAbort) goto _0;
		{
			Variant t1;
			c.f.fLine=18;
			if (g->GetMember(ctx,lesEntities.cv(),Klength.cv(),t1.cv())) goto _0;
			Bool t2;
			if (g->OperationOnAny(ctx,5,t1.cv(),Num(0).cv(),t2.cv())) goto _0;
			if (!(t2.get())) goto _2;
		}
		{
			Time t3;
			c.f.fLine=19;
			if (g->Call(ctx,(PCV[]){t3.cv(),K.cv(),Kjsn.cv()},2,266)) goto _0;
			g->Check(ctx);
			lhExportDoc=t3.get();
		}
		if (1!=Var<Long>(ctx,vOK).get()) goto _3;
		{
			Time t5;
			t5=lhExportDoc.get();
			c.f.fLine=22;
			if (g->Call(ctx,(PCV[]){nullptr,t5.cv()},1,267)) goto _0;
			g->Check(ctx);
		}
		{
			Obj t6;
			c.f.fLine=23;
			if (g->Call(ctx,(PCV[]){t6.cv(),Var<Txt>(ctx,vDOCUMENT).cv(),Long(1).cv()},2,1566)) goto _0;
			g->Check(ctx);
			loExportFile=t6.get();
		}
		{
			Variant t7;
			c.f.fLine=24;
			if (!g->GetValue(ctx,(PCV[]){t7.cv(),lvProperties.cv(),nullptr})) goto _0;
			Variant t8;
			if (g->Call(ctx,(PCV[]){t8.cv(),lesEntities.cv(),KtoCollection.cv(),t7.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Txt t9;
			if (g->Call(ctx,(PCV[]){t9.cv(),t8.cv()},1,1217)) goto _0;
			ltEntitiesExport=t9.get();
		}
		c.f.fLine=25;
		if (g->Call(ctx,(PCV[]){nullptr,loExportFile.cv(),KsetText.cv(),ltEntitiesExport.cv()},3,1500)) goto _0;
		g->Check(ctx);
_3:
_2:
_0:
_1:
;
	}

}
