extern Txt K;
extern Txt KThis_2E;
extern Txt K_2C;
extern Txt KbHidden;
extern Txt KiWidth;
extern Txt KindexOf;
extern Txt Klength;
extern Txt Kpush;
extern Txt KtHeader;
extern Txt KtName;
extern Txt KtVariable;
extern unsigned char D_proc_WDGT__CONFIGCOLUMNS[];
void proc_WDGT__CONFIGCOLUMNS( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_WDGT__CONFIGCOLUMNS);
	if (!ctx->doingAbort) {
		Long v0;
		Long v1;
		Long li;
		Txt ltHeaders;
		Col lcolListSetup;
		Col lcolWidths;
		Col lcolHdrMaps;
		Bool lJCPEREZ__20241102;
		Txt ltHiddenCols;
		Obj loCol;
		Col lcolHeaders;
		Txt ltHdrMap;
		Txt ltWidths;
		Col lcolHiddenCols;
		new ( outResult) Col();
		c.f.fLine=20;
		ltHeaders=Parm<Txt>(ctx,inParams,inNbParam,1).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=21;
		ltHdrMap=Parm<Txt>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
		c.f.fLine=22;
		ltWidths=Parm<Txt>(ctx,inParams,inNbParam,3).get();
		if (ctx->doingAbort) goto _0;
		ltHiddenCols=K.get();
		{
			Col t0;
			c.f.fLine=24;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolListSetup=t0.get();
		}
		{
			Long t1;
			t1=inNbExplicitParam;
			if (4>t1.get()) goto _2;
		}
		c.f.fLine=27;
		ltHiddenCols=Parm<Txt>(ctx,inParams,inNbParam,4).get();
		if (ctx->doingAbort) goto _0;
_2:
		{
			Col t3;
			c.f.fLine=32;
			if (g->Call(ctx,(PCV[]){t3.cv(),ltHeaders.cv(),K_2C.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolHeaders=t3.get();
		}
		{
			Col t4;
			c.f.fLine=33;
			if (g->Call(ctx,(PCV[]){t4.cv(),ltHdrMap.cv(),K_2C.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolHdrMaps=t4.get();
		}
		{
			Col t5;
			c.f.fLine=34;
			if (g->Call(ctx,(PCV[]){t5.cv(),ltWidths.cv(),K_2C.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolWidths=t5.get();
		}
		{
			Col t6;
			c.f.fLine=35;
			if (g->Call(ctx,(PCV[]){t6.cv(),ltHiddenCols.cv(),K_2C.cv()},2,1554)) goto _0;
			g->Check(ctx);
			lcolHiddenCols=t6.get();
		}
		{
			Variant t7;
			c.f.fLine=37;
			if (g->Call(ctx,(PCV[]){t7.cv(),lcolHeaders.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t8;
			if (g->Call(ctx,(PCV[]){t8.cv(),lcolHdrMaps.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			Bool t9;
			if (g->OperationOnAny(ctx,6,t7.cv(),t8.cv(),t9.cv())) goto _0;
			Variant t10;
			if (g->Call(ctx,(PCV[]){t10.cv(),lcolWidths.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			Variant t11;
			if (g->Call(ctx,(PCV[]){t11.cv(),lcolHdrMaps.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			Bool t12;
			if (g->OperationOnAny(ctx,6,t10.cv(),t11.cv(),t12.cv())) goto _0;
			Bool t13;
			t13=t9.get()&&t12.get();
			if (!(t13.get())) goto _3;
		}
		li=0;
		{
			Variant t14;
			c.f.fLine=39;
			if (g->Call(ctx,(PCV[]){t14.cv(),lcolHdrMaps.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Variant t15;
			if (g->OperationOnAny(ctx,1,t14.cv(),Num(1).cv(),t15.cv())) goto _0;
			Long t16;
			if (!g->GetValue(ctx,(PCV[]){t16.cv(),t15.cv(),nullptr})) goto _0;
			v0=t16.get();
		}
		goto _4;
_6:
		{
			Obj t17;
			c.f.fLine=40;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loCol=t17.get();
		}
		{
			Variant t18;
			c.f.fLine=41;
			if (g->GetMember(ctx,lcolHdrMaps.cv(),li.cv(),t18.cv())) goto _0;
			if (g->SetMember(ctx,loCol.cv(),KtName.cv(),t18.cv())) goto _0;
		}
		{
			Variant t19;
			c.f.fLine=42;
			if (g->GetMember(ctx,lcolHdrMaps.cv(),li.cv(),t19.cv())) goto _0;
			Variant t20;
			if (g->OperationOnAny(ctx,0,KThis_2E.cv(),t19.cv(),t20.cv())) goto _0;
			if (g->SetMember(ctx,loCol.cv(),KtVariable.cv(),t20.cv())) goto _0;
		}
		{
			Variant t21;
			c.f.fLine=43;
			if (g->GetMember(ctx,lcolHeaders.cv(),li.cv(),t21.cv())) goto _0;
			if (g->SetMember(ctx,loCol.cv(),KtHeader.cv(),t21.cv())) goto _0;
		}
		{
			Variant t22;
			c.f.fLine=44;
			if (g->GetMember(ctx,lcolWidths.cv(),li.cv(),t22.cv())) goto _0;
			Num t23;
			if (g->Call(ctx,(PCV[]){t23.cv(),t22.cv()},1,11)) goto _0;
			if (g->SetMember(ctx,loCol.cv(),KiWidth.cv(),t23.cv())) goto _0;
		}
		{
			Variant t24;
			c.f.fLine=45;
			if (g->GetMember(ctx,lcolHdrMaps.cv(),li.cv(),t24.cv())) goto _0;
			Variant t25;
			if (g->Call(ctx,(PCV[]){t25.cv(),lcolHiddenCols.cv(),KindexOf.cv(),t24.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Bool t26;
			if (g->OperationOnAny(ctx,12,t25.cv(),Num(0).cv(),t26.cv())) goto _0;
			Bool t27;
			t27=t26.get();
			if (g->SetMember(ctx,loCol.cv(),KbHidden.cv(),t27.cv())) goto _0;
		}
		c.f.fLine=46;
		if (g->Call(ctx,(PCV[]){nullptr,lcolListSetup.cv(),Kpush.cv(),loCol.cv()},3,1500)) goto _0;
		g->Check(ctx);
_5:
		li=li.get()+1;
_4:
		if (li.get()<=v0.get()) goto _6;
_7:
_3:
		c.f.fLine=52;
		Res<Col>(outResult)=lcolListSetup.get();
_0:
_1:
;
	}

}
