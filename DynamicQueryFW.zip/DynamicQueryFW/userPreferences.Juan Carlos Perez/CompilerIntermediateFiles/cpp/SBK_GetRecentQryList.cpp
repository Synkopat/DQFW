extern Txt KbSuccess;
extern Txt KoObject;
extern Txt Kpush;
Asm4d_Proc proc_UTIL__PARSEJSONSTR;
extern unsigned char D_proc_SBK__GETRECENTQRYLIST[];
void proc_SBK__GETRECENTQRYLIST( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_SBK__GETRECENTQRYLIST);
	if (!ctx->doingAbort) {
		Txt ltSystem;
		Obj l__4D__auto__iter__0;
		Bool lJCPEREZ__20241102;
		Obj loResult;
		new ( outResult) Col();
		{
			Col t0;
			c.f.fLine=27;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1472)) goto _0;
			g->Check(ctx);
			Res<Col>(outResult)=t0.get();
		}
		c.f.fLine=31;
		{
			Ref t1;
			t1.setLocalRef(ctx,ltSystem.cv());
			Obj t2;
			if (g->Call(ctx,(PCV[]){t2.cv(),t1.cv(),Parm<Col>(ctx,inParams,inNbParam,1).cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t2.get();
		}
		if (ctx->doingAbort) goto _0;
_2:
		{
			Bool t3;
			if (g->Call(ctx,(PCV[]){t3.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t3.get())) goto _3;
		}
		{
			Long t4;
			t4=0;
			Txt t5;
			t5=ltSystem.get();
			Obj t6;
			c.f.fLine=32;
			proc_UTIL__PARSEJSONSTR(glob,ctx,1,2,(PCV[]){t5.cv(),t4.cv()},t6.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loResult=t6.get();
		}
		{
			Variant t7;
			c.f.fLine=33;
			if (g->GetMember(ctx,loResult.cv(),KbSuccess.cv(),t7.cv())) goto _0;
			Bool t8;
			if (!g->GetValue(ctx,(PCV[]){t8.cv(),t7.cv(),nullptr})) goto _0;
			if (!(t8.get())) goto _4;
		}
		{
			Variant t9;
			c.f.fLine=34;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t9.cv())) goto _0;
			if (g->Call(ctx,(PCV[]){nullptr,Res<Col>(outResult).cv(),Kpush.cv(),t9.cv()},3,1500)) goto _0;
			g->Check(ctx);
		}
_4:
		goto _2;
_3:
		{
			Obj t10;
			l__4D__auto__iter__0=t10.get();
		}
		c.f.fLine=40;
		Res<Col>(outResult)=Res<Col>(outResult).get();
_0:
_1:
;
	}

}
