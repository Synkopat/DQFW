extern Txt K;
extern Txt KAdvanced;
extern Txt KBaseEntity;
extern Txt KCategory;
extern Txt KDQFW__QueryTable;
extern Txt KDisplayRole;
extern Txt KGroup;
extern Txt KIsActive;
extern Txt KNEW__QUERY__LINE;
extern Txt KNew_20Query_20Line;
extern Txt KQryLines;
extern Txt KQueryName;
extern Txt KSHORTCUTS;
extern Txt KSearch_20;
extern Txt KSearch_20Database;
extern Txt KSortNo;
extern Txt KUI__SEARCH;
extern Txt K_20IN_20_3A1;
extern Txt KbIsAdminUser;
extern Txt KbSuccess;
extern Txt KbUpdateCache;
extern Txt KcolQryLines;
extern Txt KcolRQ;
extern Txt Kcombine;
extern Txt Kcopy;
extern Txt KgetInfo;
extern Txt KiAdd2Selection;
extern Txt KiQryLineIndx;
extern Txt KiQrySelection;
extern Txt KiWinRef;
extern Txt Klength;
extern Txt Kname;
extern Txt KnewSelection;
extern Txt KoNewQryLine;
extern Txt KoObject;
extern Txt KoQryLine;
extern Txt Kor;
extern Txt KprimaryKey;
extern Txt Kpush;
extern Txt KqryLines;
extern Txt Kquery;
extern Txt KtFormHeader;
extern Txt KtQueryTable;
extern Txt k0hyJBtb3YKs;
extern Txt k37ob$gUXo40;
extern Txt k7nPzzMJ4l8k;
extern Txt kI9o4oFrPi2g;
extern Txt kLFmVOfq3Rog;
extern Txt kVfh0oqO1WwE;
extern Txt kpBUF4YZPrek;
extern Txt ksv03rMKIa68;
Asm4d_Proc proc_SBK__GET;
Asm4d_Proc proc_SBK__GETRECENTQRYLIST;
Asm4d_Proc proc_SBK__SETSYSTEM;
Asm4d_Proc proc_UTIL__PARSEJSONSTR;
Asm4d_Proc proc_WIND__OPENWINDOW;
extern unsigned char D_proc_DQFW__QUERYTABLE[];
void proc_DQFW__QUERYTABLE( Asm4d_globals *glob, tProcessGlobals *ctx, int32_t inNbExplicitParam, int32_t inNbParam, PCV inParams[], CV *outResult)
{
	CallChain c(ctx,D_proc_DQFW__QUERYTABLE);
	if (!ctx->doingAbort) {
		Txt ltPKField;
		Txt ltQueryScreenType;
		Col lcolNewLine;
		Long liFormHeight;
		Long liID;
		Long liFormWidth;
		Txt ltQueryForm;
		Txt ltTable;
		Txt ltProperty;
		Obj l__4D__auto__iter__0;
		Obj loAddQryShortcut;
		Obj loSearch;
		Col lcolDfltQuery;
		Bool lJCPEREZ__20241102;
		Col lcolExistingSelectionKeys;
		Obj loResult;
		new ( outResult) Obj();
		{
			Col t0;
			c.f.fLine=15;
			if (g->Call(ctx,(PCV[]){t0.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolExistingSelectionKeys=t0.get();
		}
		{
			Long t1;
			t1=inNbExplicitParam;
			if (2>t1.get()) goto _2;
		}
		c.f.fLine=18;
		lcolExistingSelectionKeys=Parm<Col>(ctx,inParams,inNbParam,2).get();
		if (ctx->doingAbort) goto _0;
_2:
		ltQueryScreenType=KAdvanced.get();
		c.f.fLine=27;
		{
			Variant t3;
			if (g->Call(ctx,(PCV[]){t3.cv(),Parm<Obj>(ctx,inParams,inNbParam,1).cv(),KnewSelection.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Obj t4;
			if (!g->GetValue(ctx,(PCV[]){t4.cv(),t3.cv(),nullptr})) goto _0;
			Res<Obj>(outResult)=t4.get();
		}
		if (ctx->doingAbort) goto _0;
		ltQueryForm=KDQFW__QueryTable.get();
		{
			Ref t5;
			t5.setLocalRef(ctx,liFormHeight.cv());
			Ref t6;
			t6.setLocalRef(ctx,liFormWidth.cv());
			c.f.fLine=30;
			if (g->Call(ctx,(PCV[]){nullptr,ltQueryForm.cv(),t6.cv(),t5.cv()},3,674)) goto _0;
			g->Check(ctx);
		}
		c.f.fLine=35;
		{
			Variant t7;
			if (g->Call(ctx,(PCV[]){t7.cv(),Parm<Obj>(ctx,inParams,inNbParam,1).cv(),KgetInfo.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Variant t8;
			if (g->GetMember(ctx,t7.cv(),Kname.cv(),t8.cv())) goto _0;
			Txt t9;
			if (!g->GetValue(ctx,(PCV[]){t9.cv(),t8.cv(),nullptr})) goto _0;
			ltTable=t9.get();
		}
		if (ctx->doingAbort) goto _0;
		c.f.fLine=36;
		{
			Variant t10;
			if (g->Call(ctx,(PCV[]){t10.cv(),Parm<Obj>(ctx,inParams,inNbParam,1).cv(),KgetInfo.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Variant t11;
			if (g->GetMember(ctx,t10.cv(),KprimaryKey.cv(),t11.cv())) goto _0;
			Txt t12;
			if (!g->GetValue(ctx,(PCV[]){t12.cv(),t11.cv(),nullptr})) goto _0;
			ltPKField=t12.get();
		}
		if (ctx->doingAbort) goto _0;
		{
			Txt t13;
			t13=k37ob$gUXo40.get();
			Txt t14;
			t14=ltTable.get();
			Obj t15;
			c.f.fLine=39;
			proc_SBK__GET(glob,ctx,2,2,(PCV[]){t14.cv(),t13.cv()},t15.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loAddQryShortcut=t15.get();
		}
		{
			Bool t16;
			t16=loAddQryShortcut.isNull();
			if (!(t16.get())) goto _3;
		}
		{
			Obj t17;
			c.f.fLine=41;
			if (g->Call(ctx,(PCV[]){t17.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loAddQryShortcut=t17.get();
		}
		c.f.fLine=42;
		if (g->SetMember(ctx,loAddQryShortcut.cv(),KBaseEntity.cv(),ltTable.cv())) goto _0;
		c.f.fLine=43;
		if (g->SetMember(ctx,loAddQryShortcut.cv(),KGroup.cv(),KUI__SEARCH.cv())) goto _0;
		c.f.fLine=44;
		if (g->SetMember(ctx,loAddQryShortcut.cv(),KCategory.cv(),KSHORTCUTS.cv())) goto _0;
		c.f.fLine=45;
		if (g->SetMember(ctx,loAddQryShortcut.cv(),KQueryName.cv(),KNEW__QUERY__LINE.cv())) goto _0;
		c.f.fLine=46;
		if (g->SetMember(ctx,loAddQryShortcut.cv(),KDisplayRole.cv(),KNew_20Query_20Line.cv())) goto _0;
		c.f.fLine=47;
		if (g->SetMember(ctx,loAddQryShortcut.cv(),KSortNo.cv(),Long(1).cv())) goto _0;
		{
			Bool t18;
			t18=Bool(1).get();
			c.f.fLine=48;
			if (g->SetMember(ctx,loAddQryShortcut.cv(),KIsActive.cv(),t18.cv())) goto _0;
		}
		c.f.fLine=49;
		if (g->SetMember(ctx,loAddQryShortcut.cv(),KQryLines.cv(),kLFmVOfq3Rog.cv())) goto _0;
		{
			Bool t20;
			t20=Bool(0).get();
			Obj t21;
			t21=loAddQryShortcut.get();
			Long t22;
			c.f.fLine=50;
			proc_SBK__SETSYSTEM(glob,ctx,1,2,(PCV[]){t21.cv(),t20.cv()},t22.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			liID=t22.get();
		}
_3:
		{
			Obj t23;
			c.f.fLine=54;
			if (g->Call(ctx,(PCV[]){t23.cv()},0,1471)) goto _0;
			g->Check(ctx);
			loSearch=t23.get();
		}
		c.f.fLine=55;
		if (g->SetMember(ctx,loSearch.cv(),KtQueryTable.cv(),ltTable.cv())) goto _0;
		c.f.fLine=56;
		if (g->SetMember(ctx,loSearch.cv(),kVfh0oqO1WwE.cv(),ltQueryScreenType.cv())) goto _0;
		{
			Txt t24;
			g->AddString(KSearch_20.get(),ltTable.get(),t24.get());
			c.f.fLine=57;
			if (g->SetMember(ctx,loSearch.cv(),KtFormHeader.cv(),t24.cv())) goto _0;
		}
		{
			Variant t25;
			c.f.fLine=58;
			if (g->GetMember(ctx,loSearch.cv(),KtQueryTable.cv(),t25.cv())) goto _0;
			Variant t26;
			if (g->OperationOnAny(ctx,0,KcolRQ.cv(),t25.cv(),t26.cv())) goto _0;
			if (g->SetMember(ctx,loSearch.cv(),ksv03rMKIa68.cv(),t26.cv())) goto _0;
		}
		{
			Obj t27;
			c.f.fLine=59;
			if (g->Call(ctx,(PCV[]){t27.cv()},0,1471)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loSearch.cv(),KoQryLine.cv(),t27.cv())) goto _0;
		}
		c.f.fLine=60;
		if (g->SetMember(ctx,loSearch.cv(),KiQryLineIndx.cv(),Long(0).cv())) goto _0;
		{
			Col t28;
			c.f.fLine=61;
			if (g->Call(ctx,(PCV[]){t28.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loSearch.cv(),KcolQryLines.cv(),t28.cv())) goto _0;
		}
		{
			Obj t29;
			c.f.fLine=62;
			if (g->Call(ctx,(PCV[]){t29.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t30;
			if (g->GetMember(ctx,loSearch.cv(),ksv03rMKIa68.cv(),t30.cv())) goto _0;
			Variant t31;
			if (g->GetMember(ctx,t29.cv(),t30.cv(),t31.cv())) goto _0;
			Col t32;
			if (!g->GetValue(ctx,(PCV[]){t32.cv(),t31.cv(),nullptr})) goto _0;
			Col t33;
			proc_SBK__GETRECENTQRYLIST(glob,ctx,1,1,(PCV[]){t32.cv()},t33.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loSearch.cv(),kI9o4oFrPi2g.cv(),t33.cv())) goto _0;
		}
		{
			Col t34;
			c.f.fLine=63;
			if (g->Call(ctx,(PCV[]){t34.cv()},0,1472)) goto _0;
			g->Check(ctx);
			if (g->SetMember(ctx,loSearch.cv(),k0hyJBtb3YKs.cv(),t34.cv())) goto _0;
		}
		{
			Variant t35;
			c.f.fLine=64;
			if (g->GetMember(ctx,loSearch.cv(),k0hyJBtb3YKs.cv(),t35.cv())) goto _0;
			Obj t36;
			if (g->Call(ctx,(PCV[]){t36.cv()},0,1525)) goto _0;
			g->Check(ctx);
			Variant t37;
			if (g->GetMember(ctx,loSearch.cv(),ksv03rMKIa68.cv(),t37.cv())) goto _0;
			Variant t38;
			if (g->GetMember(ctx,t36.cv(),t37.cv(),t38.cv())) goto _0;
			Variant t39;
			if (g->Call(ctx,(PCV[]){t39.cv(),t35.cv(),Kcombine.cv(),t38.cv()},3,1498)) goto _0;
			if (g->SetMember(ctx,loSearch.cv(),k0hyJBtb3YKs.cv(),t39.cv())) goto _0;
		}
		{
			Bool t40;
			t40=Bool(1).get();
			c.f.fLine=65;
			if (g->SetMember(ctx,loSearch.cv(),KbUpdateCache.cv(),t40.cv())) goto _0;
		}
		c.f.fLine=67;
		if (g->SetMember(ctx,loSearch.cv(),KiAdd2Selection.cv(),Long(0).cv())) goto _0;
		c.f.fLine=68;
		if (g->SetMember(ctx,loSearch.cv(),KiQrySelection.cv(),Long(0).cv())) goto _0;
		{
			Variant t41;
			c.f.fLine=69;
			if (g->Call(ctx,(PCV[]){t41.cv(),lcolExistingSelectionKeys.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t42;
			if (g->OperationOnAny(ctx,5,t41.cv(),Num(0).cv(),t42.cv())) goto _0;
			Bool t43;
			t43=t42.get();
			if (g->SetMember(ctx,loSearch.cv(),kpBUF4YZPrek.cv(),t43.cv())) goto _0;
		}
		{
			Bool t44;
			t44=Bool(1).get();
			c.f.fLine=71;
			if (g->SetMember(ctx,loSearch.cv(),KbIsAdminUser.cv(),t44.cv())) goto _0;
		}
		{
			Variant t45;
			c.f.fLine=72;
			if (g->GetMember(ctx,loAddQryShortcut.cv(),KQryLines.cv(),t45.cv())) goto _0;
			Long t46;
			t46=38;
			Txt t47;
			if (!g->GetValue(ctx,(PCV[]){t47.cv(),t45.cv(),nullptr})) goto _0;
			Obj t48;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t47.cv(),t46.cv()},t48.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			Variant t49;
			if (g->GetMember(ctx,t48.cv(),KoObject.cv(),t49.cv())) goto _0;
			Variant t50;
			if (g->GetMember(ctx,t49.cv(),KqryLines.cv(),t50.cv())) goto _0;
			Variant t51;
			if (g->GetMember(ctx,t50.cv(),Long(0).cv(),t51.cv())) goto _0;
			if (g->SetMember(ctx,loSearch.cv(),KoNewQryLine.cv(),t51.cv())) goto _0;
		}
		{
			Col t52;
			c.f.fLine=75;
			if (g->Call(ctx,(PCV[]){t52.cv()},0,1472)) goto _0;
			g->Check(ctx);
			lcolDfltQuery=t52.get();
		}
		{
			Variant t53;
			c.f.fLine=76;
			if (g->GetMember(ctx,loSearch.cv(),k0hyJBtb3YKs.cv(),t53.cv())) goto _0;
			Variant t54;
			if (g->GetMember(ctx,t53.cv(),Klength.cv(),t54.cv())) goto _0;
			Bool t55;
			if (g->OperationOnAny(ctx,6,t54.cv(),Num(0).cv(),t55.cv())) goto _0;
			if (!(t55.get())) goto _4;
		}
		{
			Variant t56;
			c.f.fLine=77;
			if (g->GetMember(ctx,loSearch.cv(),KoNewQryLine.cv(),t56.cv())) goto _0;
			Obj t57;
			if (!g->GetValue(ctx,(PCV[]){t57.cv(),t56.cv(),nullptr})) goto _0;
			Obj t58;
			if (g->Call(ctx,(PCV[]){t58.cv(),t57.cv()},1,1225)) goto _0;
			g->Check(ctx);
			if (g->Call(ctx,(PCV[]){nullptr,lcolDfltQuery.cv(),Kpush.cv(),t58.cv()},3,1500)) goto _0;
		}
		goto _5;
_4:
		{
			Variant t59;
			c.f.fLine=80;
			if (g->GetMember(ctx,loSearch.cv(),k0hyJBtb3YKs.cv(),t59.cv())) goto _0;
			Variant t60;
			if (g->GetMember(ctx,t59.cv(),Long(0).cv(),t60.cv())) goto _0;
			Long t61;
			t61=38;
			Txt t62;
			if (!g->GetValue(ctx,(PCV[]){t62.cv(),t60.cv(),nullptr})) goto _0;
			Obj t63;
			proc_UTIL__PARSEJSONSTR(glob,ctx,2,2,(PCV[]){t62.cv(),t61.cv()},t63.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			loResult=t63.get();
		}
		{
			Variant t64;
			c.f.fLine=81;
			if (g->GetMember(ctx,loResult.cv(),KbSuccess.cv(),t64.cv())) goto _0;
			Bool t65;
			if (!g->GetValue(ctx,(PCV[]){t65.cv(),t64.cv(),nullptr})) goto _0;
			if (!(t65.get())) goto _6;
		}
		{
			Variant t66;
			c.f.fLine=82;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t66.cv())) goto _0;
			Ref t67;
			t67.setLocalRef(ctx,ltProperty.cv());
			Obj t68;
			if (g->Call(ctx,(PCV[]){t68.cv(),t67.cv(),t66.cv()},2,1795)) goto _0;
			l__4D__auto__iter__0=t68.get();
		}
		{
			Bool t69;
			if (g->Call(ctx,(PCV[]){t69.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
			g->Check(ctx);
			if (!(t69.get())) goto _7;
		}
_9:
		{
			Variant t70;
			c.f.fLine=83;
			if (g->GetMember(ctx,loResult.cv(),KoObject.cv(),t70.cv())) goto _0;
			Variant t71;
			if (g->GetMember(ctx,t70.cv(),ltProperty.cv(),t71.cv())) goto _0;
			Variant t72;
			if (g->Call(ctx,(PCV[]){t72.cv(),t71.cv(),Kcopy.cv()},2,1498)) goto _0;
			g->Check(ctx);
			Col t73;
			if (!g->GetValue(ctx,(PCV[]){t73.cv(),t72.cv(),nullptr})) goto _0;
			lcolDfltQuery=t73.get();
		}
_8:
		{
			Variant t74;
			c.f.fLine=84;
			if (g->Call(ctx,(PCV[]){t74.cv(),lcolNewLine.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t75;
			if (g->OperationOnAny(ctx,5,t74.cv(),Num(0).cv(),t75.cv())) goto _0;
			Bool t76;
			t76=t75.get();
			if (t75.get()) goto _11;
			{
				Bool t77;
				if (g->Call(ctx,(PCV[]){t77.cv(),l__4D__auto__iter__0.cv()},1,1796)) goto _0;
				Bool t78;
				t78=t77.get();
				Bool t79;
				t79=!(t78.get());
				t76=t79.get();
			}
_11:
			if (!(t76.get())) goto _9;
		}
_10:
_7:
		{
			Obj t80;
			l__4D__auto__iter__0=t80.get();
		}
_6:
_5:
		c.f.fLine=87;
		if (g->SetMember(ctx,loSearch.cv(),KcolQryLines.cv(),lcolDfltQuery.cv())) goto _0;
		{
			Ptr t81;
			Txt t82;
			t82=ltQueryForm.get();
			Txt t83;
			t83=KSearch_20Database.get();
			Long t84;
			t84=8;
			Long t85;
			t85=6;
			Long t86;
			t86=liFormHeight.get();
			Long t87;
			t87=liFormWidth.get();
			Long t88;
			c.f.fLine=90;
			proc_WIND__OPENWINDOW(glob,ctx,6,7,(PCV[]){t87.cv(),t86.cv(),t85.cv(),t84.cv(),t83.cv(),t82.cv(),t81.cv()},t88.cv());
			if (ctx->checkPendingErrors) g->CheckErr(ctx,0);
			if (ctx->doingAbort) goto _0;
			if (g->SetMember(ctx,loSearch.cv(),KiWinRef.cv(),t88.cv())) goto _0;
		}
		c.f.fLine=92;
		if (g->Call(ctx,(PCV[]){nullptr,ltQueryForm.cv(),loSearch.cv()},2,40)) goto _0;
		g->Check(ctx);
		{
			Variant t89;
			c.f.fLine=95;
			if (g->Call(ctx,(PCV[]){t89.cv(),lcolExistingSelectionKeys.cv(),Klength.cv(),Long(4).cv()},3,1496)) goto _0;
			g->Check(ctx);
			Bool t90;
			if (g->OperationOnAny(ctx,6,t89.cv(),Num(0).cv(),t90.cv())) goto _0;
			if (!(t90.get())) goto _13;
		}
		{
			Variant t91;
			c.f.fLine=96;
			if (g->GetMember(ctx,loSearch.cv(),k7nPzzMJ4l8k.cv(),t91.cv())) goto _0;
			Obj t92;
			if (!g->GetValue(ctx,(PCV[]){t92.cv(),t91.cv(),nullptr})) goto _0;
			Res<Obj>(outResult)=t92.get();
		}
		goto _12;
_13:
		{
			Variant t93;
			c.f.fLine=98;
			if (g->GetMember(ctx,loSearch.cv(),KiAdd2Selection.cv(),t93.cv())) goto _0;
			Bool t94;
			if (g->OperationOnAny(ctx,6,t93.cv(),Num(1).cv(),t94.cv())) goto _0;
			Bool t95;
			t95=g->CompareString(ctx,ltPKField.get(),K.get())!=0;
			Bool t96;
			t96=t94.get()&&t95.get();
			if (!(t96.get())) goto _14;
		}
		{
			Obj t97;
			c.f.fLine=100;
			if (g->Call(ctx,(PCV[]){t97.cv()},0,1482)) goto _0;
			Variant t98;
			if (g->GetMember(ctx,t97.cv(),ltTable.cv(),t98.cv())) goto _0;
			Txt t99;
			g->AddString(ltPKField.get(),K_20IN_20_3A1.get(),t99.get());
			Variant t100;
			if (g->Call(ctx,(PCV[]){t100.cv(),t98.cv(),Kquery.cv(),t99.cv(),lcolExistingSelectionKeys.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Obj t101;
			if (!g->GetValue(ctx,(PCV[]){t101.cv(),t100.cv(),nullptr})) goto _0;
			Res<Obj>(outResult)=t101.get();
		}
		{
			Variant t102;
			c.f.fLine=101;
			if (g->GetMember(ctx,loSearch.cv(),k7nPzzMJ4l8k.cv(),t102.cv())) goto _0;
			Variant t103;
			if (g->Call(ctx,(PCV[]){t103.cv(),Res<Obj>(outResult).cv(),Kor.cv(),t102.cv()},3,1498)) goto _0;
			g->Check(ctx);
			Obj t104;
			if (!g->GetValue(ctx,(PCV[]){t104.cv(),t103.cv(),nullptr})) goto _0;
			Res<Obj>(outResult)=t104.get();
		}
		goto _12;
_14:
		{
			Variant t105;
			c.f.fLine=103;
			if (g->GetMember(ctx,loSearch.cv(),KiQrySelection.cv(),t105.cv())) goto _0;
			Bool t106;
			if (g->OperationOnAny(ctx,6,t105.cv(),Num(1).cv(),t106.cv())) goto _0;
			if (!(t106.get())) goto _15;
		}
		{
			Variant t107;
			c.f.fLine=105;
			if (g->GetMember(ctx,loSearch.cv(),ltTable.cv(),t107.cv())) goto _0;
			Txt t108;
			g->AddString(ltPKField.get(),K_20IN_20_3A1.get(),t108.get());
			Variant t109;
			if (g->Call(ctx,(PCV[]){t109.cv(),t107.cv(),Kquery.cv(),t108.cv(),lcolExistingSelectionKeys.cv()},4,1498)) goto _0;
			g->Check(ctx);
			Obj t110;
			if (!g->GetValue(ctx,(PCV[]){t110.cv(),t109.cv(),nullptr})) goto _0;
			Res<Obj>(outResult)=t110.get();
		}
		goto _12;
_15:
		{
			Variant t111;
			c.f.fLine=108;
			if (g->GetMember(ctx,loSearch.cv(),k7nPzzMJ4l8k.cv(),t111.cv())) goto _0;
			Obj t112;
			if (!g->GetValue(ctx,(PCV[]){t112.cv(),t111.cv(),nullptr})) goto _0;
			Res<Obj>(outResult)=t112.get();
		}
_12:
		c.f.fLine=113;
		Res<Obj>(outResult)=Res<Obj>(outResult).get();
_0:
_1:
;
	}

}
